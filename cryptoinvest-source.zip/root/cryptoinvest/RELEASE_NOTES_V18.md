# V18 - Unified Navigation Fix

- Added a full NVT Menu drawer for mobile and desktop.
- Mobile bottom nav stays compact, with More opening all tools.
- Desktop top navigation is compacted and includes a Menu button for all pages.
- Added KYC, Support, Tickets, Referral, Download and Logout inside the complete menu.
- Improved mobile profile readability and compact menu styling.
- Cache version bumped to v18-menu.
