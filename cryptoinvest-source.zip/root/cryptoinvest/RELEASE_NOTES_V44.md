# N-VT Miner v44

- Deposit submit rebuilt with GET image pixel request to avoid iOS/PWA fetch lock.
- Removed submit spinner/wait state from deposit form.
- Manual deposit remains fully manual and goes to pending deposits for admin.
- Dashboard mining stage/VIP section replaced with miner rental plan cards.
- VIP level page changed to miner rental plans page.
- Cache/service worker version updated to v44 and no longer caches HTML pages.
