# Release Notes V26

## Lucky Wheel prize increase
- Updated cash prizes from 5/7/10/16/25 USDT to 17/25/39/50/70 USDT.
- Kept iPhone 17, Washer and Refrigerator as display-only prizes with 0 winning chance.
- Adjusted prize odds so larger USDT prizes are much rarer.
- Bumped Lucky Wheel cache version to v26.

## Current hidden odds
- 17 USDT: common
- 25 USDT: medium
- 39 USDT: low
- 50 USDT: very low
- 70 USDT: ultra low
- Extra Spin: medium
