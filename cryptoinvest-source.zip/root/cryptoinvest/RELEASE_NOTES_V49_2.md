# N-VT Miner V49.2

- Removed the visible minimum-withdrawal text from the withdrawal page while keeping server-side withdrawal rules unchanged.
- Removed the visible KYC warning card from the top of the withdrawal page; KYC enforcement remains server-side.
- Removed the referral Lucky Wheel coming-soon messages.
- Added a dashboard popup that dynamically shows miner rental plans, 24-hour profit values, and profit percentages from the live mining API.
- Added per-notification deletion in the admin notifications panel, including cleanup of notification read receipts.
- Updated PWA cache/version identifiers to V49.2.
- No database reset or user-data migration is required.
