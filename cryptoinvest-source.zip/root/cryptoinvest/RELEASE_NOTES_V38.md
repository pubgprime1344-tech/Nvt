# N-VT Miner v38 — Assets, Convert, Admin Asset Controls

- Added `/convert` page and Convert option in the mobile/bottom menu.
- Assets page now shows USDT, BTC, ETH and DOGE balances with coin icons.
- Admin Users can adjust USDT, BTC, ETH and DOGE balances per user.
- Withdraw page now asks for the wallet address of the selected asset and changes network options per asset.
- Mining contracts remain database-based; active contracts continue after updates from the same created_at timestamp and are not reset.
- When a mining contract is claimed after 24h, the selected mined asset is credited to that asset balance.
- Deposit manual report flow/cache version reviewed and bumped to v38.
