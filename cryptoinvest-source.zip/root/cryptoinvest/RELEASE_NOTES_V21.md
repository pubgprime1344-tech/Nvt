# V21 - Multi-language support

- Added a broader language selector with English, Persian, Arabic, Turkish, Kurdish, Russian, French, German, Spanish, Italian, Portuguese, Chinese, Japanese, Korean, Hindi, Urdu and more.
- Persian remains native/local translation with RTL layout.
- Other languages use automatic page translation via Google Translate widget.
- Cleaned Google Translate UI artifacts and kept the NVT language selector compact for mobile.
- Updated PWA cache version to v21.

Note: automatic languages depend on Google Translate availability in the visitor's browser/network. English and Persian do not depend on Google Translate.
