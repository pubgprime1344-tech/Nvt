# Release Notes V25

## Lucky Wheel prize update
- Updated Lucky Wheel prizes:
  - 5 USDT
  - 7 USDT
  - 10 USDT
  - 16 USDT
  - 25 USDT
  - Extra Spin
  - iPhone 17
  - Washer
  - Refrigerator
- Removed FK-style rewards.
- Physical prizes (iPhone, washer, refrigerator) are display-only with 0% win chance.
- Big USDT reward odds are much lower than small rewards.
- Removed the NVT text from the wheel center.
- Moved prize icons/text closer to the middle of each wheel segment.
- Added a refrigerator image.
- Improved prize artwork and mobile positioning.
- Bumped Lucky Wheel assets to v25.
