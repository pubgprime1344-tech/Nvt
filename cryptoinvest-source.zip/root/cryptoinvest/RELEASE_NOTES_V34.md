# V34 — N-VT Miner Rebrand

- Full UI rebrand from NVT NexaVest to N-VT Miner.
- Bottom gold Trade tab changed to Mine.
- Added `/mine` page and redirected `/trade` to `/mine`.
- Mining assets: BTC, ETH, DOGE, USDT.
- Mining plans:
  - 100 USDT → 30 USDT / 24h
  - 200 USDT → 60 USDT / 24h
  - 500 USDT → 140 USDT / 24h
  - 1000 USDT → 300 USDT / 24h
  - 1500 USDT → 500 USDT / 24h + 1 wheel spin
- 24h mining cycles are stored in the database and are not reset by updates.
- Live profit animation is shown during mining.
- Principal + mining profit is credited after 24 hours when the user opens dashboard/mine/history.
- Referral mining boost added: 1/3/5/10/20/50 active referrals.
- Lucky wheel prizes changed to miner prize list, with large prizes display-only unless enabled later.
- Cache version updated to v35.
