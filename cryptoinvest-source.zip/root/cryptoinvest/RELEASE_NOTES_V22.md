# V22 - Trade All Button

- Added an **All / همه** button to the AI Auto Trade amount field.
- The button fills the trade amount with the user's full available wallet balance.
- Added validation when the balance is below the 50 USDT minimum trade amount.
- Updated CSS and PWA cache version to v22.
- No new npm package was added; `npm install` is not required when updating from v21/v20.
