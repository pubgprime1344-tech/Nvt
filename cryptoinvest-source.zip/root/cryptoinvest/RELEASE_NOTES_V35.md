# N-VT Miner v35

- Added live asset prices on Mine page for BTC, ETH, DOGE, USDT.
- Mining contracts now open a proper investment modal.
- Active contracts show spinning mining animation, live profit, countdown and manual End Contract & Claim button.
- After 24h, user must claim the contract; mined asset is credited as the selected asset.
- Added crypto balances for BTC/ETH/DOGE and conversion to USDT.
- Withdraw page supports selecting withdrawal asset.
- Wheel weights updated: 1.30=70, 1.60=30, 7=20; other prizes display-only.
- Cache version v35.
