# BEP20 Mainnet Shadow Guide

This release must run with:

- `BEP20_SHADOW_MODE=true`
- `BEP20_CREDIT_ENABLED=false`
- `BEP20_SWEEP_ENABLED=false`
- `BEP20_PUBLIC_ENABLED=false`

Only the admin account receives an automatic deposit address. Detected transfers are recorded as `shadow_detected` and never credit balances.
