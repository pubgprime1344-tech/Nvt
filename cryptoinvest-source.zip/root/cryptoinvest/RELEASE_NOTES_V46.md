# Release V46 — Duplicate TX Hash Protection

- Prevents the same deposit TX hash from being submitted more than once.
- Checks both credited deposits and every previous deposit request status.
- Duplicate comparison is case-insensitive.
- Duplicate check and insert run in one immediate SQLite transaction to prevent double-click/race duplicates.
- User receives the Persian message: «این هش قبلاً وارد شده است و امکان ثبت دوباره آن وجود ندارد.»
- No user records or existing database data are deleted or reset.
