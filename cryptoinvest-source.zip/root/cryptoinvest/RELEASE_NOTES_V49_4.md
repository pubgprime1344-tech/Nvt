# N-VT Miner V49.4

## Dashboard and notification changes
- Removed the visible dashboard KYC-completion warning entirely.
- Moved Deposit and Withdraw actions to the very top of the dashboard.
- Miner plan/profit popup now opens once on every dashboard entry or page reload.
- Added the 50 USDT Starter Miner to the dashboard plan preview and popup fallback data.
- Disabled the Lucky Wheel promotional popup.
- Automatically removes and permanently hides the old Lucky Spin / Wheel "coming soon" broadcast without deleting real wheel reward notifications.

## Mining page stability
- Mining plans render immediately from safe built-in fallback data, including on slower or unstable devices.
- Mining dashboard, plans, and history now load independently with automatic retries, so one failed request does not blank the whole page.
- Added automatic reconnection notice instead of the generic "Failed to load mining page" error.
- Service worker no longer handles the `/mine` page, preventing stale cached mining HTML on older devices.

## Automatic mining settlement
- Manual claim buttons and manual-claim wording were removed from the mining page.
- Completed 24-hour mining contracts are settled automatically every minute, even while the user is offline.
- Opening the mining page also immediately checks and settles any matured contract.
- Principal returns to the stored Miner Balance and the saved contract profit is credited using the original database values.
- Each automatically completed contract creates one targeted notification for the user.
- Auto-completion notifications are marked read after first display to prevent repeated popups.

## Data safety
- Existing active and completed mining contracts are not recalculated.
- Stored `amount`, `profit_percentage`, `profit_amount`, `created_at`, progress, and asset values remain unchanged.
- No database file is included in this package. Deployment must preserve the existing `cryptoinvest.db`, `.env`, and `uploads` directory.
- Minimum deposit remains 50 USDT and the 50 USDT Starter Miner remains enabled.
