# V43 Deposit no-wait final fix

- Deposit manual report now uses no-wait submit behavior.
- No explorer checks.
- Button unlocks immediately on mobile/PWA.
- Request is sent in background via sendBeacon/fetch keepalive.
