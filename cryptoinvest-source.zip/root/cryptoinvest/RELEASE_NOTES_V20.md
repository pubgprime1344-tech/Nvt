# NVT NexaVest v20

- Minimum withdrawal is now 100 USDT on the backend and frontend.
- Added per-user admin control to disable or re-enable the 5-day withdrawal lock.
- Added `withdraw_lock_disabled` database migration for existing databases.
- Updated the mobile bottom Trade tab to a stronger gold dollar icon.
- Improved Persian labels for mobile tabs, quick menu, admin/user menus, withdrawal text, and lock controls.
- Rebuilt the PWA icon with a more modern NVT branded design.
- Updated PWA cache/version to v20.
- Cleaned package-lock registry URLs so future npm installs use the public npm registry.

No new npm packages were added in this version.
