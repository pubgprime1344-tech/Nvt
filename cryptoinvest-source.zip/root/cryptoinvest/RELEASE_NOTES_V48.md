# V48

- Removed the full-page reload/redirect after manual deposit submission.
- Deposit success and duplicate messages now stay inside the current page.
- Prevents the global “Opening NVT” loader from trapping the PWA.
- Keeps duplicate TX hash protection.
- Does not modify or reset the database.
