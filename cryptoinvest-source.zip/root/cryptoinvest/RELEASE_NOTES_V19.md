# V19 - Mobile header and PWA icon fix

- Fixed blank/white PWA home-screen icon by adding new NVT PNG icons.
- Removed duplicate top Menu / hamburger buttons on mobile.
- Kept the mobile bottom More button as the full app menu.
- Kept one compact Menu button on desktop/tablet only.
- Bumped cache version to v19 to reduce stale PWA cache issues.
