# N-VT Miner V50 Stable — BEP20 RPC Failover

- Replaced ethers provider log polling with raw JSON-RPC calls.
- Added multiple RPC endpoint failover through `BEP20_RPC_URLS`.
- Added request timeout, retry, backoff, block-range splitting, and per-address destination filtering.
- Cursor advances only after a full successful scan.
- Transient RPC failures are rate-limited to one warning per minute instead of flooding PM2 logs.
- Mainnet Shadow safety remains enforced: credit and sweep are disabled in this build.
- Existing database, users, balances, mining contracts, uploads and `.env` are not included in the archive and must be preserved during deployment.
