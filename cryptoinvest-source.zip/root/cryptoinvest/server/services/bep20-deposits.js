const { ethers } = require('ethers');

const TRANSFER_TOPIC = ethers.id('Transfer(address,address,uint256)');

function boolEnv(name, fallback = false) {
    const value = process.env[name];
    if (value === undefined) return fallback;
    return ['1', 'true', 'yes', 'on'].includes(String(value).trim().toLowerCase());
}

function intEnv(name, fallback) {
    const value = Number.parseInt(process.env[name] || '', 10);
    return Number.isFinite(value) ? value : fallback;
}

function numberEnv(name, fallback) {
    const value = Number.parseFloat(process.env[name] || '');
    return Number.isFinite(value) ? value : fallback;
}

function normalizeAddress(value) {
    try {
        return ethers.getAddress(String(value || '').trim());
    } catch (_) {
        return null;
    }
}

class Bep20DepositService {
    constructor(database) {
        this.database = database;
        this.db = database.db;
        this.running = false;
        this.timer = null;

        this.enabled = boolEnv('BEP20_AUTO_DEPOSIT_ENABLED', false);
        this.network = String(process.env.BEP20_NETWORK || 'mainnet').trim().toLowerCase();
        this.chainId = intEnv('BEP20_CHAIN_ID', 56);
        this.rpcUrls = String(process.env.BEP20_RPC_URLS || process.env.BEP20_RPC_URL || '')
            .split(',')
            .map(value => value.trim())
            .filter(Boolean);
        this.rpcIndex = 0;
        this.rpcTimeoutMs = Math.max(3000, intEnv('BEP20_RPC_TIMEOUT_MS', 12000));
        this.lastRpcWarningAt = 0;
        this.shadowMode = boolEnv('BEP20_SHADOW_MODE', true);
        this.creditEnabled = boolEnv('BEP20_CREDIT_ENABLED', false);
        this.publicEnabled = boolEnv('BEP20_PUBLIC_ENABLED', false);
        this.treasuryAddress = normalizeAddress(process.env.BEP20_TREASURY_ADDRESS);
        this.gasWalletAddress = normalizeAddress(process.env.BEP20_GAS_WALLET_ADDRESS);
        this.tokenAddress = normalizeAddress(process.env.BEP20_TOKEN_CONTRACT);
        this.tokenSymbol = String(process.env.BEP20_TOKEN_SYMBOL || 'USDT').trim().toUpperCase();
        this.tokenDecimals = intEnv('BEP20_TOKEN_DECIMALS', 18);
        this.depositXpub = String(process.env.BEP20_DEPOSIT_XPUB || '').trim();
        this.minimumDeposit = numberEnv('BEP20_MIN_DEPOSIT_USDT', 50);
        this.depositFee = numberEnv('DEPOSIT_FEE_USDT', 1);
        this.scanIntervalMs = Math.max(5000, intEnv('BEP20_SCAN_INTERVAL_MS', 15000));
        this.scanChunk = Math.min(500, Math.max(1, intEnv('BEP20_SCAN_CHUNK', 5)));
        this.maxRpcRetries = Math.min(5, Math.max(1, intEnv('BEP20_RPC_MAX_RETRIES', 3)));
        this.rpcRetryDelayMs = Math.max(500, intEnv('BEP20_RPC_RETRY_DELAY_MS', 1500));
        this.fallbackConfirmations = Math.max(2, intEnv('BEP20_FALLBACK_CONFIRMATIONS', 120));
        this.startBlock = String(process.env.BEP20_START_BLOCK || 'latest').trim().toLowerCase();
        this.initialLookbackBlocks = Math.max(0, intEnv('BEP20_INITIAL_LOOKBACK_BLOCKS', 5000));

        // Mainnet shadow release: detection only. Credit and sweep remain disabled by design.
        if (this.enabled && (this.network !== 'mainnet' || this.chainId !== 56)) {
            console.error('⛔ BEP20 mainnet shadow requires BEP20_NETWORK=mainnet and BEP20_CHAIN_ID=56.');
            this.enabled = false;
        }

        if (this.enabled && (!this.shadowMode || this.creditEnabled)) {
            console.error('⛔ This release is SHADOW-ONLY. Keep BEP20_SHADOW_MODE=true and BEP20_CREDIT_ENABLED=false.');
            this.enabled = false;
        }

        if (this.enabled && (this.rpcUrls.length === 0 || !this.tokenAddress || !this.depositXpub)) {
            console.error('⛔ BEP20 auto deposit is missing RPC URL, token contract or deposit XPUB; service disabled.');
            this.enabled = false;
        }

        if (this.enabled) {
            try {
                this.publicNode = ethers.HDNodeWallet.fromExtendedKey(this.depositXpub);
                if (!String(this.publicNode.extendedKey || '').startsWith('xpub')) {
                    throw new Error('BEP20_DEPOSIT_XPUB must be an xpub, never an xprv');
                }
                // RPC access is handled by a raw JSON-RPC failover pool below.
            } catch (error) {
                console.error('⛔ Invalid BEP20 auto-deposit configuration:', error.message);
                this.enabled = false;
            }
        }
    }

    isEnabled() {
        return this.enabled;
    }

    publicConfig() {
        return {
            enabled: this.enabled,
            network: this.enabled ? 'bsc_mainnet' : 'manual',
            chain_id: this.enabled ? this.chainId : null,
            token_symbol: this.enabled ? this.tokenSymbol : null,
            token_contract: this.enabled ? this.tokenAddress : null,
            minimum_deposit: this.minimumDeposit,
            automatic_credit: false,
            shadow_mode: this.enabled ? this.shadowMode : false,
            public_enabled: this.enabled ? this.publicEnabled : false,
            sweep_enabled: false,
            phase: this.enabled ? 'mainnet_shadow' : 'manual'
        };
    }

    getOrCreateAccount(userId) {
        if (!this.enabled) return null;

        const existing = this.db.prepare(`
            SELECT user_id, derivation_index, address, created_at
            FROM bep20_deposit_accounts
            WHERE user_id = ?
        `).get(userId);
        if (existing) return existing;

        let created = null;
        const createAccount = this.db.transaction(() => {
            const secondCheck = this.db.prepare(`
                SELECT user_id, derivation_index, address, created_at
                FROM bep20_deposit_accounts
                WHERE user_id = ?
            `).get(userId);
            if (secondCheck) {
                created = secondCheck;
                return;
            }

            const next = this.db.prepare(`
                SELECT COALESCE(MAX(derivation_index), -1) + 1 AS next_index
                FROM bep20_deposit_accounts
            `).get();
            const derivationIndex = Number(next?.next_index || 0);
            const child = this.publicNode.deriveChild(derivationIndex);
            const address = ethers.getAddress(child.address);

            this.db.prepare(`
                INSERT INTO bep20_deposit_accounts (user_id, derivation_index, address)
                VALUES (?, ?, ?)
            `).run(userId, derivationIndex, address);

            this.db.prepare(`
                UPDATE users
                SET bep20_address = ?, wallet_address = ?
                WHERE id = ?
            `).run(address, address, userId);

            created = {
                user_id: userId,
                derivation_index: derivationIndex,
                address,
                created_at: new Date().toISOString()
            };
        });

        if (typeof createAccount.immediate === 'function') createAccount.immediate();
        else createAccount();
        return created;
    }

    getUserStatus(userId) {
        const account = this.getOrCreateAccount(userId);
        const events = this.db.prepare(`
            SELECT tx_hash, log_index, block_number, amount_usdt, status, credited_at, created_at
            FROM bep20_deposit_events
            WHERE user_id = ?
            ORDER BY id DESC
            LIMIT 20
        `).all(userId);
        return { account, events, config: this.publicConfig() };
    }

    rpcHex(value) {
        return `0x${Number(value).toString(16)}`;
    }

    async rawRpc(url, method, params = []) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), this.rpcTimeoutMs);
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: { 'content-type': 'application/json' },
                body: JSON.stringify({ jsonrpc: '2.0', id: Date.now(), method, params }),
                signal: controller.signal
            });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const payload = await response.json();
            if (payload?.error) {
                const message = payload.error.message || JSON.stringify(payload.error);
                const error = new Error(message);
                error.code = payload.error.code;
                throw error;
            }
            return payload?.result;
        } finally {
            clearTimeout(timeout);
        }
    }

    warnRpc(message) {
        const now = Date.now();
        if (now - this.lastRpcWarningAt < 60000) return;
        this.lastRpcWarningAt = now;
        console.warn(`BEP20 RPC warning: ${message}`);
    }

    async rpcCall(method, params = []) {
        let lastError = null;
        const total = this.rpcUrls.length;

        for (let offset = 0; offset < total; offset++) {
            const index = (this.rpcIndex + offset) % total;
            const url = this.rpcUrls[index];
            try {
                const result = await this.rawRpc(url, method, params);
                this.rpcIndex = index;
                return result;
            } catch (error) {
                lastError = error;
                this.rpcIndex = (index + 1) % total;
            }
        }

        throw lastError || new Error(`All ${total} BEP20 RPC endpoints failed`);
    }

    async getFinalizedHeight() {
        const latestHex = await this.rpcCall('eth_blockNumber');
        const latest = Number(BigInt(latestHex));
        return Math.max(0, latest - this.fallbackConfirmations);
    }

    cursorKey() {
        return `bep20:${this.chainId}:${String(this.tokenAddress).toLowerCase()}:last_scanned_block`;
    }

    getCursor() {
        const row = this.db.prepare('SELECT value FROM blockchain_cursors WHERE key = ?').get(this.cursorKey());
        if (!row) return null;
        const value = Number.parseInt(row.value, 10);
        return Number.isFinite(value) ? value : null;
    }

    setCursor(blockNumber) {
        this.db.prepare(`
            INSERT INTO blockchain_cursors (key, value, updated_at)
            VALUES (?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP
        `).run(this.cursorKey(), String(blockNumber));
    }

    async initializeCursor(finalizedHeight) {
        if (this.getCursor() !== null) return;
        let initial = Math.max(0, finalizedHeight - this.initialLookbackBlocks);
        if (/^\d+$/.test(this.startBlock)) initial = Math.min(finalizedHeight, Number(this.startBlock));
        this.setCursor(initial);
        console.log(`🔎 BEP20 watcher cursor initialized at block ${initial}.`);
    }

    accountMap() {
        const rows = this.db.prepare('SELECT user_id, address FROM bep20_deposit_accounts').all();
        const map = new Map();
        for (const row of rows) {
            const address = normalizeAddress(row.address);
            if (address) map.set(address.toLowerCase(), Number(row.user_id));
        }
        return map;
    }

    creditLog(log, userId) {
        const logIndex = Number(log.index ?? log.logIndex ?? 0);
        const txHash = String(log.transactionHash || '').toLowerCase();
        const amountText = ethers.formatUnits(BigInt(log.data), this.tokenDecimals);
        const grossAmount = Number(amountText);
        if (!Number.isFinite(grossAmount) || grossAmount <= 0) return;

        const toAddress = ethers.getAddress(`0x${String(log.topics[2]).slice(-40)}`);
        const eventExists = this.db.prepare(`
            SELECT id FROM bep20_deposit_events
            WHERE chain_id = ? AND tx_hash = ? AND log_index = ?
        `).get(this.chainId, txHash, logIndex);
        if (eventExists) return;

        const processDeposit = this.db.transaction(() => {
            this.db.prepare(`
                INSERT INTO bep20_deposit_events
                (chain_id, tx_hash, log_index, block_number, user_id, to_address, token_address, raw_amount, amount_usdt, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'detected')
            `).run(
                this.chainId,
                txHash,
                logIndex,
                Number(log.blockNumber),
                userId,
                toAddress,
                this.tokenAddress,
                String(BigInt(log.data)),
                grossAmount
            );

            if (this.shadowMode) {
                this.db.prepare(`
                    UPDATE bep20_deposit_events
                    SET status = ?
                    WHERE chain_id = ? AND tx_hash = ? AND log_index = ?
                `).run(
                    grossAmount < this.minimumDeposit ? 'shadow_below_minimum' : 'shadow_detected',
                    this.chainId,
                    txHash,
                    logIndex
                );
                return;
            }

            if (grossAmount < this.minimumDeposit) {
                this.db.prepare(`
                    UPDATE bep20_deposit_events SET status = 'below_minimum'
                    WHERE chain_id = ? AND tx_hash = ? AND log_index = ?
                `).run(this.chainId, txHash, logIndex);
                return;
            }

            const alreadyCredited = this.db.prepare(`
                SELECT tx_hash FROM known_deposits WHERE tx_hash = ? COLLATE NOCASE
            `).get(txHash);
            if (alreadyCredited) {
                this.db.prepare(`
                    UPDATE bep20_deposit_events SET status = 'duplicate'
                    WHERE chain_id = ? AND tx_hash = ? AND log_index = ?
                `).run(this.chainId, txHash, logIndex);
                return;
            }

            const netAmount = Math.max(0, grossAmount - this.depositFee);
            const before = this.db.prepare(`
                SELECT COALESCE(total_deposit, 0) AS total_deposit
                FROM users WHERE id = ?
            `).get(userId);

            this.db.prepare(`
                INSERT INTO known_deposits (tx_hash, user_id, amount)
                VALUES (?, ?, ?)
            `).run(txHash, userId, grossAmount);

            const pending = this.db.prepare(`
                SELECT id FROM transactions
                WHERE type = 'deposit' AND tx_hash = ? COLLATE NOCASE
                ORDER BY id DESC LIMIT 1
            `).get(txHash);

            if (pending) {
                this.db.prepare(`
                    UPDATE transactions
                    SET amount = ?, net_amount = ?, status = 'completed',
                        description = 'Automatically verified BEP20 mainnet deposit', network = 'bep20'
                    WHERE id = ?
                `).run(grossAmount, netAmount, pending.id);
            } else {
                this.db.prepare(`
                    INSERT INTO transactions
                    (user_id, type, amount, net_amount, status, tx_hash, description, network)
                    VALUES (?, 'deposit', ?, ?, 'completed', ?, 'Automatically verified BEP20 mainnet deposit', 'bep20')
                `).run(userId, grossAmount, netAmount, txHash);
            }

            this.db.prepare(`
                UPDATE users
                SET wallet_balance = COALESCE(wallet_balance, 0) + ?,
                    total_deposit = COALESCE(total_deposit, 0) + ?
                WHERE id = ?
            `).run(netAmount, netAmount, userId);

            if (typeof this.database.awardFirstDepositWheelSpin === 'function') {
                this.database.awardFirstDepositWheelSpin(userId, grossAmount, before?.total_deposit || 0);
            }
            if (typeof this.database.awardReferralBonus === 'function') {
                this.database.awardReferralBonus(userId, netAmount, txHash, 'bep20 automatic mainnet deposit');
            }

            this.db.prepare(`
                INSERT INTO notifications
                (target_user_id, title, title_fa, message, message_fa, type)
                VALUES (?, 'Deposit confirmed', 'واریز تأیید شد', ?, ?, 'success')
            `).run(
                userId,
                `${netAmount} ${this.tokenSymbol} was automatically credited to your balance.`,
                `مبلغ ${netAmount} ${this.tokenSymbol} به‌صورت خودکار به موجودی شما اضافه شد.`
            );

            this.db.prepare(`
                UPDATE bep20_deposit_events
                SET status = 'credited', credited_at = CURRENT_TIMESTAMP
                WHERE chain_id = ? AND tx_hash = ? AND log_index = ?
            `).run(this.chainId, txHash, logIndex);
        });

        if (typeof processDeposit.immediate === 'function') processDeposit.immediate();
        else processDeposit();
        console.log(`✅ BEP20 deposit credited: user=${userId} amount=${grossAmount} tx=${txHash}`);
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    isRpcLimitError(error) {
        const message = String(error?.shortMessage || error?.message || error || '').toLowerCase();
        return message.includes('limit exceeded') ||
            message.includes('query returned more than') ||
            message.includes('response size exceeded') ||
            message.includes('block range') ||
            message.includes('too many results') ||
            message.includes('timeout') ||
            message.includes('timed out') ||
            message.includes('request aborted') ||
            message.includes('http 429') ||
            message.includes('http 503');
    }

    async getAddressLogs(addressLower, fromBlock, toBlock, attempt = 1) {
        const destinationTopic = ethers.zeroPadValue(ethers.getAddress(addressLower), 32);
        const filter = {
            address: this.tokenAddress,
            topics: [TRANSFER_TOPIC, null, destinationTopic],
            fromBlock: this.rpcHex(fromBlock),
            toBlock: this.rpcHex(toBlock)
        };

        try {
            const logs = await this.rpcCall('eth_getLogs', [filter]);
            return Array.isArray(logs) ? logs : [];
        } catch (error) {
            if (fromBlock < toBlock) {
                const middle = Math.floor((fromBlock + toBlock) / 2);
                const left = await this.getAddressLogs(addressLower, fromBlock, middle, 1);
                const right = await this.getAddressLogs(addressLower, middle + 1, toBlock, 1);
                return [...left, ...right];
            }

            if (attempt < this.maxRpcRetries) {
                await this.sleep(this.rpcRetryDelayMs * attempt);
                return this.getAddressLogs(addressLower, fromBlock, toBlock, attempt + 1);
            }

            throw error;
        }
    }

    async scanOnce() {
        if (!this.enabled || this.running) return;
        this.running = true;
        try {
            const chainHex = await this.rpcCall('eth_chainId');
            const rpcChainId = Number(BigInt(chainHex));
            if (rpcChainId !== this.chainId) {
                throw new Error(`RPC chain mismatch: expected ${this.chainId}, got ${rpcChainId}`);
            }

            const finalizedHeight = await this.getFinalizedHeight();
            await this.initializeCursor(finalizedHeight);
            let cursor = this.getCursor();
            if (cursor === null || cursor >= finalizedHeight) return;

            const accounts = this.accountMap();
            if (accounts.size === 0) return;

            while (cursor < finalizedHeight) {
                const fromBlock = cursor + 1;
                const toBlock = Math.min(finalizedHeight, cursor + this.scanChunk);

                for (const [addressLower, userId] of accounts.entries()) {
                    const logs = await this.getAddressLogs(addressLower, fromBlock, toBlock);
                    for (const log of logs) {
                        if (log.removed) continue;
                        this.creditLog(log, userId);
                    }
                }

                // Cursor advances only after every watched address in the range
                // has completed successfully, so failed requests cannot skip funds.
                this.setCursor(toBlock);
                cursor = toBlock;
            }
        } catch (error) {
            this.warnRpc(error.shortMessage || error.message || String(error));
        } finally {
            this.running = false;
        }
    }

    start() {
        if (!this.enabled || this.timer) return;
        console.log(`🔎 BEP20 mainnet SHADOW watcher enabled with ${this.rpcUrls.length} RPC endpoint(s) (chain ${this.chainId}); credit and sweep are disabled.`);
        setTimeout(() => this.scanOnce(), 3000);
        this.timer = setInterval(() => this.scanOnce(), this.scanIntervalMs);
        if (typeof this.timer.unref === 'function') this.timer.unref();
    }

    stop() {
        if (this.timer) clearInterval(this.timer);
        this.timer = null;
    }
}

module.exports = Bep20DepositService;
