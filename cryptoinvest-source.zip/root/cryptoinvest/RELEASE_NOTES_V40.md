# V40 Convert Balance Fix

- Fixed Convert page showing USDT as zero when the user had miner/rental USDT balance.
- Convert page now shows Total USDT, Miner USDT, and Withdrawable USDT separately.
- Conversion still only converts mined BTC/ETH/DOGE to withdrawable USDT.
- Cache version updated to v40.
