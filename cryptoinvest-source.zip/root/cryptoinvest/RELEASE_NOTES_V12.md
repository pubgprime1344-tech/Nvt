# NVT NexaVest v12

Changes in this build:

- Real KYC document upload using multipart/form-data.
- KYC files are stored under `uploads/kyc/` and are not publicly exposed.
- Admin can view submitted KYC documents from a protected admin-only route.
- New dedicated admin KYC page: `/admin-kyc`.
- New dedicated admin deposits page: `/admin-deposits`.
- Existing withdrawal page now also shows full withdrawal history.
- User notifications page: `/notifications`.
- Admin notification sender page: `/admin-notifications`.
- Admin can send broadcast notifications or single-user notifications by email, NVT User ID, or internal user ID.
- User top navigation shows a notifications option and unread badge.
- KYC approval/rejection, deposit approval/rejection and withdrawal approval/rejection create user notifications.

Important file locations:

- Database: `cryptoinvest.db`
- KYC uploads: `uploads/kyc/`
- Environment config: `.env`

For backups, include the database, `.env`, and `uploads/`.
