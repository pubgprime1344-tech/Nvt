# NexaVest - پلتفرم سرمایه‌گذاری کریپتو

## 1. Concept & Vision

یک پلتفرم سرمایه‌گذاری کریپتو با طراحی مدرن و تاریک که حس اعتماد و حرفه‌ای بودن رو القا می‌کنه. کاربران می‌تونن با ثبت‌نام، کیف‌پول اختصاصی داشته باشند، روزانه ترید کنند و سود بگیرند. سیستم رفرال برای جذب کاربران جدید.

## 2. Design Language

### Aesthetic Direction
- **Style**: Dark futuristic finance theme با گرادیان‌های آبی-بنفش
- **Mood**: Trust, Professional, Modern, High-tech

### Color Palette
```
Primary:     #6366f1 (Indigo)
Secondary:   #8b5cf6 (Purple)
Accent:      #22c55e (Green for profit)
Danger:      #ef4444 (Red for loss)
Background:  #0f172a (Dark Navy)
Surface:     #1e293b (Card Background)
Text:        #f8fafc (White)
Text Muted:  #94a3b8 (Gray)
```

### Typography
- **Headings**: Inter (700)
- **Body**: Inter (400, 500)
- **Numbers**: JetBrains Mono (monospace for prices)

### Motion
- Smooth page transitions
- Subtle hover effects on cards
- Animated counter for profits
- Gradient animations on hero section

## 3. Layout & Structure

### Pages
1. **Landing Page** - Hero, Features, Stats
2. **Login/Register** - با فرم‌های مدرن
3. **Dashboard** - Overview, Wallet, Trading
4. **Deposit** - کیف‌پول‌های TRC20/BEP20
5. **Withdraw** - درخواست برداشت
6. **Trade** - رابط ترید روزانه
7. **Referral** - کد رفرال و جوایز
8. **KYC** - احراز هویت
9. **Admin Panel** - مدیریت کاربران و برداشت‌ها

### Navigation
- Fixed top navbar با logo و user menu
- Responsive sidebar برای mobile
- Breadcrumb برای track location

## 4. Features & Interactions

### Authentication
- Email/Password registration
- Mandatory referral code (admin code for first user)
- Auto-generated referral code per user
- KYC verification (basic: name, phone, ID upload)

### Wallet System
- Auto-generated TRC20 address per user
- Auto-generated BEP20 address per user
- Balance display with USDT
- Deposit history
- Internal transfers

### Daily Trading
- 3 trades per day allowed
- Fixed profit percentage (configurable: 0.5-2%)
- Trade timer countdown
- Trade history with results
- Profit auto-added to wallet

### Referral System
- Unique referral code per user
- Referral reward: 10% of verified deposit
- Multi-level commission (optional)
- Referral statistics

### Withdrawal
- Request withdrawal to external wallet
- Admin approval required
- Transaction history
- Minimum withdrawal limits

## 5. Component Inventory

### Cards
- Stat cards (gradient border, icon, number)
- Trade cards (pair, profit %, timer)
- Wallet card (address, copy button, QR)
- Transaction card (type, amount, status, date)

### Buttons
- Primary (gradient background)
- Secondary (outline)
- Disabled state
- Loading state

### Forms
- Input fields with floating labels
- Validation feedback
- File upload for KYC
- Address input with chain selector

### Tables
- Transaction history
- User list (admin)
- Withdrawal requests (admin)

## 6. Technical Approach

### Stack
- **Frontend**: Vanilla HTML/CSS/JS (SPA-like)
- **Backend**: Node.js + Express
- **Database**: SQLite
- **Crypto**: tronweb (TRC20), ethers.js (BEP20)

### API Endpoints
```
POST   /api/auth/register
POST   /api/auth/login
GET    /api/user/profile
POST   /api/user/kyc
GET    /api/wallet/address
GET    /api/wallet/balance
POST   /api/wallet/deposit/callback (webhook simulation)
GET    /api/trade/daily-trades
POST   /api/trade/execute
GET    /api/referral/code
GET    /api/referral/stats
POST   /api/withdraw/request
GET    /api/withdraw/history
```

### Admin Endpoints
```
GET    /api/admin/users
GET    /api/admin/withdrawals
POST   /api/admin/withdrawals/:id/approve
POST   /api/admin/withdrawals/:id/reject
```

## 7. Additional Features

### Notifications
- Real-time notifications
- Trade results
- Withdrawal status
- Deposit confirmations

### Security
- Password hashing
- JWT tokens
- Rate limiting
- Input validation

### Statistics Dashboard
- Total users
- Total deposits
- Total withdrawals
- Active trades
- Profit distribution
