# N-VT Miner v37

- Admin can enable/disable referral withdrawal requirement globally.
- Admin can bulk disable/enable referral withdrawal requirement for all users.
- Admin can disable/enable referral withdrawal requirement for a single user from Admin Users.
- Withdrawal page hides restriction text/card when limits are disabled.
- KYC requirement for withdrawals is now globally manageable from Admin Withdrawals.
- Mining contract funds/profit are only added after the user manually claims a finished 24h contract.
- Cache version bumped to v37.
