# N-VT Miner v39

- Referral deposit commission is fixed at 10%.
- Referral commission is credited to withdrawable USDT, not locked miner balance.
- Successful referred deposit gives 1 lucky wheel spin to the referrer and 1 to the referred user.
- Mining claim now returns principal to locked Miner Balance and credits only the profit as withdrawable/asset profit.
- USDT withdrawals use Withdrawable USDT only. Deposit principal remains locked for renting miners.
- Crypto conversion sends BTC/ETH/DOGE mined profit to Withdrawable USDT.
- Active mining contracts remain database-based and continue after updates.
