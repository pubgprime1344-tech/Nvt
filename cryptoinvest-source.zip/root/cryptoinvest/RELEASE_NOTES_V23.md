# NVT NexaVest v23 - Lucky Wheel + Notification Popups

Changes:
- Added in-app popup when users have unread admin notifications or support messages.
- Notification API now supports Persian title/message fields and returns localized fields when the user language is Persian.
- Admin notification form now includes optional Persian title/message.
- Added Lucky Wheel campaign page at `/lucky-wheel`.
- Added admin Lucky Wheel management page at `/admin-wheel`.
- Admin can enable/disable the wheel campaign and promo popup.
- Admin can add, remove, or set wheel spin chances per user.
- A referred user making a qualifying verified deposit grants the inviter 1 Lucky Wheel chance.
- Lucky Wheel rewards: 5, 7, 10, 25 USDT, Extra Spin, plus display-only premium prizes.
- Cash wheel rewards credit user balance automatically and log a transaction.
- Wheel promo popup appears to users on app entry when campaign is active.
- Added wheel links to user/admin menus.
- Added mobile overflow hardening to reduce page width/zoom bugs.
- Cache version updated to v23.

No new npm packages were added.
