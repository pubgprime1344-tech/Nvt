# Release Notes V27

## Lucky Wheel fixes
- Fixed the wheel landing mismatch: the wheel now calls the backend first and animates to the exact prize slice returned by the backend.
- Display-only physical prizes (iPhone 17, Washer, Refrigerator) have zero backend weight and the frontend no longer visually lands on them for a cash result.
- Upgraded wheel graphics with premium neon rim, sharper hub, stronger glow, better prize placement, and clearer cash result card.
- Removed NVT text from the wheel center and replaced it with a clean premium glowing hub.
- Removed display-only tag text from physical prize labels.
- Updated cache version to v27.

## Deployment
No new npm packages. `npm install` is not required.
