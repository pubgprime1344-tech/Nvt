# V41 - Final deposit manual + withdraw UI fixes

- Removed explorer/blockchain auto-check code from deposit route.
- Deposit report is now fully manual: amount + TX hash goes directly to admin pending list.
- Deposit form no longer freezes; server response is handled with timeout and UI always unlocks.
- Withdraw information items 4, 5 and 6 removed.
- Added mobile layout fixes for withdrawal form/buttons/history table.
- Cache version bumped to v42.
