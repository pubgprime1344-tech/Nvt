# NVT NexaVest v14

## Changes
- Trade profit ranges adjusted to half of the earlier high-profit table:
  - VIP 1: 0.5% - 1%
  - VIP 2: 0.75% - 1.25%
  - VIP 3: 1% - 1.5%
  - VIP 4: 1.25% - 1.75%
  - VIP 5: 1.5% - 2%
  - VIP 6: 2% - 2.5%
- Admin withdrawal approve/reject actions fixed.
- Added direct approve/reject action buttons on /admin-withdrawals.
- Added visible error messages when a withdrawal action fails.
- Added backend guard to prevent double-processing an already approved/rejected withdrawal.

## Upgrade note
Keep your existing .env, cryptoinvest.db, and uploads directory when upgrading.
