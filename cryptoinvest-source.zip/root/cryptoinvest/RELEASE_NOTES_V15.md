# Release Notes V15

- VIP profit ranges now increase more clearly at higher levels:
  - VIP 1: 0.5% - 1%
  - VIP 2: 1% - 1.5%
  - VIP 3: 1.5% - 2.1%
  - VIP 4: 2% - 2.7%
  - VIP 5: 2.5% - 3.2%
  - VIP 6: 3% - 4%
- Backend trade calculation, user dashboard API, VIP page, and landing display are synchronized.
