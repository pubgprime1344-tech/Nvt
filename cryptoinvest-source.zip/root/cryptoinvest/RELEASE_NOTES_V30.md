# Release Notes V30

## Deposit QR Codes
- Added exact QR code images for TRC20 and BEP20 deposit addresses.
- TRC20 QR encodes: `TFVSKHiakSiSMR7VyGjDzWxfPSPnSSwNPg`
- BEP20 QR encodes: `0xe410bbb0dafee7879626382ddfc40223040c8a06`
- Added clean white QR cards under each deposit address.

## Deposit report message
- When explorer verification is unavailable, the deposit report is now registered as pending for admin review.
- The user sees a green success message instead of a red explorer error.
- New message: `درخواست شما به مدیریت ارسال گردید. ۱ تا ۱۰ ساعت آینده پول به حساب اکانت شما واریز خواهد شد.`

## Cache
- Updated frontend cache version to `v30-deposit-qr`.
