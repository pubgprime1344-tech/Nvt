# NVT NexaVest v33 — Withdrawal Limits + Deposit Freeze Fix

## Fixed
- Deposit report button no longer stays locked on mobile/PWA.
- Deposit report UI is released immediately and request is sent in background with XHR.
- Cache/service worker version bumped to v33.

## Added
- Global withdrawal limit settings in admin withdrawals panel.
- Admin can enable/disable withdrawal limits.
- Admin can require active referral before withdrawal.
- Admin can set minimum active referrals.
- Admin can set minimum deposit amount for referral to count as active.
- Admin can set weekly withdrawal percentage and weekly window days.
- Default: user needs 1 active referral with deposit >= 100 USDT.
- Default: user can withdraw 33.33% of total weekly base every 7 days.

## Preserved
- Existing manual deposit system remains unchanged.
- Withdrawals remain manual approval by admin.
- Existing database, uploads, .env, node_modules should be preserved during deployment.
