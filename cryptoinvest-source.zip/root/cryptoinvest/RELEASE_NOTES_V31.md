# Release Notes V31

## Deposit report freeze fix
- Deposit TX hash report now submits quickly and immediately creates a pending admin-review request.
- Removed slow explorer waits from the user-facing deposit submit path.
- Added duplicate pending/completed TX hash checks.
- User receives the green manual-review message without needing to close/reopen the app.

## Iran midnight trade reset
- Daily trade usage is now calculated by Iran date (`Asia/Tehran`) instead of UTC.
- Trade counter resets at 00:00 Iran time.
- Today’s trade usage is derived from the `trades` table, so it survives server restarts and source-code updates as long as `cryptoinvest.db` is preserved.
- One-trade-per-pair-per-day also uses Iran date.

## Cache
- Asset/cache version bumped to v31.
