# V49.6 — BEP20 Mainnet Shadow

- BSC Mainnet chain 56 detection-only mode.
- Admin-only dedicated deposit address while public mode is disabled.
- No balance credit and no sweep in this release.
- Mainnet USDT/BSC-USD contract allowlisted.
- Existing database, users, miners, balances and manual deposits remain unchanged.
