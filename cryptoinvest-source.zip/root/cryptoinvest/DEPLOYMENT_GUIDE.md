# NVT NexaVest Deployment / Update Guide

## Clean install

```bash
sudo -i
cd /root
unzip nvt-nexavest-final-v13-support-tickets.zip -d cryptoinvest
cd cryptoinvest
npm install
pm2 start server.js --name cryptoinvest
pm2 save
```

## Safe update without losing database/uploads/.env

Use this when an older `/root/cryptoinvest` already exists and you do not want to lose users, balances, KYC files, notifications, or tickets.

```bash
sudo -i
cd /root

# stop app only
pm2 stop cryptoinvest 2>/dev/null || true
fuser -k 3000/tcp 2>/dev/null || true

# create safety copy of the old app folder
cp -a cryptoinvest cryptoinvest_backup_$(date +%F_%H-%M) 2>/dev/null || true

# unpack new version into temp folder
rm -rf cryptoinvest_new
unzip nvt-nexavest-final-v13-support-tickets.zip -d cryptoinvest_new

# preserve live data from old version
cp -f cryptoinvest/.env cryptoinvest_new/.env 2>/dev/null || true
cp -f cryptoinvest/cryptoinvest.db cryptoinvest_new/cryptoinvest.db 2>/dev/null || true
cp -a cryptoinvest/uploads cryptoinvest_new/uploads 2>/dev/null || true

# replace app code
mv cryptoinvest cryptoinvest_old_$(date +%F_%H-%M)
mv cryptoinvest_new cryptoinvest

cd cryptoinvest
npm install
pm2 start server.js --name cryptoinvest
pm2 save
pm2 logs cryptoinvest --lines 80
```

## New pages

- `/support`
- `/tickets`
- `/admin-tickets`
- `/admin-kyc`
- `/admin-deposits`
- `/admin-withdrawals`
- `/admin-notifications`

## Data locations

```text
/root/cryptoinvest/cryptoinvest.db
/root/cryptoinvest/.env
/root/cryptoinvest/uploads/
```

KYC files are stored in:

```text
/root/cryptoinvest/uploads/kyc/
```
