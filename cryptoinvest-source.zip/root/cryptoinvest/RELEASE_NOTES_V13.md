# NVT NexaVest v13

## Changes
- Compact and cleaner buttons/navigation styling.
- User account area in the top bar opens the Profile page.
- Lower VIP AI Auto Trade profit ranges:
  - VIP 1: 0.12% - 0.22%
  - VIP 2: 0.18% - 0.32%
  - VIP 3: 0.25% - 0.45%
  - VIP 4: 0.35% - 0.60%
  - VIP 5: 0.45% - 0.80%
  - VIP 6: 0.60% - 1.00%
- Admin request count badges for deposits, withdrawals, KYC, and tickets.
- New user Support Center page.
- New user Tickets page.
- New admin Tickets queue.
- Ticket replies and ticket status control.
- Expanded Persian language coverage and RTL support for more screens.
- Existing database, uploads, and .env are preserved when using the safe update commands.

## New routes
- /support
- /tickets
- /admin-tickets

## Important backup files
- cryptoinvest.db
- .env
- uploads/
