# NVT NexaVest v11

- Added public random NVT User ID for every account.
- Existing users automatically receive a User ID during migration.
- New users receive a User ID at registration.
- Added `/profile` page.
- Users can view/copy their NVT User ID from Profile.
- Users can change full name, email/Gmail, phone and password by entering current password.
- Changing password requires confirmation.
- User profile updates issue a fresh login token when email changes.
- Dashboard shows the NVT User ID and links to Profile.
- Admin user list/search now includes public User ID.
- Service worker cache bumped to v11.
