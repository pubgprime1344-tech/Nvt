# Release Notes V29

## Bug fixes
- Trade All button now fills a valid decimal amount with 2 decimal places and supports balances like 670.89.
- Backend trade amount handling now rounds safely to 2 decimals and compares balance with a small epsilon.
- First-deposit Lucky Wheel spin is now awarded based on the gross confirmed deposit amount, so a 100 USDT deposit still qualifies even after network/platform fee deductions.
- Manual admin deposits also award the first-deposit Lucky Wheel spin when eligible.
- Users receive a notification when a Lucky Wheel chance is added after a qualifying confirmed deposit.
- KYC upload accepts HEIC/HEIF/mobile image formats, allows up to 25MB per file, and returns clean JSON errors instead of failing silently.

## No npm install required
- No new packages were added.
