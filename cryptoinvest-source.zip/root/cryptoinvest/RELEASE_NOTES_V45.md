# Release V45 - Deposit Submit Fix

- Replaced image-pixel deposit submission with a real authenticated POST request.
- Added a 15-second timeout and guaranteed UI cleanup in `finally`.
- Prevented double-click/double-submit while a request is active.
- Shows the server success/error message directly to the user.
- Resets the form only after confirmed successful registration.
- Existing users and database files are not modified.
- Updated the service-worker cache name so mobile/PWA clients receive the fixed files.
