# V49.1 — Persian UI Freeze Fix

- Fixed recursive Persian translation MutationObserver loop that could freeze Chrome/PWA.
- Mutation observer now watches only added DOM nodes and disconnects while translating.
- Bumped HTML asset versions and Service Worker cache name to force clean assets.
- No database schema or user data changes.
