# NVT NexaVest v16

Changes:
- Added NVT loading animation on page load and internal page changes.
- Added app-like mobile bottom navigation for user and admin dashboards.
- Improved compact button styling and mobile layout.
- Added PWA install shortcut behavior with NVT manifest name.
- Removed ADMIN2024 hint from registration page.
- Added email verification code step before registration.
- Added email verification code step before withdrawal submission.
- Added 5-day withdrawal lock after each verified deposit.
- Added one-time 5 USDT active referral bonus after the invited user's first qualifying deposit.
- Added support email display next to ticket support.
- Added one-trade-per-pair-per-day rule.
- Added Mailtrap SMTP settings to environment files.

Important:
- Rotate the Mailtrap token after testing because it was shared in chat.
- Keep cryptoinvest.db, .env and uploads/ when updating existing servers.
