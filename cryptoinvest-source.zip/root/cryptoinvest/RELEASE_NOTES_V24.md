# Release Notes V24

## Lucky Wheel visual refresh
- Removed rules 4 and 6 from the public Lucky Wheel rules section.
- Upgraded wheel prize visuals with premium-style artwork.
- Added Tether coin artwork for USDT prizes.
- Added improved iPhone 17 artwork.
- Added improved washer artwork.
- Added improved extra spin artwork.
- Improved Lucky Wheel history localization for Persian.
- Bumped Lucky Wheel asset version to v24 for cache refresh.

## Prize labels
- Updated display-only prize label to `iPhone 17`.
- Updated washer label to `Washer` with Persian translation support.
