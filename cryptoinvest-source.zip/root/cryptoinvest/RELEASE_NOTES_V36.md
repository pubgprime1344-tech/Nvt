# N-VT Miner v36

- Fixed Rent Miner button/modal not opening on mobile/PWA.
- Added robust click handler and forced modal overlay visibility.
- Removed/replaced VIP/trading navigation with miner-focused labels.
- Bottom tab now uses Wheel instead of VIP.
- Dashboard no longer shows trade remaining limits; it shows active miner contracts.
- Cache version bumped to v36.
