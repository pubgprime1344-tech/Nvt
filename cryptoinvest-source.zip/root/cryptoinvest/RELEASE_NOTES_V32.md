# Release Notes V32

## Deposit submit no-freeze fix
- Deposit report UI now releases automatically within ~2 seconds even if mobile browser/Cloudflare fetch stays pending.
- Request continues in the background and manual-review success message is shown immediately.
- Button is always re-enabled by a safety fallback.
- Added no-store headers on deposit report endpoint.
- No new npm packages required.
