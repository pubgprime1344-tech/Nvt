/**
 * Run this on a trusted/offline computer:
 *   node scripts/generate-bep20-test-wallet.js
 *
 * Never send the mnemonic to anyone and never put it in the web server .env.
 * The server receives only the account-level XPUB and can derive addresses,
 * but cannot move funds.
 */
const { ethers } = require('ethers');

const wallet = ethers.HDNodeWallet.createRandom();
const phrase = wallet.mnemonic.phrase;
const accountNode = ethers.HDNodeWallet.fromPhrase(phrase, '', "m/44'/60'/0'/0");
const xpub = accountNode.neuter().extendedKey;

console.log('============================================================');
console.log('BEP20 TEST WALLET - KEEP THE MNEMONIC OFFLINE');
console.log('============================================================');
console.log('Mnemonic (SECRET - DO NOT PUT ON SERVER):');
console.log(phrase);
console.log('');
console.log('Server XPUB (public-only, safe for testnet address generation):');
console.log(xpub);
console.log('');
console.log('First test deposit address:');
console.log(accountNode.deriveChild(0).address);
console.log('============================================================');
