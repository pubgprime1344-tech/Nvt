# V42 Manual Deposit Final Fix

- Removed explorer/RPC waiting from deposit page flow.
- Deposit report posts directly to admin pending list.
- Mobile/PWA button can no longer stay locked; hard UI unlock added.
- Server route does not check explorer or require admin address validation before accepting manual report.
- Cache version updated to v42.
