# Release V10 - Withdrawal Fee

Changes:
- Added 10% withdrawal fee.
- User balance is deducted by the requested withdrawal amount.
- Admin should send only the net amount after fee.
- Rejected withdrawals return the full requested amount to the user.
- Withdrawal history and admin withdrawal screen now show requested amount, fee, and net amount to send.
- Existing databases are migrated with `fee_amount` and `net_amount` columns for withdrawals.
