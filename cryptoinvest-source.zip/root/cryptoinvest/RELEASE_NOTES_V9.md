# NVT NexaVest v9

Changes in this build:

- Brand mark changed from `NV` to `NVT`, displayed as `NVT NexaVest`.
- PWA manifest updated to `NVT NexaVest` / `NVT`.
- App icons regenerated with the `NVT` mark.
- VIP daily trade limits added:
  - VIP 1: 3 trades/day
  - VIP 2: 5 trades/day
  - VIP 3: 7 trades/day
  - VIP 4: 10 trades/day
  - VIP 5: 15 trades/day
  - VIP 6: 20 trades/day
- Dashboard now shows the current VIP level and progress to the next level.
- New user page added: `/vip-level`.
- Trading page now shows remaining trades as `remaining / VIP daily limit`.
- Server-side trade limit enforcement now uses the user's VIP level.
- JWT secret now reads from `.env` when available.

Install with the same clean deployment commands used for previous versions.
