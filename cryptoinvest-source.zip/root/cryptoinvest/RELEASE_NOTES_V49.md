# V49

- Removed phone number from account registration; phone remains required only in KYC.
- Added live in-site popup notifications for account events, including deposit approval/rejection.
- Added optional device/PWA notifications while the app is running or in the background.
- Added automatic wallet balance refresh after deposit approval notification.
- Added user deposit request history with pending/approved/rejected status.
- Added best-effort SQLite unique index for deposit transaction hashes without deleting existing data.
- Preserved the V48 no-reload deposit submission fix.
