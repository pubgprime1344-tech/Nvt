# V47

- Fixed full-page freeze after deposit submission on iOS Safari and installed PWA.
- Replaced fetch/keepalive deposit submit with XMLHttpRequest.
- Added duplicate TX hash pre-check endpoint.
- Added forced clean reload after successful/uncertain submission so the PWA never remains stuck.
- Updated service-worker cache key.
- Database schema unchanged.
