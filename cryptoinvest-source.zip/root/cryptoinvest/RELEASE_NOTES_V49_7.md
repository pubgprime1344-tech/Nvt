# NVT Miner V49.7

- Reworked the BEP20 mainnet shadow watcher.
- Filters USDT Transfer logs by each assigned destination address at RPC level.
- Automatically splits eth_getLogs block ranges when an RPC returns limit errors.
- Retries transient one-block RPC failures without advancing the database cursor.
- Keeps Shadow Mode, automatic balance credit and sweep disabled.
- Intended for the allow-listed test user only while BEP20_PUBLIC_ENABLED=false.
- Does not include a database or .env file.
