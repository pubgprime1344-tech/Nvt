# N-VT Miner V49.3

## Changes
- Minimum accepted deposit changed from 100 USDT to 50 USDT in backend and user-facing deposit pages.
- Added a new 50 USDT **Starter Miner** plan with 15 USDT base 24-hour profit (30%).
- Mining minimum changed to 50 USDT for newly created contracts.
- Existing active/completed mining contracts are not recalculated or edited. Their saved `amount`, `profit_percentage`, `profit_amount`, `created_at`, and progress remain unchanged.
- No database file is included in this package. Deployment must keep the existing `cryptoinvest.db`.
- Lucky Wheel qualification and withdrawal/referral thresholds that were already 100 USDT were not changed.
- PWA/cache version bumped to V49.3.
