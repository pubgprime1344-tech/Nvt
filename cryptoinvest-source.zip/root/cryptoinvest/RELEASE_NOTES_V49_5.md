# V49.5 — BEP20 Automatic Deposit Phase 1

- Testnet-only automatic BEP20 deposit system.
- Unique HD-derived BSC address for every user.
- Web server stores only an XPUB, never the mnemonic/private key.
- Finalized-block processing with 120-block fallback.
- Automatic, idempotent balance credit.
- Duplicate protection by chain ID, transaction hash and log index.
- Existing users, balances, mining contracts and progress are not recalculated or modified.
- Manual TRC20 flow remains available.
- Sweep to admin wallet is intentionally disabled until Phase 1 tests pass.
