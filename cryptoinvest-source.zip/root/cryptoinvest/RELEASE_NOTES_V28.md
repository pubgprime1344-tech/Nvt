# Release Notes V28

## Lucky Wheel rules
- Current Lucky Wheel is now positioned as a new-user wheel.
- A new user receives 1 normal Lucky Wheel spin after the first verified deposit of 100 USDT or more.
- Removed old rule that referrers receive normal Lucky Wheel spins from referred deposits.
- Added note that a special referral wheel will be introduced after 5 active referrals.

## Referral ranking
- Added referral rank system based on active referrals:
  - Bronze: 1-9 active referrals, 10% commission
  - Silver: 10-49 active referrals, 12% commission + 50 USDT one-time rank bonus
  - Gold: 50-99 active referrals, 15% commission + 200 USDT one-time rank bonus
  - Platinum: 100+ active referrals, 20% commission + 500 USDT one-time rank bonus
- Referral commission is now calculated dynamically from the referrer's active referral count.
- One-time rank bonuses are credited automatically when a rank is reached.

## UI
- Added Referral Ranking table on the referral page.
- Added current rank badge and dynamic commission rate.
- Updated Persian translations for referral ranking and wheel rules.
- Cache version bumped to v28.
