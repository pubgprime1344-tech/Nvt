#!/usr/bin/env bash
set -euo pipefail

APP="/root/cryptoinvest"
HERE="$(cd "$(dirname "$0")" && pwd)"
PATCH="$HERE/patch"
STAMP="$(date +%F_%H-%M-%S)"
BACKUP="/root/nvt_v50_2_source_backup_$STAMP"

[ -f "$APP/server.js" ] || { echo "ERROR: $APP/server.js not found"; exit 1; }
[ -f "$APP/cryptoinvest.db" ] || { echo "ERROR: database not found; stopped"; exit 1; }
[ -f "$PATCH/server.js" ] || { echo "ERROR: patch is incomplete"; exit 1; }
[ -f "$PATCH/public/downloads/app-release.apk" ] || { echo "ERROR: APK missing from patch"; exit 1; }

mkdir -p "$BACKUP"
cp -a "$APP/server.js" "$BACKUP/"
cp -a "$APP/public" "$BACKUP/"
cp -a "$APP/server" "$BACKUP/"
cp -a "$APP/package.json" "$BACKUP/" 2>/dev/null || true
cp -a "$APP/package-lock.json" "$BACKUP/" 2>/dev/null || true
cp -a "$APP/.env" "$BACKUP/.env" 2>/dev/null || true
cp -a "$APP"/cryptoinvest.db* "$BACKUP/" 2>/dev/null || true

echo "Backup: $BACKUP"

pm2 stop cryptoinvest 2>/dev/null || true

cp -a "$PATCH/public/." "$APP/public/"
cp -a "$PATCH/server/." "$APP/server/"
cp -f "$PATCH/server.js" "$APP/server.js"
cp -f "$PATCH/package.json" "$APP/package.json"
cp -f "$PATCH/package-lock.json" "$APP/package-lock.json"

# Keep database, uploads, node_modules and all user data untouched.
python3 - <<'PY'
from pathlib import Path
p = Path('/root/cryptoinvest/.env')
text = p.read_text() if p.exists() else ''
values = {
    'BEP20_AUTO_DEPOSIT_ENABLED': 'false',
    'BEP20_SHADOW_MODE': 'false',
    'BEP20_CREDIT_ENABLED': 'false',
    'BEP20_SWEEP_ENABLED': 'false',
    'BEP20_PUBLIC_ENABLED': 'false',
}
lines=[]
seen=set()
for line in text.splitlines():
    if '=' in line and not line.lstrip().startswith('#'):
        k=line.split('=',1)[0].strip()
        if k in values:
            if k not in seen:
                lines.append(f'{k}={values[k]}')
                seen.add(k)
            continue
    lines.append(line)
for k,v in values.items():
    if k not in seen:
        lines.append(f'{k}={v}')
p.write_text('\n'.join(lines).rstrip()+'\n')
PY

node --check "$APP/server.js"

auto_restore() {
  echo "New overlay failed; restoring source backup..."
  rm -rf "$APP/public" "$APP/server"
  cp -a "$BACKUP/public" "$APP/public"
  cp -a "$BACKUP/server" "$APP/server"
  cp -f "$BACKUP/server.js" "$APP/server.js"
  cp -f "$BACKUP/package.json" "$APP/package.json" 2>/dev/null || true
  cp -f "$BACKUP/package-lock.json" "$APP/package-lock.json" 2>/dev/null || true
  cp -f "$BACKUP/.env" "$APP/.env" 2>/dev/null || true
  pm2 delete cryptoinvest 2>/dev/null || true
  pm2 start "$APP/server.js" --name cryptoinvest --cwd "$APP"
  pm2 save
}

pm2 delete cryptoinvest 2>/dev/null || true
pm2 start "$APP/server.js" --name cryptoinvest --cwd "$APP"
sleep 8

if curl -fsS --max-time 15 http://127.0.0.1:3000/ >/dev/null; then
  pm2 save
  pm2 flush
  nginx -t && systemctl restart nginx || true
  echo "OK: V50.2 overlay installed"
  echo "OK: database/users/mines/balances were not replaced"
  echo "OK: automatic BEP20 watcher disabled"
  echo "OK: APK URL: https://nv-t.site/downloads/app-release.apk"
  pm2 status
else
  auto_restore
  exit 1
fi
