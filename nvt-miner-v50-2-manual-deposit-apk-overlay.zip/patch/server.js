const express = require('express');
const path = require('path');
const fs = require('fs');

// Load .env without requiring any extra package
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
    const envLines = fs.readFileSync(envPath, 'utf8').split(/\r?\n/);
    for (const line of envLines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#') || !trimmed.includes('=')) continue;
        const eq = trimmed.indexOf('=');
        const key = trimmed.slice(0, eq).trim();
        let value = trimmed.slice(eq + 1).trim();
        if ((value.startsWith('\"') && value.endsWith('\"')) || (value.startsWith("\'") && value.endsWith("\'"))) {
            value = value.slice(1, -1);
        }
        if (key && process.env[key] === undefined) process.env[key] = value;
    }
}

const Database = require('./server/database');
const authRoutes = require('./server/routes/auth');
const userRoutes = require('./server/routes/user');
const walletRoutes = require('./server/routes/wallet');
const tradeRoutes = require('./server/routes/trade');
const referralRoutes = require('./server/routes/referral');
const withdrawRoutes = require('./server/routes/withdraw');
const adminRoutes = require('./server/routes/admin');
const kycRoutes = require('./server/routes/kyc');
const sendRoutes = require('./server/routes/send');
const depositRoutes = require('./server/routes/deposit');
const notificationRoutes = require('./server/routes/notifications');
const ticketRoutes = require('./server/routes/tickets');
const wheelRoutes = require('./server/routes/wheel');
const { authMiddleware } = require('./server/middleware/auth');

const app = express();
const PORT = process.env.PORT || 3000;

// Initialize Database
const db = new Database();
db.init();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Make db available to routes
app.use((req, res, next) => {
    req.db = db;
    next();
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/user', authMiddleware, userRoutes);
app.use('/api/wallet', authMiddleware, walletRoutes);
app.use('/api/trade', authMiddleware, tradeRoutes);
app.use('/api/mine', authMiddleware, tradeRoutes);
app.use('/api/referral', authMiddleware, referralRoutes);
app.use('/api/withdraw', authMiddleware, withdrawRoutes);
app.use('/api/kyc', authMiddleware, kycRoutes);
app.use('/api/deposit', authMiddleware, depositRoutes);
app.use('/api/notifications', authMiddleware, notificationRoutes);
app.use('/api/tickets', authMiddleware, ticketRoutes);
app.use('/api/wheel', authMiddleware, wheelRoutes);
app.use('/api/admin/send', authMiddleware, sendRoutes);
app.use('/api/admin', authMiddleware, adminRoutes);

// Serve HTML pages
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

app.get('/wallet', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'wallet.html'));
});

app.get('/profile', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'profile.html'));
});

app.get('/deposit', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'deposit.html'));
});

app.get('/withdraw', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'withdraw.html'));
});

app.get('/convert', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'convert.html'));
});

app.get('/trade', (req, res) => {
    res.redirect('/mine');
});

app.get('/mine', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'mine.html'));
});

app.get('/vip-level', (req, res) => {
    res.redirect('/mine');
});

app.get('/referral', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'referral.html'));
});

app.get('/kyc', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'kyc.html'));
});

app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.get('/admin-users', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin-users.html'));
});

app.get('/admin-withdrawals', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin-withdrawals.html'));
});

app.get('/notifications', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'notifications.html'));
});

app.get('/admin-kyc', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin-kyc.html'));
});

app.get('/admin-deposits', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin-deposits.html'));
});

app.get('/admin-notifications', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin-notifications.html'));
});

app.get('/admin-send', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin-send.html'));
});
app.get('/admin-tickets', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin-tickets.html'));
});

app.get('/support', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'support.html'));
});

app.get('/tickets', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'tickets.html'));
});

app.get('/lucky-wheel', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'lucky-wheel.html'));
});

app.get('/admin-wheel', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin-wheel.html'));
});



// Error handling
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ success: false, message: 'Server error' });
});

function runAutomaticMiningClaims() {
    try {
        if (typeof tradeRoutes.runAutoClaims !== 'function') return;
        const settled = tradeRoutes.runAutoClaims(db.db);
        if (settled.length) {
            console.log(`⛏️ Automatically credited ${settled.length} completed mining contract(s).`);
        }
    } catch (error) {
        console.error('Automatic mining claim worker error:', error);
    }
}

app.listen(PORT, () => {
    console.log(`🚀 N-VT Miner running on http://localhost:${PORT}`);
    console.log(`📊 Admin panel: http://localhost:${PORT}/admin`);
    console.log(`🔑 Default admin referral code: ADMIN2024`);

    // Settle matured contracts even when users are offline.
    setTimeout(runAutomaticMiningClaims, 5000);
    const miningClaimTimer = setInterval(runAutomaticMiningClaims, 60000);
    if (typeof miningClaimTimer.unref === 'function') miningClaimTimer.unref();
});
