const express = require('express');
const crypto = require('crypto');
const https = require('https');
const router = express.Router();
const { JWT_SECRET } = require('../middleware/auth');
const { isEmailEnabled, sendEmail, renderCodeEmail } = require('../utils/email');

const MIN_WITHDRAWAL = Math.max(100, parseFloat(process.env.MIN_WITHDRAWAL_USDT || '100'));
const WITHDRAWAL_FEE_RATE = parseFloat(process.env.WITHDRAWAL_FEE_RATE || '0.10');
const DEPOSIT_WITHDRAW_LOCK_DAYS = parseInt(process.env.DEPOSIT_WITHDRAW_LOCK_DAYS || '5', 10);
const CODE_EXPIRE_MINUTES = parseInt(process.env.WITHDRAW_EMAIL_CODE_EXPIRE_MINUTES || '10', 10);
const CODE_RESEND_SECONDS = parseInt(process.env.EMAIL_CODE_RESEND_SECONDS || '60', 10);
const FALLBACK_PRICES = { USDT: 1, BTC: 67500, ETH: 3450, DOGE: 0.12 };
let priceCache = { at: 0, prices: FALLBACK_PRICES };
const roundMoney = (value) => Math.round(Number(value || 0) * 100000000) / 100000000;

function emailVerificationRequired() {
    const setting = String(process.env.REQUIRE_WITHDRAW_EMAIL_CODE || 'auto').toLowerCase();
    if (setting === 'true') return true;
    if (setting === 'false') return false;
    return isEmailEnabled();
}
function generateCode() { return String(Math.floor(100000 + Math.random() * 900000)); }
function hashCode(email, purpose, code) { return crypto.createHash('sha256').update(`${JWT_SECRET}:${String(email).toLowerCase()}:${purpose}:${code}`).digest('hex'); }
function httpsJson(url, timeoutMs = 3500) {
    return new Promise((resolve, reject) => {
        const req = https.get(url, { timeout: timeoutMs, headers: { 'User-Agent': 'NVT-Miner/1.0' } }, (res) => {
            let data = ''; res.on('data', c => data += c); res.on('end', () => { try { resolve(JSON.parse(data)); } catch(e){ reject(e); } });
        });
        req.on('timeout', () => req.destroy(new Error('timeout')));
        req.on('error', reject);
    });
}
async function getPrices() {
    if (Date.now() - priceCache.at < 60000) return priceCache.prices;
    try {
        const rows = await httpsJson('https://api.binance.com/api/v3/ticker/price?symbols=%5B%22BTCUSDT%22,%22ETHUSDT%22,%22DOGEUSDT%22%5D');
        const p = { ...FALLBACK_PRICES };
        for (const r of rows || []) {
            if (r.symbol === 'BTCUSDT') p.BTC = Number(r.price) || p.BTC;
            if (r.symbol === 'ETHUSDT') p.ETH = Number(r.price) || p.ETH;
            if (r.symbol === 'DOGEUSDT') p.DOGE = Number(r.price) || p.DOGE;
        }
        priceCache = { at: Date.now(), prices: p };
    } catch (_) { priceCache = { at: Date.now(), prices: priceCache.prices || FALLBACK_PRICES }; }
    return priceCache.prices;
}
function normalizePayload({ amount, wallet_address, network, asset }, prices = FALLBACK_PRICES) {
    const cleanAsset = String(asset || 'USDT').toUpperCase();
    const price = Number(prices[cleanAsset] || 1);
    const requestedAmount = roundMoney(amount);
    const amountUsdt = cleanAsset === 'USDT' ? requestedAmount : roundMoney(requestedAmount * price);
    return { amount: requestedAmount, amount_usdt: amountUsdt, asset: cleanAsset, asset_price: price, wallet_address: String(wallet_address || '').trim(), network: String(network || '').trim().toLowerCase() };
}
function samePayload(a, b) {
    return roundMoney(a.amount) === roundMoney(b.amount) && String(a.asset || 'USDT').toUpperCase() === String(b.asset || 'USDT').toUpperCase() && String(a.wallet_address || '').trim() === String(b.wallet_address || '').trim() && String(a.network || '').trim().toLowerCase() === String(b.network || '').trim().toLowerCase();
}
function getDepositLock(db, userId) {
    const lockSetting = db.prepare('SELECT COALESCE(withdraw_lock_disabled, 0) as disabled FROM users WHERE id = ?').get(userId);
    if (lockSetting && Number(lockSetting.disabled || 0) === 1) return null;
    const lock = db.prepare(`
        SELECT id, amount, created_at, datetime(created_at, '+' || ? || ' days') as unlock_at,
               CAST((julianday(datetime(created_at, '+' || ? || ' days')) - julianday('now')) * 24 * 60 AS INTEGER) as minutes_left
        FROM transactions
        WHERE user_id = ? AND type = 'deposit' AND status = 'completed' AND datetime(created_at, '+' || ? || ' days') > datetime('now')
        ORDER BY created_at DESC LIMIT 1
    `).get(DEPOSIT_WITHDRAW_LOCK_DAYS, DEPOSIT_WITHDRAW_LOCK_DAYS, userId, DEPOSIT_WITHDRAW_LOCK_DAYS);
    if (!lock) return null;
    return { ...lock, days: DEPOSIT_WITHDRAW_LOCK_DAYS, minutes_left: Math.max(1, Number(lock.minutes_left || 1)) };
}
function validateWithdrawInputSync(payload) {
    if (!payload.amount || !payload.wallet_address || !payload.network || !payload.asset) return { ok: false, message: 'All fields are required' };
    const allowedNetworks = ['trc20','bep20','erc20','ethereum','btc','bitcoin','doge','dogecoin'];
    if (!allowedNetworks.includes(payload.network)) return { ok: false, message: 'Invalid withdrawal network' };
    if (!['USDT', 'BTC', 'ETH', 'DOGE'].includes(payload.asset)) return { ok: false, message: 'Invalid withdrawal asset' };
    if (payload.amount <= 0) return { ok: false, message: 'Invalid withdrawal amount' };
    if (payload.amount_usdt < MIN_WITHDRAWAL) return { ok: false, message: `Minimum withdrawal value is ${MIN_WITHDRAWAL} USDT` };
    const feeAmount = roundMoney(payload.amount * WITHDRAWAL_FEE_RATE);
    const netAmount = roundMoney(payload.amount - feeAmount);
    return { ok: true, payload: { ...payload, fee_amount: feeAmount, net_amount: netAmount } };
}
function getAssetBalance(db, userId, asset) {
    if (asset === 'USDT') return Number(db.prepare('SELECT COALESCE(withdrawable_balance,0) as withdrawable_balance FROM users WHERE id = ?').get(userId)?.withdrawable_balance || 0);
    return Number(db.prepare('SELECT amount FROM crypto_balances WHERE user_id = ? AND asset = ?').get(userId, asset)?.amount || 0);
}
function getWithdrawalSettings(db) {
    const defaults = { enabled: 1, require_active_referral: 1, min_active_referrals: 1, active_referral_min_deposit: 100, weekly_withdraw_ratio: 0.3333333333, weekly_window_days: 7, kyc_required: 1 };
    try {
        const row = db.prepare('SELECT * FROM withdrawal_settings WHERE id = 1').get() || {};
        return { enabled: Number(row.enabled ?? defaults.enabled), require_active_referral: Number(row.require_active_referral ?? defaults.require_active_referral), min_active_referrals: Math.max(0, parseInt(row.min_active_referrals ?? defaults.min_active_referrals, 10)), active_referral_min_deposit: Math.max(0, Number(row.active_referral_min_deposit ?? defaults.active_referral_min_deposit)), weekly_withdraw_ratio: Math.min(1, Math.max(0.01, Number(row.weekly_withdraw_ratio ?? defaults.weekly_withdraw_ratio))), weekly_window_days: Math.max(1, parseInt(row.weekly_window_days ?? defaults.weekly_window_days, 10)), kyc_required: Number(row.kyc_required ?? defaults.kyc_required) };
    } catch (_) { return defaults; }
}
function getWithdrawalLimitStatus(db, userId, walletBalance) {
    const settings = getWithdrawalSettings(db);
    const activeReferralRow = db.prepare(`SELECT COUNT(*) as count FROM users WHERE referred_by = ? AND role = 'user' AND COALESCE(total_deposit, 0) >= ?`).get(userId, settings.active_referral_min_deposit);
    const activeReferrals = Number(activeReferralRow?.count || 0);
    const userOverride = db.prepare('SELECT COALESCE(withdraw_referral_limit_disabled, 0) as disabled FROM users WHERE id = ?').get(userId);
    const referralDisabledForUser = Number(userOverride?.disabled || 0) === 1;
    const usedRow = db.prepare(`SELECT COALESCE(SUM(COALESCE(amount_usdt, amount)), 0) as used FROM withdrawals WHERE user_id = ? AND status IN ('pending', 'approved') AND datetime(created_at) >= datetime('now', '-' || ? || ' days')`).get(userId, settings.weekly_window_days);
    const weeklyUsed = roundMoney(usedRow?.used || 0);
    const balance = roundMoney(walletBalance || 0);
    const weeklyBase = roundMoney(balance + weeklyUsed);
    const weeklyLimit = Number(settings.enabled || 0) ? roundMoney(weeklyBase * settings.weekly_withdraw_ratio) : balance;
    const weeklyRemaining = Number(settings.enabled || 0) ? roundMoney(Math.max(0, weeklyLimit - weeklyUsed)) : balance;
    const referralOk = referralDisabledForUser || !Number(settings.enabled || 0) || !settings.require_active_referral || activeReferrals >= settings.min_active_referrals;
    return { settings, active_referrals: activeReferrals, referral_ok: referralOk, referral_limit_disabled_for_user: referralDisabledForUser, weekly_used: weeklyUsed, weekly_base: weeklyBase, weekly_limit: weeklyLimit, weekly_remaining: weeklyRemaining, weekly_percent: Number(settings.enabled || 0) ? Math.round(settings.weekly_withdraw_ratio * 10000) / 100 : 100, window_days: settings.weekly_window_days };
}
function validateWithdrawalLimits(db, userId, walletBalance, amountUsdt) {
    const status = getWithdrawalLimitStatus(db, userId, walletBalance);
    if (!status.settings.enabled) return { ok: true, status };
    if (!status.referral_ok) return { ok: false, status, message: `برای برداشت باید حداقل ${status.settings.min_active_referrals} زیرمجموعه فعال داشته باشید که واریز انجام داده باشد.` };
    if (roundMoney(amountUsdt) > roundMoney(status.weekly_remaining + 0.000001)) return { ok: false, status, message: `محدودیت برداشت هفتگی فعال است. سقف باقی‌مانده این هفته: ${status.weekly_remaining} USDT` };
    return { ok: true, status };
}
function verifyWithdrawCode(db, user, payload, code) {
    const cleanCode = String(code || '').trim();
    if (!cleanCode || !/^\d{6}$/.test(cleanCode)) return { ok: false, message: 'Enter the 6-digit email code' };
    const row = db.prepare(`SELECT * FROM verification_codes WHERE user_id = ? AND email = ? AND purpose = 'withdraw' AND used_at IS NULL AND datetime(expires_at) > datetime('now') ORDER BY created_at DESC LIMIT 1`).get(user.id, String(user.email || '').toLowerCase());
    if (!row) return { ok: false, message: 'Withdrawal email code is expired or not found' };
    if (Number(row.attempts || 0) >= 5) return { ok: false, message: 'Too many wrong attempts. Request a new code.' };
    const expected = hashCode(user.email, 'withdraw', cleanCode);
    if (expected !== row.code_hash) { db.prepare('UPDATE verification_codes SET attempts = attempts + 1 WHERE id = ?').run(row.id); return { ok: false, message: 'Withdrawal email code is incorrect' }; }
    let meta = null; try { meta = row.metadata ? JSON.parse(row.metadata) : null; } catch { meta = null; }
    if (meta && !samePayload(meta, payload)) return { ok: false, message: 'Withdrawal details changed. Request a new email code.' };
    return { ok: true, row };
}

router.post('/send-code', async (req, res) => {
    try {
        if (!isEmailEnabled()) return res.json({ success: false, message: 'Email sending is not configured yet' });
        const prices = await getPrices();
        const normalized = normalizePayload(req.body, prices);
        const validation = validateWithdrawInputSync(normalized);
        if (!validation.ok) return res.json({ success: false, message: validation.message });
        const payload = validation.payload;
        const user = req.db.db.prepare('SELECT id, email, wallet_balance, COALESCE(withdrawable_balance,0) as withdrawable_balance, kyc_status FROM users WHERE id = ?').get(req.user.id);
        if (!user) return res.json({ success: false, message: 'User not found' });
        if (getAssetBalance(req.db.db, req.user.id, payload.asset) + 1e-10 < payload.amount) return res.json({ success: false, message: 'Insufficient balance' });
        const ws = getWithdrawalLimitStatus(req.db.db, req.user.id, user.withdrawable_balance || 0).settings;
        if (Number(ws.kyc_required ?? 1) === 1 && user.kyc_status !== 'approved') return res.json({ success: false, message: 'Please complete KYC verification before withdrawing' });
        // Deposit principal is locked in Miner Balance; withdrawable mining/referral rewards are not blocked by the old deposit lock.
        const limitCheck = validateWithdrawalLimits(req.db.db, req.user.id, user.withdrawable_balance, payload.amount_usdt); if (!limitCheck.ok) return res.json({ success: false, message: limitCheck.message, withdrawal_limits: limitCheck.status });
        const recent = req.db.db.prepare(`SELECT last_sent_at FROM verification_codes WHERE user_id = ? AND email = ? AND purpose = 'withdraw' AND used_at IS NULL ORDER BY created_at DESC LIMIT 1`).get(user.id, user.email);
        if (recent) { const wait = Math.ceil((CODE_RESEND_SECONDS * 1000 - (Date.now() - new Date(recent.last_sent_at).getTime())) / 1000); if (wait > 0) return res.json({ success: false, message: `Please wait ${wait}s before requesting another code` }); }
        const code = generateCode();
        const expiresAt = new Date(Date.now() + CODE_EXPIRE_MINUTES * 60 * 1000).toISOString();
        req.db.db.prepare(`INSERT INTO verification_codes (user_id, email, purpose, code_hash, metadata, expires_at) VALUES (?, ?, 'withdraw', ?, ?, ?)`).run(user.id, String(user.email).toLowerCase(), hashCode(user.email, 'withdraw', code), JSON.stringify(payload), expiresAt);
        const mail = renderCodeEmail({ title: 'Confirm your N-VT Miner withdrawal', code, purposeText: `confirm your ${payload.amount} ${payload.asset} withdrawal request` });
        const sent = await sendEmail({ to: user.email, ...mail });
        if (!sent.ok) return res.json({ success: false, message: sent.error || 'Could not send email code' });
        res.json({ success: true, message: 'Withdrawal verification code sent to your email', expires_minutes: CODE_EXPIRE_MINUTES, net_amount: payload.net_amount, fee_amount: payload.fee_amount, asset: payload.asset });
    } catch (error) { console.error('Withdrawal code error:', error); res.json({ success: false, message: 'Could not send withdrawal code' }); }
});

router.post('/request', async (req, res) => {
    try {
        const prices = await getPrices();
        const normalized = normalizePayload(req.body, prices);
        const validation = validateWithdrawInputSync(normalized);
        if (!validation.ok) return res.json({ success: false, message: validation.message });
        const payload = validation.payload;
        const user = req.db.db.prepare('SELECT id, email, wallet_balance, COALESCE(withdrawable_balance,0) as withdrawable_balance, kyc_status FROM users WHERE id = ?').get(req.user.id);
        if (!user) return res.json({ success: false, message: 'User not found' });
        if (getAssetBalance(req.db.db, req.user.id, payload.asset) + 1e-10 < payload.amount) return res.json({ success: false, message: 'Insufficient balance' });
        const ws = getWithdrawalLimitStatus(req.db.db, req.user.id, user.withdrawable_balance || 0).settings;
        if (Number(ws.kyc_required ?? 1) === 1 && user.kyc_status !== 'approved') return res.json({ success: false, message: 'Please complete KYC verification before withdrawing' });
        // Deposit principal is locked in Miner Balance; withdrawable mining/referral rewards are not blocked by the old deposit lock.
        const limitCheck = validateWithdrawalLimits(req.db.db, req.user.id, user.withdrawable_balance, payload.amount_usdt); if (!limitCheck.ok) return res.json({ success: false, message: limitCheck.message, withdrawal_limits: limitCheck.status });
        if (emailVerificationRequired()) { const check = verifyWithdrawCode(req.db.db, user, payload, req.body.email_code); if (!check.ok) return res.json({ success: false, message: check.message }); req.db.db.prepare('UPDATE verification_codes SET used_at = CURRENT_TIMESTAMP WHERE id = ?').run(check.row.id); }
        const tx = req.db.db.transaction(() => {
            if (payload.asset === 'USDT') req.db.db.prepare('UPDATE users SET withdrawable_balance = COALESCE(withdrawable_balance,0) - ? WHERE id = ?').run(payload.amount, req.user.id);
            else req.db.db.prepare('UPDATE crypto_balances SET amount = amount - ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ? AND asset = ?').run(payload.amount, req.user.id, payload.asset);
            const result = req.db.db.prepare(`INSERT INTO withdrawals (user_id, amount, fee_amount, net_amount, wallet_address, network, asset, asset_price, amount_usdt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
              .run(req.user.id, payload.amount, payload.fee_amount, payload.net_amount, payload.wallet_address, payload.network, payload.asset, payload.asset_price, payload.amount_usdt);
            req.db.db.prepare(`INSERT INTO transactions (user_id, type, amount, net_amount, description, status, network) VALUES (?, 'withdraw_request', ?, ?, ?, 'pending', ?)`)
              .run(req.user.id, -payload.amount_usdt, -roundMoney(payload.net_amount * payload.asset_price), `Withdrawal request #${result.lastInsertRowid} — ${payload.amount} ${payload.asset}, net ${payload.net_amount} ${payload.asset}`, payload.network);
            req.db.db.prepare(`INSERT INTO notifications (target_user_id, title, message, type, created_by) VALUES (?, 'Withdrawal request submitted', ?, 'info', ?)`).run(req.user.id, `Your withdrawal request for ${payload.amount} ${payload.asset} was submitted. Net amount: ${payload.net_amount} ${payload.asset}.`, req.user.id);
            return result;
        });
        const result = tx();
        res.json({ success: true, message: 'Withdrawal request submitted. Processing time: 24-48 hours.', withdrawal_id: result.lastInsertRowid, amount: payload.amount, asset: payload.asset, fee: payload.fee_amount, fee_rate: WITHDRAWAL_FEE_RATE, net_amount: payload.net_amount });
    } catch (error) { console.error('Withdrawal error:', error); res.json({ success: false, message: 'Withdrawal request failed' }); }
});

router.get('/history', (req, res) => {
    try {
        const withdrawals = req.db.db.prepare(`SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC`).all(req.user.id);
        const stats = req.db.db.prepare(`SELECT SUM(CASE WHEN status = 'approved' THEN COALESCE(amount_usdt, net_amount, amount) ELSE 0 END) as total_withdrawn, SUM(CASE WHEN status = 'pending' THEN COALESCE(amount_usdt, net_amount, amount) ELSE 0 END) as pending_amount, COUNT(*) as total_requests FROM withdrawals WHERE user_id = ?`).get(req.user.id);
        const lock = getDepositLock(req.db.db, req.user.id);
        const user = req.db.db.prepare('SELECT wallet_balance, COALESCE(withdrawable_balance,0) as withdrawable_balance FROM users WHERE id = ?').get(req.user.id);
        const withdrawalLimits = getWithdrawalLimitStatus(req.db.db, req.user.id, user?.withdrawable_balance || 0);
        const assetRows = req.db.db.prepare(`SELECT asset, amount FROM crypto_balances WHERE user_id = ? ORDER BY asset`).all(req.user.id);
        const assetMap = Object.fromEntries((assetRows || []).map(r => [String(r.asset).toUpperCase(), Number(r.amount || 0)]));
        const assetBalances = ['BTC','ETH','DOGE'].map(asset => ({ asset, amount: Number(assetMap[asset] || 0) }));
        res.json({ success: true, withdrawals, stats, deposit_lock: null, withdrawal_limits: withdrawalLimits, asset_balances: assetBalances, locked_usdt_balance: user?.wallet_balance || 0, withdrawable_usdt_balance: user?.withdrawable_balance || 0 });
    } catch (error) { res.json({ success: false, message: 'Error fetching withdrawal history' }); }
});

module.exports = router;
