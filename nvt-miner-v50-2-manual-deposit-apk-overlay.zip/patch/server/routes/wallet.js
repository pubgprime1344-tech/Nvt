const express = require('express');
const router = express.Router();

// دریافت آدرس‌های واریز مستقیم ادمین
router.get('/addresses', (req, res) => {
    try {
        const addresses = typeof req.db.getAdminAddresses === 'function'
            ? req.db.getAdminAddresses()
            : { tron: process.env.TRON_ADDRESS || 'TKxxxxx', bsc: process.env.BSC_ADDRESS || '0xxxxx' };

        res.json({
            success: true,
            mode: 'direct_to_admin',
            addresses: {
                trc20: addresses.tron,
                bep20: addresses.bsc
            }
        });
    } catch (error) {
        console.error('Wallet addresses error:', error);
        res.json({ success: false, message: 'Error fetching wallet addresses' });
    }
});

// Asset balances
router.get('/assets', (req, res) => {
    try {
        const rows = req.db.db.prepare(`SELECT asset, amount FROM crypto_balances WHERE user_id = ? ORDER BY asset`).all(req.user.id);
        const user = req.db.db.prepare(`SELECT wallet_balance, COALESCE(withdrawable_balance,0) as withdrawable_balance FROM users WHERE id = ?`).get(req.user.id);
        const map = Object.fromEntries((rows || []).map(r => [String(r.asset).toUpperCase(), Number(r.amount || 0)]));
        const assets = ['BTC','ETH','DOGE'].map(asset => ({ asset, amount: Number(map[asset] || 0) }));
        res.json({ success: true, usdt_balance: user?.wallet_balance || 0, withdrawable_balance: user?.withdrawable_balance || 0, locked_usdt_balance: user?.wallet_balance || 0, withdrawable_balance: user?.withdrawable_balance || 0, withdrawable_usdt_balance: user?.withdrawable_balance || 0, assets });
    } catch (error) {
        res.json({ success: false, message: 'Error fetching asset balances' });
    }
});

// دریافت موجودی
router.get('/balance', (req, res) => {
    try {
        const user = req.db.db.prepare(`
            SELECT wallet_balance, COALESCE(withdrawable_balance,0) as withdrawable_balance FROM users WHERE id = ?
        `).get(req.user.id);
        
        res.json({
            success: true,
            balance: user?.wallet_balance || 0, withdrawable_balance: user?.withdrawable_balance || 0
        });
    } catch (error) {
        res.json({ success: false, message: 'Error fetching balance' });
    }
});

// تاریخچه تراکنش‌ها
router.get('/transactions', (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 20;
        const offset = (page - 1) * limit;
        
        const transactions = req.db.db.prepare(`
            SELECT * FROM transactions WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        `).all(req.user.id, limit, offset);
        
        res.json({
            success: true,
            transactions
        });
    } catch (error) {
        res.json({ success: false, message: 'Error fetching transactions' });
    }
});

module.exports = router;
