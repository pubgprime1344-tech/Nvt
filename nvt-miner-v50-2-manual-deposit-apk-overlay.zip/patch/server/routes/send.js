const express = require('express');
const router = express.Router();
const { adminMiddleware } = require('../middleware/auth');

// Get admin wallet addresses and balances
router.get('/wallet-info', adminMiddleware, async (req, res) => {
    try {
        const admin = req.db.db.prepare('SELECT * FROM users WHERE role = ?').get('admin');
        
        // Get balances from blockchain (simulated for now)
        // In production, you would call TronWeb/BSC API here
        
        res.json({
            success: true,
            addresses: {
                tron: admin.trc20_address || 'TNotConfigured',
                bsc: admin.bep20_address || '0xNotConfigured'
            },
            balances: {
                tron: '0.00', // Will be fetched from blockchain
                bsc: '0.00'
            }
        });
    } catch (error) {
        res.json({ success: false, message: 'Error fetching wallet info' });
    }
});

// Get user's wallet address
router.get('/user/:id/wallet', adminMiddleware, (req, res) => {
    try {
        const { id } = req.params;
        const user = req.db.db.prepare(`
            SELECT trc20_address, bep20_address, full_name, email 
            FROM users WHERE id = ?
        `).get(id);
        
        if (!user) {
            return res.json({ success: false, message: 'User not found' });
        }

        res.json({
            success: true,
            user: {
                id,
                name: user.full_name || user.email,
                trc20: user.trc20_address,
                bep20: user.bep20_address
            },
            wallet: user.trc20_address || user.bep20_address
        });
    } catch (error) {
        res.json({ success: false, message: 'Error fetching user wallet' });
    }
});

// Record admin send transaction
router.post('/send-record', adminMiddleware, (req, res) => {
    try {
        const { network, address, amount, txHash } = req.body;
        
        if (!network || !address || !txHash) {
            return res.json({ success: false, message: 'Missing required fields' });
        }

        // Record the transaction
        req.db.db.prepare(`
            INSERT INTO admin_transactions (network, from_address, to_address, amount, tx_hash, type, status)
            VALUES (?, 'ADMIN_WALLET', ?, ?, ?, 'send', 'completed')
        `).run(network, address, amount || 0, txHash);

        res.json({
            success: true,
            message: 'Transaction recorded successfully'
        });
    } catch (error) {
        console.error('Send record error:', error);
        res.json({ success: false, message: 'Failed to record transaction' });
    }
});

// Send to user (approve withdrawal + record)
router.post('/send-to-user', adminMiddleware, (req, res) => {
    try {
        const { user_id, network, amount, tx_hash } = req.body;
        
        // Get user
        const user = req.db.db.prepare('SELECT * FROM users WHERE id = ?').get(user_id);
        if (!user) {
            return res.json({ success: false, message: 'User not found' });
        }

        // Find pending withdrawal for this user
        const withdrawal = req.db.db.prepare(`
            SELECT * FROM withdrawals 
            WHERE user_id = ? AND status = 'pending' 
            ORDER BY created_at DESC LIMIT 1
        `).get(user_id);

        if (withdrawal) {
            // Update withdrawal status
            req.db.db.prepare(`
                UPDATE withdrawals SET 
                    status = 'approved',
                    tx_hash = ?,
                    processed_at = CURRENT_TIMESTAMP
                WHERE id = ?
            `).run(tx_hash, withdrawal.id);

            // Update user total withdraw
            req.db.db.prepare(`
                UPDATE users SET total_withdraw = total_withdraw + ? WHERE id = ?
            `).run(withdrawal.amount, user_id);

            // Update transaction status
            req.db.db.prepare(`
                UPDATE transactions SET 
                    status = 'completed',
                    tx_hash = ?
                WHERE user_id = ? AND type = 'withdraw_request' AND status = 'pending'
            `).run(tx_hash, user_id);

            // Record admin send
            req.db.db.prepare(`
                INSERT INTO admin_transactions (network, from_address, to_address, amount, tx_hash, type, related_user_id, status)
                VALUES (?, 'ADMIN_WALLET', ?, ?, ?, 'withdrawal', ?, 'completed')
            `).run(network, user.trc20_address, amount, tx_hash, user_id);

        } else {
            // No pending withdrawal, just record the send
            req.db.db.prepare(`
                INSERT INTO admin_transactions (network, from_address, to_address, amount, tx_hash, type, related_user_id, status)
                VALUES (?, 'ADMIN_WALLET', ?, ?, ?, 'manual_send', ?, 'completed')
            `).run(network, user.trc20_address, amount, tx_hash, user_id);

            // Still credit user's wallet if it's a manual send
            req.db.db.prepare(`
                UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?
            `).run(amount, user_id);

            req.db.db.prepare(`
                INSERT INTO transactions (user_id, type, amount, net_amount, tx_hash, description, status)
                VALUES (?, 'manual_credit', ?, ?, ?, 'Admin manual credit', 'completed')
            `).run(user_id, amount, amount, tx_hash);
        }

        res.json({
            success: true,
            message: 'Transaction processed successfully'
        });

    } catch (error) {
        console.error('Send to user error:', error);
        res.json({ success: false, message: 'Failed to process' });
    }
});

// Get admin transaction history
router.get('/transactions', adminMiddleware, (req, res) => {
    try {
        // Check if table exists, if not create it
        try {
            req.db.db.exec(`
                CREATE TABLE IF NOT EXISTS admin_transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    network TEXT NOT NULL,
                    from_address TEXT NOT NULL,
                    to_address TEXT NOT NULL,
                    amount REAL,
                    tx_hash TEXT,
                    type TEXT,
                    related_user_id INTEGER,
                    status TEXT DEFAULT 'pending',
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            `);
        } catch (e) {
            // Table might already exist
        }

        const transactions = req.db.db.prepare(`
            SELECT * FROM admin_transactions 
            ORDER BY created_at DESC 
            LIMIT 50
        `).all();

        res.json({
            success: true,
            transactions
        });
    } catch (error) {
        res.json({ success: false, message: 'Error fetching transactions' });
    }
});

module.exports = router;
