/**
 * Deposit Routes - Manual Review Only
 * User sends USDT to admin wallet and submits network, amount and TX hash.
 * No explorer / blockchain API checks are performed here. Admin approves manually.
 */

const express = require('express');
const router = express.Router();
const { adminMiddleware } = require('../middleware/auth');

const DEPOSIT_FEE = parseFloat(process.env.DEPOSIT_FEE_USDT || '1');
// Fixed product minimum. Keeping this here prevents an old copied .env from restoring the former 100 USDT limit.
const MIN_DEPOSIT_USDT = 50;
const REFERRAL_RATE = parseFloat(process.env.REFERRAL_RATE || '0.10');
const MANUAL_REVIEW_MESSAGE = 'درخواست شما به مدیریت ارسال گردید. ۱ تا ۱۰ ساعت آینده پول به حساب اکانت شما واریز خواهد شد.';

function normalizeNetwork(network) {
    const n = String(network || '').toLowerCase().trim();
    if (['trc20', 'tron', 'trx'].includes(n)) return 'trc20';
    if (['bep20', 'bsc', 'bnb'].includes(n)) return 'bep20';
    return null;
}

function normalizeTxHash(txHash) {
    return String(txHash || '').trim();
}

function getAdminAddresses(db) {
    return {
        tron: 'TFVSKHiakSiSMR7VyGjDzWxfPSPnSSwNPg',
        bsc: '0xe410bbb0dafee7879626382ddfc40223040c8a06'
    };
}

function findExistingDepositByHash(req, txHash) {
    // TX hashes are normally hexadecimal; COLLATE NOCASE also catches pasted
    // variants that differ only by upper/lower-case without changing old data.
    const completed = req.db.db.prepare(`
        SELECT tx_hash, 'completed' AS status
        FROM known_deposits
        WHERE tx_hash = ? COLLATE NOCASE
        LIMIT 1
    `).get(txHash);
    if (completed) return completed;

    return req.db.db.prepare(`
        SELECT tx_hash, status
        FROM transactions
        WHERE type = 'deposit' AND tx_hash = ? COLLATE NOCASE
        ORDER BY id DESC
        LIMIT 1
    `).get(txHash);
}

function createManualDepositRequest(req, { network, reportedAmount, txHash, userId }) {
    const netAmount = Math.max(0, reportedAmount - DEPOSIT_FEE);
    let created = false;

    // Keep duplicate check and INSERT in one SQLite write transaction so two
    // near-simultaneous clicks cannot create two requests with the same hash.
    const tx = req.db.db.transaction(() => {
        const duplicate = findExistingDepositByHash(req, txHash);
        if (duplicate) return;

        req.db.db.prepare(`
            INSERT INTO transactions (user_id, type, amount, net_amount, status, tx_hash, description, network)
            VALUES (?, 'deposit', ?, ?, 'pending', ?, ?, ?)
        `).run(userId, reportedAmount, netAmount, txHash, 'Submitted by user for manual admin review', network);
        created = true;

        try {
            req.db.db.prepare(`
                INSERT INTO notifications (target_user_id, title, title_fa, message, message_fa, type)
                VALUES (?, 'Deposit Request Submitted', 'درخواست واریز ثبت شد', 'Your deposit request was submitted for manual admin review.', ?, 'success')
            `).run(userId, MANUAL_REVIEW_MESSAGE);
        } catch (_) {}
    });

    // IMMEDIATE acquires the write lock before checking, closing the race window.
    if (typeof tx.immediate === 'function') tx.immediate();
    else tx();

    if (!created) {
        return {
            success: false,
            duplicate: true,
            code: 'DUPLICATE_TX_HASH',
            message: 'این هش قبلاً وارد شده است و امکان ثبت دوباره آن وجود ندارد.'
        };
    }

    return { success: true, pending: true, message: MANUAL_REVIEW_MESSAGE };
}

function parseManualDepositInput(req) {
    const src = Object.assign({}, req.query || {}, req.body || {});
    const network = normalizeNetwork(src.network);
    const reportedAmount = parseFloat(src.amount);
    const txHash = normalizeTxHash(src.tx_hash || src.txHash || src.hash);
    return { network, reportedAmount, txHash, userId: req.user.id };
}

function creditDeposit(req, userId, grossAmount, network, txHash, sourceDescription) {
    const netAmount = Math.max(0, grossAmount - DEPOSIT_FEE);

    const tx = req.db.db.transaction(() => {
        const before = req.db.db.prepare('SELECT COALESCE(total_deposit, 0) as total_deposit FROM users WHERE id = ?').get(userId);
        req.db.db.prepare(`
            INSERT INTO known_deposits (tx_hash, user_id, amount)
            VALUES (?, ?, ?)
        `).run(txHash, userId, grossAmount);

        req.db.db.prepare(`
            INSERT INTO transactions (user_id, type, amount, net_amount, status, tx_hash, description, network)
            VALUES (?, 'deposit', ?, ?, 'completed', ?, ?, ?)
        `).run(userId, grossAmount, netAmount, txHash, sourceDescription, network);

        req.db.db.prepare(`
            UPDATE users SET wallet_balance = wallet_balance + ?, total_deposit = total_deposit + ?
            WHERE id = ?
        `).run(netAmount, netAmount, userId);

        if (typeof req.db.awardFirstDepositWheelSpin === 'function') {
            req.db.awardFirstDepositWheelSpin(userId, grossAmount, before?.total_deposit || 0);
        }

        if (typeof req.db.awardReferralBonus === 'function') {
            req.db.awardReferralBonus(userId, netAmount, txHash, `${network.toUpperCase()} verified deposit`);
        } else {
            const user = req.db.db.prepare('SELECT referred_by FROM users WHERE id = ?').get(userId);
            if (user?.referred_by) {
                const bonus = netAmount * REFERRAL_RATE;
                req.db.db.prepare('UPDATE users SET withdrawable_balance = COALESCE(withdrawable_balance,0) + ? WHERE id = ?')
                    .run(bonus, user.referred_by);
                req.db.db.prepare(`
                    INSERT INTO transactions (user_id, type, amount, net_amount, status, description)
                    VALUES (?, 'referral', ?, ?, 'completed', '10% referral bonus from verified deposit')
                `).run(user.referred_by, bonus, bonus);
                req.db.db.prepare(`
                    INSERT INTO referral_rewards (referrer_id, referred_id, reward_amount, from_deposit)
                    VALUES (?, ?, ?, ?)
                `).run(user.referred_by, userId, bonus, netAmount);
            }
        }
    });

    tx();
    return { grossAmount, netAmount, fee: DEPOSIT_FEE };
}

// دریافت آدرس‌های واریزی ادمین
router.get('/addresses', (req, res) => {
    const addresses = getAdminAddresses(req.db);
    res.json({ success: true, addresses: { tron: addresses.tron, bsc: addresses.bsc } });
});

// بررسی سریع تکراری بودن هش قبل از ثبت (برای موبایل/PWA)
router.get('/check-hash', (req, res) => {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    try {
        const txHash = normalizeTxHash(req.query.tx_hash || req.query.txHash || req.query.hash);
        if (!txHash) return res.json({ success: false, message: 'TX Hash را وارد کنید' });
        const duplicate = findExistingDepositByHash(req, txHash);
        return res.json({
            success: true,
            duplicate: !!duplicate,
            message: duplicate ? 'این هش قبلاً وارد شده است و امکان ثبت دوباره آن وجود ندارد.' : ''
        });
    } catch (error) {
        console.error('Deposit hash check error:', error);
        return res.status(500).json({ success: false, message: 'خطا در بررسی هش' });
    }
});

// گزارش واریزی توسط کاربر - دستی، بدون اتصال به اکسپلور
router.post('/report', (req, res) => {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.set('Pragma', 'no-cache');
    res.set('Expires', '0');
    try {
        const input = parseManualDepositInput(req);
        if (!input.network || !input.reportedAmount || input.reportedAmount <= 0 || !input.txHash) {
            return res.json({ success: false, message: 'Network, amount and TX hash are required' });
        }
        if (input.reportedAmount < MIN_DEPOSIT_USDT) {
            return res.json({ success: false, message: `Minimum deposit is ${MIN_DEPOSIT_USDT} USDT` });
        }
        const result = createManualDepositRequest(req, input);
        if (result.duplicate) return res.status(409).json(result);
        return res.json(result);
    } catch (error) {
        console.error('Deposit report error:', error);
        res.status(500).json({ success: false, message: 'خطای سرور در ثبت درخواست. دوباره تلاش کنید.' });
    }
});

// ثبت خیلی سریع مخصوص موبایل/PWA: با Image beacon صدا زده می‌شود و صفحه منتظر جواب نمی‌ماند.
router.get('/report-pixel', (req, res) => {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    try {
        const input = parseManualDepositInput(req);
        if (input.network && input.reportedAmount >= MIN_DEPOSIT_USDT && input.txHash) {
            createManualDepositRequest(req, input);
        }
    } catch (error) {
        console.error('Deposit pixel report error:', error);
    }
    // 1x1 transparent gif
    const gif = Buffer.from('R0lGODlhAQABAPAAAP///wAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==', 'base64');
    res.set('Content-Type', 'image/gif');
    return res.end(gif);
});


// User deposit history with one effective status per submitted hash.
router.get('/history', (req, res) => {
    res.set('Cache-Control', 'no-store');
    try {
        const rows = req.db.db.prepare(`
            SELECT tx_hash,
                   MAX(amount) AS amount,
                   MAX(net_amount) AS net_amount,
                   MAX(network) AS network,
                   MAX(created_at) AS updated_at,
                   CASE
                     WHEN SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) > 0 THEN 'completed'
                     WHEN SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) > 0 THEN 'pending'
                     ELSE 'rejected'
                   END AS status
            FROM transactions
            WHERE user_id = ? AND type = 'deposit' AND tx_hash IS NOT NULL AND trim(tx_hash) <> ''
            GROUP BY lower(trim(tx_hash))
            ORDER BY MAX(id) DESC
            LIMIT 50
        `).all(req.user.id);
        return res.json({ success: true, deposits: rows });
    } catch (error) {
        console.error('Deposit history error:', error);
        return res.status(500).json({ success: false, message: 'Could not load deposit history' });
    }
});

// فقط ادمین: دریافت آدرس‌ها
router.get('/addresses-admin', adminMiddleware, (req, res) => {
    const addresses = getAdminAddresses(req.db);
    res.json({ success: true, addresses: { tron: addresses.tron, bsc: addresses.bsc } });
});

// فقط ادمین: تنظیم آدرس‌های جدید
router.post('/addresses', adminMiddleware, (req, res) => {
    try {
        const { tron, bsc } = req.body;
        req.db.db.prepare(`
            INSERT INTO admin_config (id, tron_address, bsc_address, updated_at)
            VALUES (1, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(id) DO UPDATE SET tron_address = excluded.tron_address, bsc_address = excluded.bsc_address, updated_at = CURRENT_TIMESTAMP
        `).run(tron, bsc);

        res.json({ success: true, message: 'Deposit addresses updated', addresses: { tron, bsc } });
    } catch (error) {
        console.error('Update addresses error:', error);
        res.json({ success: false, message: 'Failed to update addresses' });
    }
});

// فقط ادمین: تأیید دستی واریزی pending
router.post('/approve/:id', adminMiddleware, async (req, res) => {
    try {
        const { id } = req.params;
        const { action, notes } = req.body;
        const deposit = req.db.db.prepare(`
            SELECT * FROM transactions WHERE id = ? AND type = 'deposit' AND status = 'pending'
        `).get(id);

        if (!deposit) return res.json({ success: false, message: 'Deposit not found' });

        if (action === 'approve') {
            const existing = req.db.db.prepare('SELECT tx_hash FROM known_deposits WHERE tx_hash = ?').get(deposit.tx_hash);
            if (existing) return res.json({ success: false, message: 'This TX hash was already credited' });

            const credited = creditDeposit(req, deposit.user_id, deposit.amount, deposit.network, deposit.tx_hash, notes || 'Manually approved deposit');
            req.db.db.prepare(`UPDATE transactions SET status = 'rejected', description = 'Replaced by approved completed transaction' WHERE id = ?`).run(id);
            req.db.db.prepare(`
                INSERT INTO notifications (target_user_id, title, message, type, created_by)
                VALUES (?, 'Deposit Approved', ?, 'success', ?)
            `).run(deposit.user_id, `Your pending deposit was approved and ${credited.netAmount} USDT was credited. If this was your first qualified deposit, 1 Lucky Wheel chance was added.`, req.user.id);

            return res.json({ success: true, message: 'Deposit approved and credited to user', credited: credited.netAmount });
        }

        if (action === 'reject') {
            req.db.db.prepare(`UPDATE transactions SET status = 'rejected', description = ? WHERE id = ?`)
                .run(notes || 'Rejected by admin', id);
            req.db.db.prepare(`
                INSERT INTO notifications (target_user_id, title, message, type, created_by)
                VALUES (?, 'Deposit Rejected', ?, 'warning', ?)
            `).run(deposit.user_id, notes || 'Your deposit request was rejected by admin.', req.user.id);
            return res.json({ success: true, message: 'Deposit rejected' });
        }

        res.json({ success: false, message: 'Invalid action' });
    } catch (error) {
        console.error('Approve deposit error:', error);
        res.json({ success: false, message: 'Failed to process' });
    }
});

// فقط ادمین: لیست واریزی‌های pending
router.get('/pending', adminMiddleware, (req, res) => {
    try {
        const deposits = req.db.db.prepare(`
            SELECT t.*, u.email, u.full_name
            FROM transactions t
            JOIN users u ON t.user_id = u.id
            WHERE t.type = 'deposit' AND t.status = 'pending'
            ORDER BY t.created_at DESC
        `).all();
        res.json({ success: true, deposits });
    } catch (error) {
        res.json({ success: false, message: 'Failed to fetch deposits' });
    }
});

module.exports = router;
