const express = require('express');
const https = require('https');
const router = express.Router();

const FALLBACK_PRICES = { BTC: 67500, ETH: 3450, DOGE: 0.12, USDT: 1 };
const MINE_ASSETS_BASE = [
  { pair: 'BTC', name: 'Bitcoin Miner', icon: '₿' },
  { pair: 'ETH', name: 'Ethereum Miner', icon: 'Ξ' },
  { pair: 'DOGE', name: 'Dogecoin Miner', icon: 'Ð' },
  { pair: 'USDT', name: 'USDT Miner', icon: '₮' }
];
const MINING_PLANS = [
  // Plan changes only affect contracts created after this release.
  // Existing mining rows keep their stored profit_percentage/profit_amount values.
  { amount: 50, profit: 15, grade: 'Starter Miner', wheel: 0 },
  { amount: 100, profit: 30, grade: 'Bronze Miner', wheel: 0 },
  { amount: 200, profit: 60, grade: 'Silver Miner', wheel: 0 },
  { amount: 500, profit: 140, grade: 'Gold Miner', wheel: 0 },
  { amount: 1000, profit: 300, grade: 'Platinum Miner', wheel: 0 },
  { amount: 1500, profit: 500, grade: 'Diamond Miner', wheel: 1 }
];
const MIN_MINE_USDT = 50;
const CYCLE_HOURS = 24;
let priceCache = { at: 0, prices: FALLBACK_PRICES };

function roundAsset(v) { return Math.round(Number(v || 0) * 1e10) / 1e10; }
function roundMoney(v) { return Math.round(Number(v || 0) * 1e8) / 1e8; }
function httpsJson(url, timeoutMs = 3500) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { timeout: timeoutMs, headers: { 'User-Agent': 'NVT-Miner/1.0' } }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch (e) { reject(e); } });
    });
    req.on('timeout', () => { req.destroy(new Error('timeout')); });
    req.on('error', reject);
  });
}
async function getLivePrices() {
  if (Date.now() - priceCache.at < 60000) return priceCache.prices;
  try {
    const url = 'https://api.binance.com/api/v3/ticker/price?symbols=%5B%22BTCUSDT%22,%22ETHUSDT%22,%22DOGEUSDT%22%5D';
    const rows = await httpsJson(url);
    const next = { ...FALLBACK_PRICES, USDT: 1 };
    for (const r of rows || []) {
      if (r.symbol === 'BTCUSDT') next.BTC = Number(r.price) || next.BTC;
      if (r.symbol === 'ETHUSDT') next.ETH = Number(r.price) || next.ETH;
      if (r.symbol === 'DOGEUSDT') next.DOGE = Number(r.price) || next.DOGE;
    }
    priceCache = { at: Date.now(), prices: next };
  } catch (e) {
    priceCache = { at: Date.now(), prices: priceCache.prices || FALLBACK_PRICES };
  }
  return priceCache.prices;
}
async function getAssets() {
  const prices = await getLivePrices();
  return MINE_ASSETS_BASE.map(a => ({ ...a, price: prices[a.pair] || FALLBACK_PRICES[a.pair], price_source: a.pair === 'USDT' ? 'fixed' : 'live' }));
}
function getAssetBalanceRows(db, userId) {
  const rows = db.prepare(`SELECT asset, amount FROM crypto_balances WHERE user_id = ? ORDER BY asset`).all(userId);
  const map = Object.fromEntries((rows || []).map(r => [String(r.asset).toUpperCase(), Number(r.amount || 0)]));
  return ['BTC','ETH','DOGE'].map(asset => ({ asset, amount: Number(map[asset] || 0) }));
}
function addCryptoBalance(db, userId, asset, amount) {
  db.prepare(`
    INSERT INTO crypto_balances (user_id, asset, amount, updated_at)
    VALUES (?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(user_id, asset) DO UPDATE SET amount = amount + excluded.amount, updated_at = CURRENT_TIMESTAMP
  `).run(userId, asset, roundAsset(amount));
}
function getActiveReferralCount(db, userId) {
  try { return db.prepare(`SELECT COUNT(*) as count FROM users WHERE referred_by = ? AND role = 'user' AND total_deposit > 0`).get(String(userId))?.count || 0; }
  catch (e) { return 0; }
}
function getReferralBoost(activeRefs) {
  if (activeRefs >= 50) return { stage: 'Golden Pool', boost: 100, wheel: 30, label: '50 referrals: 100% mining boost + 30 wheels / 24h' };
  if (activeRefs >= 20) return { stage: 'Stage 3', boost: 50, wheel: 10, label: '20 referrals: 50% mining boost + 10 wheels' };
  if (activeRefs >= 10) return { stage: 'Stage 2', boost: 25, wheel: 4, label: '10 referrals: 25% mining boost + 4 wheels' };
  if (activeRefs >= 5) return { stage: 'Stage 1', boost: 15, wheel: 2, label: '5 referrals: 15% mining boost + 2 wheels' };
  if (activeRefs >= 3) return { stage: 'Referral Boost', boost: 10, wheel: 0, label: '3 referrals: 10% mining boost' };
  if (activeRefs >= 1) return { stage: 'Referral Boost', boost: 5, wheel: 0, label: '1 referral: 5% mining boost' };
  return { stage: 'Starter', boost: 0, wheel: 0, label: 'Invite active referrals to increase mining boost' };
}
function getPlan(amount) { return MINING_PLANS.find(p => Number(p.amount) === Number(amount || 0)) || null; }
function isReady(row) {
  const start = new Date(String(row.created_at).replace(' ', 'T') + 'Z').getTime();
  return Date.now() - start >= CYCLE_HOURS * 60 * 60 * 1000;
}

function settleMiningRow(db, row) {
  const asset = String(row.pair || 'USDT').toUpperCase();
  const principal = Number(row.amount || 0);
  const profitUsdt = Number(row.profit_amount || 0);
  const assetPrice = Number(row.asset_price || 1) || 1;
  const profitAssetAmount = asset === 'USDT' ? profitUsdt : roundAsset(profitUsdt / assetPrice);

  const tx = db.transaction(() => {
    const changed = db.prepare(`
      UPDATE trades
      SET status = 'completed', closed_at = CURRENT_TIMESTAMP
      WHERE id = ? AND status = 'mining'
    `).run(row.id);

    if (changed.changes !== 1) return false;

    // Preserve the original contract values exactly as stored in the database.
    // Principal returns to locked miner balance; only profit becomes withdrawable/asset credit.
    db.prepare(`
      UPDATE users
      SET wallet_balance = COALESCE(wallet_balance, 0) + ?, total_profit = COALESCE(total_profit, 0) + ?
      WHERE id = ?
    `).run(principal, profitUsdt, row.user_id);

    if (asset === 'USDT') {
      db.prepare(`
        UPDATE users
        SET withdrawable_balance = COALESCE(withdrawable_balance, 0) + ?
        WHERE id = ?
      `).run(profitUsdt, row.user_id);
    } else {
      addCryptoBalance(db, row.user_id, asset, profitAssetAmount);
    }

    db.prepare(`
      INSERT INTO transactions
      (user_id, type, amount, net_amount, status, description)
      VALUES (?, 'mining_claim', ?, ?, 'completed', ?)
    `).run(
      row.user_id,
      profitUsdt,
      profitUsdt,
      `Mining contract #${row.id} completed automatically. Principal returned to miner balance.`
    );

    const enMessage = asset === 'USDT'
      ? `Your 24-hour miner completed automatically. ${principal.toFixed(2)} USDT principal returned to Miner Balance and ${profitUsdt.toFixed(2)} USDT profit was added to your withdrawable balance.`
      : `Your 24-hour miner completed automatically. ${principal.toFixed(2)} USDT principal returned to Miner Balance and ${profitAssetAmount} ${asset} mining profit was added to your asset balance.`;
    const faMessage = asset === 'USDT'
      ? `ماینر ۲۴ ساعته شما به‌صورت خودکار تکمیل شد. ${principal.toFixed(2)} تتر اصل مبلغ به موجودی ماینر برگشت و ${profitUsdt.toFixed(2)} تتر سود به موجودی قابل برداشت شما اضافه شد.`
      : `ماینر ۲۴ ساعته شما به‌صورت خودکار تکمیل شد. ${principal.toFixed(2)} تتر اصل مبلغ به موجودی ماینر برگشت و ${profitAssetAmount} ${asset} سود ماین به موجودی دارایی شما اضافه شد.`;

    db.prepare(`
      INSERT INTO notifications
      (target_user_id, title, title_fa, message, message_fa, type, created_at)
      VALUES (?, ?, ?, ?, ?, 'mining_auto_claim', CURRENT_TIMESTAMP)
    `).run(
      row.user_id,
      'Miner completed and credited',
      'ماینر تکمیل و به حساب اضافه شد',
      enMessage,
      faMessage
    );

    return true;
  });

  if (!tx()) return null;
  return {
    id: row.id,
    user_id: row.user_id,
    asset,
    principal_returned: principal,
    profit_usdt: profitUsdt,
    profit_asset_amount: profitAssetAmount
  };
}

function autoClaimCompletedMining(db, userId = null, limit = 200) {
  const whereUser = userId == null ? '' : ' AND user_id = ?';
  const sql = `
    SELECT * FROM trades
    WHERE status = 'mining'
      AND datetime(COALESCE(NULLIF(claimable_at, ''), datetime(created_at, '+24 hours'))) <= CURRENT_TIMESTAMP
      ${whereUser}
    ORDER BY id ASC
    LIMIT ?
  `;
  const rows = userId == null
    ? db.prepare(sql).all(limit)
    : db.prepare(sql).all(userId, limit);
  const settled = [];
  for (const row of rows) {
    const result = settleMiningRow(db, row);
    if (result) settled.push(result);
  }
  return settled;
}

router.get('/pairs', async (req, res) => {
  try {
    const autoClaims = autoClaimCompletedMining(req.db.db, req.user.id);
    const user = req.db.db.prepare('SELECT wallet_balance, COALESCE(withdrawable_balance,0) as withdrawable_balance, total_deposit FROM users WHERE id = ?').get(req.user.id);
    const activeRefs = getActiveReferralCount(req.db.db, req.user.id);
    const boost = getReferralBoost(activeRefs);
    const activeMining = req.db.db.prepare(`SELECT * FROM trades WHERE user_id = ? AND status = 'mining' ORDER BY created_at DESC`).all(req.user.id)
      .map(t => ({ ...t, ready_to_claim: isReady(t) }));
    const assets = await getAssets();
    res.json({
      success: true,
      pairs: assets,
      assets,
      prices: Object.fromEntries(assets.map(a => [a.pair, a.price])),
      asset_balances: getAssetBalanceRows(req.db.db, req.user.id),
      locked_usdt_balance: Number(user?.wallet_balance || 0),
      withdrawable_usdt_balance: Number(user?.withdrawable_balance || 0),
      plans: MINING_PLANS,
      mining_plans: MINING_PLANS,
      active_mining: activeMining,
      used_pairs: activeMining.map(r => r.pair),
      trades_remaining: null,
      daily_trade_limit: null,
      can_trade: Number(user?.wallet_balance || 0) >= MIN_MINE_USDT,
      min_trade: MIN_MINE_USDT,
      cycle_hours: CYCLE_HOURS,
      active_referrals: activeRefs,
      referral_boost: boost,
      vip: { level: boost.stage, min: 0, max: 0, range: boost.label, daily_trades: null },
      auto_claims: autoClaims
    });
  } catch (error) {
    console.error('Mining status error:', error);
    res.json({ success: false, message: 'Error loading mining data' });
  }
});

router.post('/execute', async (req, res) => {
  try {
    const { pair, amount } = req.body;
    const assets = await getAssets();
    const selectedAsset = assets.find(a => a.pair === pair || `${a.pair}/USDT` === pair);
    const plan = getPlan(amount);
    if (!selectedAsset) return res.json({ success: false, message: 'Invalid mining asset' });
    if (!plan) return res.json({ success: false, message: 'Choose one of the available mining plans' });

    const user = req.db.db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
    if (Number(user.wallet_balance || 0) + 0.000001 < plan.amount) return res.json({ success: false, message: 'Insufficient balance' });

    const activeRefs = getActiveReferralCount(req.db.db, req.user.id);
    const boost = getReferralBoost(activeRefs);
    const extraProfit = Number(((plan.profit * boost.boost) / 100).toFixed(8));
    const profitAmount = roundMoney(plan.profit + extraProfit);
    const returnUsdt = roundMoney(plan.amount + profitAmount);
    const price = Number(selectedAsset.price || 1);
    const assetAmount = selectedAsset.pair === 'USDT' ? returnUsdt : roundAsset(returnUsdt / price);
    const profitPercentage = Number(((profitAmount / plan.amount) * 100).toFixed(4));

    const insert = req.db.db.transaction(() => {
      req.db.db.prepare('UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?').run(plan.amount, req.user.id);
      const result = req.db.db.prepare(`
        INSERT INTO trades (user_id, pair, direction, amount, profit_percentage, profit_amount, status, asset_price, asset_amount, return_usdt, claimable_at)
        VALUES (?, ?, 'CLOUD_MINING_24H', ?, ?, ?, 'mining', ?, ?, ?, datetime('now', '+24 hours'))
      `).run(req.user.id, selectedAsset.pair, plan.amount, profitPercentage, profitAmount, price, assetAmount, returnUsdt);
      if (plan.wheel > 0) req.db.db.prepare('UPDATE users SET wheel_spins = COALESCE(wheel_spins, 0) + ? WHERE id = ?').run(plan.wheel, req.user.id);
      req.db.db.prepare(`INSERT INTO transactions (user_id, type, amount, net_amount, status, description) VALUES (?, 'mining_invest', ?, ?, 'pending', ?)`).run(req.user.id, plan.amount, plan.amount, `${plan.grade} started on ${selectedAsset.pair}`);
      return result;
    })();

    res.json({ success: true, message: '24h mining contract started. It will be credited automatically after 24 hours.', trade: { id: insert.lastInsertRowid, pair: selectedAsset.pair, amount: plan.amount, asset_price: price, asset_amount: assetAmount, grade: plan.grade, profit_percentage: profitPercentage, profit_amount: profitAmount, total_return: returnUsdt, status: 'mining', cycle_hours: CYCLE_HOURS, wheel_bonus: plan.wheel } });
  } catch (error) {
    console.error('Mining start error:', error);
    res.json({ success: false, message: 'Mining request failed' });
  }
});

router.post('/claim/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const settled = autoClaimCompletedMining(req.db.db, req.user.id);
    const justSettled = settled.find(item => Number(item.id) === id);
    if (justSettled) {
      return res.json({
        success: true,
        message: 'This miner was completed and credited automatically.',
        auto_claimed: true,
        ...justSettled
      });
    }

    const row = req.db.db.prepare(`SELECT * FROM trades WHERE id = ? AND user_id = ?`).get(id, req.user.id);
    if (!row) return res.json({ success: false, message: 'Mining contract not found' });
    if (row.status === 'completed') {
      return res.json({ success: true, message: 'This miner has already been credited automatically.', auto_claimed: true });
    }
    return res.json({ success: false, message: 'Manual claim is disabled. The miner will be credited automatically after 24 hours.' });
  } catch (error) {
    console.error('Mining auto-claim check error:', error);
    res.json({ success: false, message: 'Could not check mining contract' });
  }
});

router.post('/convert', async (req, res) => {
  try {
    const asset = String(req.body.asset || '').toUpperCase();
    const amount = roundAsset(req.body.amount);
    if (!['BTC','ETH','DOGE'].includes(asset)) return res.json({ success: false, message: 'Only BTC, ETH and DOGE can be converted to USDT' });
    if (!amount || amount <= 0) return res.json({ success: false, message: 'Invalid amount' });
    const bal = req.db.db.prepare(`SELECT amount FROM crypto_balances WHERE user_id = ? AND asset = ?`).get(req.user.id, asset);
    if (!bal || Number(bal.amount || 0) + 1e-10 < amount) return res.json({ success: false, message: 'Insufficient asset balance' });
    const prices = await getLivePrices();
    const usdt = roundMoney(amount * Number(prices[asset] || FALLBACK_PRICES[asset]));
    const tx = req.db.db.transaction(() => {
      req.db.db.prepare(`UPDATE crypto_balances SET amount = amount - ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ? AND asset = ?`).run(amount, req.user.id, asset);
      req.db.db.prepare(`UPDATE users SET withdrawable_balance = COALESCE(withdrawable_balance,0) + ? WHERE id = ?`).run(usdt, req.user.id);
      req.db.db.prepare(`INSERT INTO transactions (user_id, type, amount, net_amount, status, description) VALUES (?, 'asset_convert', ?, ?, 'completed', ?)`).run(req.user.id, usdt, usdt, `Converted ${amount} ${asset} to ${usdt} USDT`);
    });
    tx();
    res.json({ success: true, message: `Converted to ${usdt} USDT`, usdt, price: prices[asset] });
  } catch (error) {
    console.error('Asset convert error:', error);
    res.json({ success: false, message: 'Conversion failed' });
  }
});

router.get('/history', (req, res) => {
  try {
    const autoClaims = autoClaimCompletedMining(req.db.db, req.user.id);
    const trades = req.db.db.prepare(`SELECT * FROM trades WHERE user_id = ? ORDER BY created_at DESC LIMIT 50`).all(req.user.id).map(t => ({ ...t, ready_to_claim: t.status === 'mining' && isReady(t) }));
    const stats = req.db.db.prepare(`
      SELECT COUNT(*) as total_trades,
             SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as winning_trades,
             SUM(CASE WHEN status = 'mining' THEN 1 ELSE 0 END) as active_mining,
             COALESCE(SUM(CASE WHEN status IN ('completed','mining') THEN profit_amount ELSE 0 END), 0) as total_profit
      FROM trades WHERE user_id = ?
    `).get(req.user.id);
    res.json({ success: true, trades, stats, asset_balances: getAssetBalanceRows(req.db.db, req.user.id), auto_claims: autoClaims });
  } catch (error) {
    res.json({ success: false, message: 'Error fetching mining history' });
  }
});

router.runAutoClaims = autoClaimCompletedMining;
module.exports = router;
