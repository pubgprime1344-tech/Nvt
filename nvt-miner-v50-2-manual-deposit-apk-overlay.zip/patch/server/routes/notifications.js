const express = require('express');
const router = express.Router();

const FA_FALLBACKS = {
  'Support replied': 'پشتیبانی پاسخ داد',
  'Admin replied to your support ticket.': 'ادمین به تیکت پشتیبانی شما پاسخ داد.',
  'Ticket status updated': 'وضعیت تیکت تغییر کرد',
  'Withdrawal Approved': 'برداشت تایید شد',
  'Withdrawal Rejected': 'برداشت رد شد',
  'Deposit Approved': 'واریز تایید شد',
  'Deposit Rejected': 'واریز رد شد',
  'KYC Approved': 'احراز هویت تایید شد',
  'KYC Rejected': 'احراز هویت رد شد',
  'Lucky Wheel reward': 'جایزه گردونه شانس',
  'Lucky Wheel chance unlocked': 'یک شانس گردونه برای شما فعال شد',
  'Lucky Wheel chances updated': 'شانس‌های گردونه به‌روزرسانی شد'
};

function localize(row, lang) {
  if (lang === 'fa') {
    return {
      ...row,
      title: row.title_fa || FA_FALLBACKS[row.title] || row.title,
      message: row.message_fa || FA_FALLBACKS[row.message] || row.message
    };
  }
  return row;
}

// User notification list: broadcast + targeted
router.get('/', (req, res) => {
    try {
        const lang = String(req.query.lang || 'en').toLowerCase();
        const rows = req.db.db.prepare(`
            SELECT n.id, n.title, n.title_fa, n.message, n.message_fa, n.type, n.created_at,
                   CASE WHEN r.read_at IS NULL THEN 0 ELSE 1 END AS is_read,
                   r.read_at
            FROM notifications n
            LEFT JOIN notification_reads r
              ON r.notification_id = n.id AND r.user_id = ?
            WHERE (n.target_user_id IS NULL OR n.target_user_id = ?)
              AND NOT (
                   lower(COALESCE(n.message, '')) LIKE '%will soon add the wheel of fortune%'
                OR (lower(COALESCE(n.title, '')) LIKE '%lucky spin%' AND lower(COALESCE(n.message, '')) LIKE '%soon%')
                OR (COALESCE(n.message_fa, '') LIKE '%به زودی%' AND COALESCE(n.message_fa, '') LIKE '%چرخ شانس%')
              )
            ORDER BY n.created_at DESC
            LIMIT 100
        `).all(req.user.id, req.user.id).map(r => localize(r, lang));
        const unread = rows.filter(r => !r.is_read).length;
        res.json({ success: true, unread, notifications: rows });
    } catch (error) {
        console.error('Notifications list error:', error);
        res.json({ success: false, message: 'Error fetching notifications' });
    }
});

router.get('/unread-count', (req, res) => {
    try {
        const row = req.db.db.prepare(`
            SELECT COUNT(*) as count
            FROM notifications n
            LEFT JOIN notification_reads r
              ON r.notification_id = n.id AND r.user_id = ?
            WHERE (n.target_user_id IS NULL OR n.target_user_id = ?)
              AND r.read_at IS NULL
              AND NOT (
                   lower(COALESCE(n.message, '')) LIKE '%will soon add the wheel of fortune%'
                OR (lower(COALESCE(n.title, '')) LIKE '%lucky spin%' AND lower(COALESCE(n.message, '')) LIKE '%soon%')
                OR (COALESCE(n.message_fa, '') LIKE '%به زودی%' AND COALESCE(n.message_fa, '') LIKE '%چرخ شانس%')
              )

        `).get(req.user.id, req.user.id);
        res.json({ success: true, unread: row.count || 0 });
    } catch (error) {
        res.json({ success: false, unread: 0 });
    }
});

router.post('/:id/read', (req, res) => {
    try {
        const notification = req.db.db.prepare(`
            SELECT id FROM notifications
            WHERE id = ? AND (target_user_id IS NULL OR target_user_id = ?)
        `).get(req.params.id, req.user.id);
        if (!notification) return res.json({ success: false, message: 'Notification not found' });

        req.db.db.prepare(`
            INSERT INTO notification_reads (notification_id, user_id, read_at)
            VALUES (?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(notification_id, user_id) DO UPDATE SET read_at = CURRENT_TIMESTAMP
        `).run(req.params.id, req.user.id);
        res.json({ success: true });
    } catch (error) {
        console.error('Notification read error:', error);
        res.json({ success: false, message: 'Could not mark as read' });
    }
});

router.post('/mark-all-read', (req, res) => {
    try {
        const notifications = req.db.db.prepare(`
            SELECT n.id FROM notifications n
            WHERE (n.target_user_id IS NULL OR n.target_user_id = ?)
              AND NOT (
                   lower(COALESCE(n.message, '')) LIKE '%will soon add the wheel of fortune%'
                OR (lower(COALESCE(n.title, '')) LIKE '%lucky spin%' AND lower(COALESCE(n.message, '')) LIKE '%soon%')
                OR (COALESCE(n.message_fa, '') LIKE '%به زودی%' AND COALESCE(n.message_fa, '') LIKE '%چرخ شانس%')
              )
        `).all(req.user.id);
        const mark = req.db.db.prepare(`
            INSERT INTO notification_reads (notification_id, user_id, read_at)
            VALUES (?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(notification_id, user_id) DO UPDATE SET read_at = CURRENT_TIMESTAMP
        `);
        const tx = req.db.db.transaction(() => {
            notifications.forEach(n => mark.run(n.id, req.user.id));
        });
        tx();
        res.json({ success: true, count: notifications.length });
    } catch (error) {
        console.error('Mark all notifications error:', error);
        res.json({ success: false, message: 'Could not mark notifications' });
    }
});

module.exports = router;
