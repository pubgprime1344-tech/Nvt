const express = require('express');
const router = express.Router();
const { adminMiddleware } = require('../middleware/auth');

function clean(value, max = 1000) {
    return String(value || '').trim().slice(0, max);
}

function isTicketOwnerOrAdmin(ticket, user) {
    return user.role === 'admin' || Number(ticket.user_id) === Number(user.id);
}

function notifyUser(db, userId, title, message, type = 'info', createdBy = null) {
    try {
        db.prepare(`INSERT INTO notifications (target_user_id, title, message, type, created_by) VALUES (?, ?, ?, ?, ?)`)
            .run(userId, title, message, type, createdBy);
    } catch (e) {
        console.error('Ticket notification error:', e.message);
    }
}

// User: list own tickets
router.get('/my', (req, res) => {
    try {
        const tickets = req.db.db.prepare(`
            SELECT t.*, COUNT(m.id) as message_count,
                   MAX(m.created_at) as last_message_at
            FROM tickets t
            LEFT JOIN ticket_messages m ON m.ticket_id = t.id
            WHERE t.user_id = ?
            GROUP BY t.id
            ORDER BY t.updated_at DESC, t.id DESC
            LIMIT 100
        `).all(req.user.id);
        res.json({ success: true, tickets });
    } catch (error) {
        console.error('Ticket list error:', error);
        res.json({ success: false, message: 'Could not load tickets' });
    }
});

// Admin: list all tickets
router.get('/admin', adminMiddleware, (req, res) => {
    try {
        const status = clean(req.query.status || 'open', 24).toLowerCase();
        const params = [];
        let where = '';
        if (['open', 'answered', 'closed'].includes(status)) {
            where = 'WHERE t.status = ?';
            params.push(status);
        }
        const tickets = req.db.db.prepare(`
            SELECT t.*, u.email, u.full_name, u.user_uid, COUNT(m.id) as message_count,
                   MAX(m.created_at) as last_message_at
            FROM tickets t
            JOIN users u ON u.id = t.user_id
            LEFT JOIN ticket_messages m ON m.ticket_id = t.id
            ${where}
            GROUP BY t.id
            ORDER BY t.admin_unread DESC, t.updated_at DESC, t.id DESC
            LIMIT 200
        `).all(...params);
        const counts = req.db.db.prepare(`
            SELECT
              COALESCE(SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END),0) as open,
              COALESCE(SUM(CASE WHEN status = 'answered' THEN 1 ELSE 0 END),0) as answered,
              COALESCE(SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END),0) as closed,
              COALESCE(SUM(CASE WHEN admin_unread > 0 THEN 1 ELSE 0 END),0) as unread
            FROM tickets
        `).get();
        res.json({ success: true, tickets, counts });
    } catch (error) {
        console.error('Admin ticket list error:', error);
        res.json({ success: false, message: 'Could not load tickets' });
    }
});

// Admin/user: ticket detail
router.get('/:id', (req, res) => {
    try {
        const ticket = req.db.db.prepare(`
            SELECT t.*, u.email, u.full_name, u.user_uid
            FROM tickets t JOIN users u ON u.id = t.user_id
            WHERE t.id = ?
        `).get(req.params.id);
        if (!ticket || !isTicketOwnerOrAdmin(ticket, req.user)) {
            return res.status(404).json({ success: false, message: 'Ticket not found' });
        }
        if (req.user.role === 'admin') {
            req.db.db.prepare('UPDATE tickets SET admin_unread = 0 WHERE id = ?').run(ticket.id);
        } else {
            req.db.db.prepare('UPDATE tickets SET user_unread = 0 WHERE id = ? AND user_id = ?').run(ticket.id, req.user.id);
        }
        const messages = req.db.db.prepare(`
            SELECT tm.*, u.full_name, u.email, u.user_uid
            FROM ticket_messages tm
            LEFT JOIN users u ON u.id = tm.sender_id
            WHERE tm.ticket_id = ?
            ORDER BY tm.created_at ASC
        `).all(ticket.id);
        res.json({ success: true, ticket, messages });
    } catch (error) {
        console.error('Ticket detail error:', error);
        res.json({ success: false, message: 'Could not load ticket' });
    }
});

// User: create ticket
router.post('/', (req, res) => {
    try {
        const subject = clean(req.body.subject, 160);
        const message = clean(req.body.message, 4000);
        const priority = clean(req.body.priority || 'normal', 20).toLowerCase();
        if (!subject || !message) return res.json({ success: false, message: 'Subject and message are required' });
        if (!['low', 'normal', 'high'].includes(priority)) return res.json({ success: false, message: 'Invalid priority' });

        const tx = req.db.db.transaction(() => {
            const result = req.db.db.prepare(`
                INSERT INTO tickets (user_id, subject, priority, status, admin_unread, user_unread)
                VALUES (?, ?, ?, 'open', 1, 0)
            `).run(req.user.id, subject, priority);
            req.db.db.prepare(`
                INSERT INTO ticket_messages (ticket_id, sender_id, sender_role, message)
                VALUES (?, ?, ?, ?)
            `).run(result.lastInsertRowid, req.user.id, req.user.role, message);
            return result.lastInsertRowid;
        });
        const id = tx();
        res.json({ success: true, message: 'Ticket created successfully', ticket_id: id });
    } catch (error) {
        console.error('Create ticket error:', error);
        res.json({ success: false, message: 'Could not create ticket' });
    }
});

// Admin/user: reply
router.post('/:id/reply', (req, res) => {
    try {
        const message = clean(req.body.message, 4000);
        if (!message) return res.json({ success: false, message: 'Message is required' });
        const ticket = req.db.db.prepare('SELECT * FROM tickets WHERE id = ?').get(req.params.id);
        if (!ticket || !isTicketOwnerOrAdmin(ticket, req.user)) {
            return res.status(404).json({ success: false, message: 'Ticket not found' });
        }
        if (ticket.status === 'closed' && req.user.role !== 'admin') {
            return res.json({ success: false, message: 'This ticket is closed' });
        }

        const tx = req.db.db.transaction(() => {
            req.db.db.prepare(`
                INSERT INTO ticket_messages (ticket_id, sender_id, sender_role, message)
                VALUES (?, ?, ?, ?)
            `).run(ticket.id, req.user.id, req.user.role, message);
            if (req.user.role === 'admin') {
                req.db.db.prepare(`
                    UPDATE tickets SET status = 'answered', user_unread = user_unread + 1, admin_unread = 0, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                `).run(ticket.id);
                notifyUser(req.db.db, ticket.user_id, 'Support replied', 'Admin replied to your support ticket.', 'support', req.user.id);
            } else {
                req.db.db.prepare(`
                    UPDATE tickets SET status = 'open', admin_unread = admin_unread + 1, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                `).run(ticket.id);
            }
        });
        tx();
        res.json({ success: true, message: 'Reply sent' });
    } catch (error) {
        console.error('Ticket reply error:', error);
        res.json({ success: false, message: 'Could not send reply' });
    }
});

// Admin: change ticket status
router.patch('/:id/status', adminMiddleware, (req, res) => {
    try {
        const status = clean(req.body.status, 20).toLowerCase();
        if (!['open', 'answered', 'closed'].includes(status)) return res.json({ success: false, message: 'Invalid status' });
        const ticket = req.db.db.prepare('SELECT * FROM tickets WHERE id = ?').get(req.params.id);
        if (!ticket) return res.status(404).json({ success: false, message: 'Ticket not found' });
        req.db.db.prepare('UPDATE tickets SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(status, ticket.id);
        notifyUser(req.db.db, ticket.user_id, 'Ticket status updated', `Your ticket status is now ${status}.`, 'support', req.user.id);
        res.json({ success: true, message: 'Ticket status updated' });
    } catch (error) {
        console.error('Ticket status error:', error);
        res.json({ success: false, message: 'Could not update ticket' });
    }
});

module.exports = router;
