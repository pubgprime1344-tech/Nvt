const express = require('express');
const router = express.Router();

const PRIZES = [
  { code: 'usdt_1_30', label: '1.30 USDT', label_fa: '۱.۳۰ تتر', amount: 1.30, weight: 70, icon: '₮' },
  { code: 'usdt_1_60', label: '1.60 USDT', label_fa: '۱.۶۰ تتر', amount: 1.60, weight: 30, icon: '₮' },
  { code: 'usdt_7', label: '7 USDT', label_fa: '۷ تتر', amount: 7, weight: 20, icon: '₮' },
  { code: 'usdt_177', label: '177 USDT', label_fa: '۱۷۷ تتر', amount: 177, weight: 0, icon: '₮', displayOnly: true },
  { code: 'usdt_777', label: '777 USDT', label_fa: '۷۷۷ تتر', amount: 777, weight: 0, icon: '₮', displayOnly: true },
  { code: 'usdt_11500', label: '11500 USDT', label_fa: '۱۱۵۰۰ تتر', amount: 11500, weight: 0, icon: '₮', displayOnly: true },
  { code: 'iphone_17_promax_1t', label: 'iPhone 17 Pro Max 1T', label_fa: 'آیفون ۱۷ پرو مکس ۱ ترابایت', amount: 0, weight: 0, icon: '📱', displayOnly: true }
];

function wheelSettings(db) {
  const row = db.prepare('SELECT * FROM lucky_wheel_settings WHERE id = 1').get();
  return row || { enabled: 1, popup_enabled: 1 };
}

function isAdmin(req) {
  return req.user && req.user.role === 'admin';
}

function pickPrize() {
  const weighted = PRIZES.filter(p => Number(p.weight || 0) > 0);
  const total = weighted.reduce((sum, p) => sum + Number(p.weight || 0), 0);
  let r = Math.random() * total;
  for (const prize of weighted) {
    r -= Number(prize.weight || 0);
    if (r <= 0) return prize;
  }
  return weighted[0];
}

router.get('/status', (req, res) => {
  try {
    const settings = wheelSettings(req.db.db);
    const user = req.db.db.prepare('SELECT COALESCE(wheel_spins, 0) as wheel_spins FROM users WHERE id = ?').get(req.user.id);
    const results = req.db.db.prepare(`
      SELECT * FROM lucky_wheel_results WHERE user_id = ? ORDER BY created_at DESC LIMIT 20
    `).all(req.user.id);
    res.json({ success: true, enabled: !!settings.enabled, popup_enabled: !!settings.popup_enabled, spins: user?.wheel_spins || 0, prizes: PRIZES.map(({weight, ...p}) => p), results });
  } catch (error) {
    console.error('Wheel status error:', error);
    res.json({ success: false, message: 'Could not load lucky wheel' });
  }
});

router.post('/spin', (req, res) => {
  try {
    const settings = wheelSettings(req.db.db);
    if (!settings.enabled) return res.json({ success: false, message: 'Lucky Wheel campaign is currently inactive' });

    const user = req.db.db.prepare('SELECT id, COALESCE(wheel_spins, 0) as wheel_spins FROM users WHERE id = ?').get(req.user.id);
    if (!user || user.wheel_spins <= 0) return res.json({ success: false, message: 'You do not have any Lucky Wheel spins yet' });

    const prize = pickPrize();
    const tx = req.db.db.transaction(() => {
      req.db.db.prepare('UPDATE users SET wheel_spins = COALESCE(wheel_spins, 0) - 1 WHERE id = ? AND COALESCE(wheel_spins, 0) > 0').run(req.user.id);
      if (prize.amount > 0) {
        req.db.db.prepare('UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?').run(prize.amount, req.user.id);
        req.db.db.prepare(`
          INSERT INTO transactions (user_id, type, amount, net_amount, status, description)
          VALUES (?, 'wheel_reward', ?, ?, 'completed', ?)
        `).run(req.user.id, prize.amount, prize.amount, `Lucky Wheel reward: ${prize.label}`);
      }
      if (prize.extraSpin) {
        req.db.db.prepare('UPDATE users SET wheel_spins = COALESCE(wheel_spins, 0) + 1 WHERE id = ?').run(req.user.id);
      }
      const result = req.db.db.prepare(`
        INSERT INTO lucky_wheel_results (user_id, prize_code, prize_label, prize_amount)
        VALUES (?, ?, ?, ?)
      `).run(req.user.id, prize.code, prize.label, prize.amount || 0);
      req.db.db.prepare(`
        INSERT INTO notifications (target_user_id, title, title_fa, message, message_fa, type, created_by)
        VALUES (?, ?, ?, ?, ?, 'success', NULL)
      `).run(
        req.user.id,
        'Lucky Wheel reward',
        'جایزه گردونه شانس',
        prize.amount > 0 ? `You won ${prize.label}. It was added to your balance.` : `You won ${prize.label}.`,
        prize.amount > 0 ? `شما ${prize.label_fa} برنده شدید و به موجودی شما اضافه شد.` : `شما ${prize.label_fa} برنده شدید.`
      );
      return result.lastInsertRowid;
    });
    const resultId = tx();
    const fresh = req.db.db.prepare('SELECT COALESCE(wheel_spins, 0) as wheel_spins, wallet_balance FROM users WHERE id = ?').get(req.user.id);
    res.json({ success: true, prize: { code: prize.code, label: prize.label, label_fa: prize.label_fa, amount: prize.amount, icon: prize.icon, extraSpin: !!prize.extraSpin }, result_id: resultId, spins: fresh.wheel_spins, balance: fresh.wallet_balance });
  } catch (error) {
    console.error('Wheel spin error:', error);
    res.json({ success: false, message: 'Could not spin the Lucky Wheel' });
  }
});

router.get('/admin', (req, res) => {
  if (!isAdmin(req)) return res.status(403).json({ success: false, message: 'Admin access required' });
  try {
    const settings = wheelSettings(req.db.db);
    const stats = req.db.db.prepare(`
      SELECT COUNT(*) as total_spins, COALESCE(SUM(prize_amount),0) as total_paid
      FROM lucky_wheel_results
    `).get();
    const users = req.db.db.prepare(`
      SELECT id, user_uid, email, full_name, COALESCE(wheel_spins,0) as wheel_spins, wallet_balance
      FROM users WHERE role = 'user'
      ORDER BY wheel_spins DESC, created_at DESC LIMIT 200
    `).all();
    const results = req.db.db.prepare(`
      SELECT r.*, u.email, u.full_name, u.user_uid
      FROM lucky_wheel_results r JOIN users u ON u.id = r.user_id
      ORDER BY r.created_at DESC LIMIT 100
    `).all();
    res.json({ success: true, settings, stats, users, results, prizes: PRIZES.map(({weight, ...p}) => p) });
  } catch (error) {
    console.error('Admin wheel error:', error);
    res.json({ success: false, message: 'Could not load wheel admin panel' });
  }
});

router.patch('/admin/settings', (req, res) => {
  if (!isAdmin(req)) return res.status(403).json({ success: false, message: 'Admin access required' });
  try {
    const enabled = req.body.enabled === true || req.body.enabled === 1 || req.body.enabled === '1';
    const popupEnabled = req.body.popup_enabled === true || req.body.popup_enabled === 1 || req.body.popup_enabled === '1';
    req.db.db.prepare(`
      UPDATE lucky_wheel_settings SET enabled = ?, popup_enabled = ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1
    `).run(enabled ? 1 : 0, popupEnabled ? 1 : 0);
    res.json({ success: true, message: 'Lucky Wheel settings updated', enabled, popup_enabled: popupEnabled });
  } catch (error) {
    console.error('Update wheel settings error:', error);
    res.json({ success: false, message: 'Could not update wheel settings' });
  }
});

router.post('/admin/users/:id/spins', (req, res) => {
  if (!isAdmin(req)) return res.status(403).json({ success: false, message: 'Admin access required' });
  try {
    const userId = Number(req.params.id);
    const amount = Math.max(0, Math.floor(Number(req.body.amount || 0)));
    const mode = String(req.body.mode || 'add').toLowerCase();
    const user = req.db.db.prepare('SELECT id, COALESCE(wheel_spins,0) as wheel_spins FROM users WHERE id = ? AND role = \'user\'').get(userId);
    if (!user) return res.json({ success: false, message: 'User not found' });
    if (!['add', 'remove', 'set'].includes(mode)) return res.json({ success: false, message: 'Invalid mode' });
    let newSpins = user.wheel_spins;
    if (mode === 'add') newSpins += amount;
    if (mode === 'remove') newSpins = Math.max(0, newSpins - amount);
    if (mode === 'set') newSpins = amount;
    req.db.db.prepare('UPDATE users SET wheel_spins = ? WHERE id = ?').run(newSpins, userId);
    req.db.db.prepare(`
      INSERT INTO notifications (target_user_id, title, title_fa, message, message_fa, type, created_by)
      VALUES (?, ?, ?, ?, ?, 'info', ?)
    `).run(userId, 'Lucky Wheel chances updated', 'شانس‌های گردونه به‌روزرسانی شد', `Your Lucky Wheel chances are now ${newSpins}.`, `تعداد شانس‌های گردونه شما اکنون ${newSpins} است.`, req.user.id);
    res.json({ success: true, message: 'User wheel chances updated', spins: newSpins });
  } catch (error) {
    console.error('Update user wheel spins error:', error);
    res.json({ success: false, message: 'Could not update user spins' });
  }
});

module.exports = router;
