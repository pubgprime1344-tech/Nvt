const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const { adminMiddleware } = require('../middleware/auth');
const REFERRAL_RATE = parseFloat(process.env.REFERRAL_RATE || '0.10');

// Apply admin middleware to all routes
router.use(adminMiddleware);

// Get admin dashboard stats
router.get('/stats', (req, res) => {
    try {
        const userStats = req.db.db.prepare(`
            SELECT 
                COUNT(*) as total_users,
                COALESCE(SUM(wallet_balance), 0) as total_user_balance,
                COALESCE(SUM(COALESCE(withdrawable_balance,0)), 0) as total_withdrawable_balance,
                COALESCE(SUM(total_deposit), 0) as total_deposits,
                COALESCE(SUM(total_withdraw), 0) as total_withdrawals,
                COALESCE(SUM(total_profit), 0) as total_user_profits
            FROM users WHERE role = 'user'
        `).get();

        const kycStats = req.db.db.prepare(`
            SELECT 
                COALESCE(SUM(CASE WHEN kyc_status = 'pending' THEN 1 ELSE 0 END), 0) as pending_kyc,
                COALESCE(SUM(CASE WHEN kyc_status = 'approved' THEN 1 ELSE 0 END), 0) as approved_kyc,
                COALESCE(SUM(CASE WHEN kyc_status = 'rejected' THEN 1 ELSE 0 END), 0) as rejected_kyc
            FROM users WHERE role = 'user'
        `).get();

        const withdrawalStats = req.db.db.prepare(`
            SELECT 
                COALESCE(SUM(CASE WHEN status = 'pending' THEN COALESCE(net_amount, amount) ELSE 0 END), 0) as pending_withdrawals,
                COALESCE(SUM(CASE WHEN status = 'approved' THEN COALESCE(net_amount, amount) ELSE 0 END), 0) as approved_withdrawals,
                COALESCE(SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END), 0) as pending_count,
                COUNT(*) as total_count
            FROM withdrawals
        `).get();

        const tradeStats = req.db.db.prepare(`
            SELECT 
                COUNT(*) as total_trades,
                COALESCE(SUM(profit_amount), 0) as total_trade_profits
            FROM trades
        `).get();

        const depositStats = req.db.db.prepare(`
            SELECT
                COUNT(*) as total_deposit_records,
                COALESCE(SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END), 0) as confirmed_deposit_count,
                COALESCE(SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END), 0) as pending_deposit_count,
                COALESCE(SUM(CASE WHEN status = 'completed' THEN COALESCE(net_amount, amount) ELSE 0 END), 0) as confirmed_deposit_amount,
                COALESCE(SUM(CASE WHEN status = 'pending' THEN COALESCE(net_amount, amount) ELSE 0 END), 0) as pending_deposit_amount
            FROM transactions
            WHERE type = 'deposit'
        `).get();

        const recentUsers = req.db.db.prepare(`
            SELECT id, user_uid, email, full_name, wallet_balance, COALESCE(withdrawable_balance,0) as withdrawable_balance, total_deposit, kyc_status, created_at
            FROM users WHERE role = 'user'
            ORDER BY created_at DESC LIMIT 5
        `).all();

        const pendingDeposits = req.db.db.prepare(`
            SELECT t.id, t.user_id, t.amount, t.net_amount, t.tx_hash, t.network, t.created_at, u.email, u.full_name
            FROM transactions t
            JOIN users u ON u.id = t.user_id
            WHERE t.type = 'deposit' AND t.status = 'pending'
            ORDER BY t.created_at DESC LIMIT 5
        `).all();

        res.json({
            success: true,
            stats: {
                users: userStats,
                kyc: kycStats,
                withdrawals: withdrawalStats,
                trades: tradeStats,
                deposits: depositStats,
                recent_users: recentUsers,
                pending_deposits: pendingDeposits
            }
        });
    } catch (error) {
        console.error('Admin stats error:', error);
        res.json({ success: false, message: 'Error fetching stats' });
    }
});

// Get all users
router.get('/users', (req, res) => {
    try {
        const page = Math.max(1, parseInt(req.query.page) || 1);
        const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 20));
        const offset = (page - 1) * limit;
        const q = String(req.query.q || '').trim();
        const like = `%${q}%`;

        const where = q
            ? `role = 'user' AND (email LIKE ? OR full_name LIKE ? OR phone LIKE ? OR referral_code LIKE ? OR user_uid LIKE ?)`
            : `role = 'user'`;
        const params = q ? [like, like, like, like, like] : [];

        const users = req.db.db.prepare(`
            SELECT id, user_uid, email, full_name, phone, referral_code, wallet_balance, COALESCE(withdrawable_balance,0) as withdrawable_balance, COALESCE(withdrawable_balance,0) as withdrawable_balance,
                   total_deposit, total_withdraw, total_profit, kyc_status, created_at,
                   referred_by, COALESCE(withdraw_lock_disabled, 0) as withdraw_lock_disabled, COALESCE(withdraw_referral_limit_disabled, 0) as withdraw_referral_limit_disabled
            FROM users
            WHERE ${where}
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        `).all(...params, limit, offset);

        const total = req.db.db.prepare(`SELECT COUNT(*) as count FROM users WHERE ${where}`).get(...params);

        res.json({
            success: true,
            users,
            pagination: {
                page,
                limit,
                total: total.count,
                pages: Math.ceil(total.count / limit)
            }
        });
    } catch (error) {
        console.error('Admin users error:', error);
        res.json({ success: false, message: 'Error fetching users' });
    }
});

// Get one user with activity
router.get('/users/:id', (req, res) => {
    try {
        const user = req.db.db.prepare(`
            SELECT id, user_uid, email, full_name, phone, referral_code, wallet_balance, COALESCE(withdrawable_balance,0) as withdrawable_balance, COALESCE(withdrawable_balance,0) as withdrawable_balance,
                   total_deposit, total_withdraw, total_profit, kyc_status, created_at,
                   trc20_address, bep20_address, referred_by, COALESCE(withdraw_lock_disabled, 0) as withdraw_lock_disabled, COALESCE(withdraw_referral_limit_disabled, 0) as withdraw_referral_limit_disabled
            FROM users WHERE id = ? AND role = 'user'
        `).get(req.params.id);

        if (!user) return res.json({ success: false, message: 'User not found' });

        const transactions = req.db.db.prepare(`
            SELECT id, type, amount, net_amount, status, tx_hash, description, network, created_at
            FROM transactions WHERE user_id = ?
            ORDER BY created_at DESC LIMIT 20
        `).all(req.params.id);

        const trades = req.db.db.prepare(`
            SELECT id, pair, direction, amount, profit_percentage, profit_amount, status, created_at, closed_at
            FROM trades WHERE user_id = ?
            ORDER BY created_at DESC LIMIT 20
        `).all(req.params.id);
        const cryptoRows = req.db.db.prepare(`SELECT asset, amount FROM crypto_balances WHERE user_id = ? ORDER BY asset`).all(req.params.id);
        const cryptoMap = Object.fromEntries((cryptoRows || []).map(r => [String(r.asset).toUpperCase(), Number(r.amount || 0)]));
        const crypto_balances = ['BTC','ETH','DOGE'].map(asset => ({ asset, amount: Number(cryptoMap[asset] || 0) }));

        res.json({ success: true, user, transactions, trades, crypto_balances });
    } catch (error) {
        console.error('Admin user detail error:', error);
        res.json({ success: false, message: 'Error fetching user details' });
    }
});

// Update user email/profile/KYC and optionally reset password
router.patch('/users/:id', (req, res) => {
    try {
        const userId = req.params.id;
        const existing = req.db.db.prepare('SELECT id FROM users WHERE id = ? AND role = ?').get(userId, 'user');
        if (!existing) return res.json({ success: false, message: 'User not found' });

        const email = String(req.body.email || '').trim().toLowerCase();
        const fullName = String(req.body.full_name || '').trim();
        const phone = String(req.body.phone || '').trim();
        const kycStatus = String(req.body.kyc_status || '').trim();
        const password = String(req.body.password || '').trim();

        if (!email || !email.includes('@')) return res.json({ success: false, message: 'Valid email is required' });
        if (!['pending', 'approved', 'rejected'].includes(kycStatus)) {
            return res.json({ success: false, message: 'Invalid KYC status' });
        }

        const duplicate = req.db.db.prepare('SELECT id FROM users WHERE email = ? AND id != ?').get(email, userId);
        if (duplicate) return res.json({ success: false, message: 'This email is already used by another user' });

        if (password) {
            if (password.length < 6) return res.json({ success: false, message: 'Password must be at least 6 characters' });
            const hashedPassword = bcrypt.hashSync(password, 10);
            req.db.db.prepare(`
                UPDATE users SET email = ?, full_name = ?, phone = ?, kyc_status = ?, password = ?
                WHERE id = ? AND role = 'user'
            `).run(email, fullName || null, phone || null, kycStatus, hashedPassword, userId);
        } else {
            req.db.db.prepare(`
                UPDATE users SET email = ?, full_name = ?, phone = ?, kyc_status = ?
                WHERE id = ? AND role = 'user'
            `).run(email, fullName || null, phone || null, kycStatus, userId);
        }

        req.db.db.prepare(`
            INSERT INTO transactions (user_id, type, amount, net_amount, status, description)
            VALUES (?, 'admin_profile_update', 0, 0, 'completed', ?)
        `).run(userId, password ? 'Admin updated profile and reset password' : 'Admin updated profile');

        res.json({ success: true, message: 'User updated successfully' });
    } catch (error) {
        console.error('Admin update user error:', error);
        res.json({ success: false, message: 'User update failed' });
    }
});

// Adjust user balance: add, subtract, or set exact balance without changing deposit totals
router.post('/users/:id/balance', (req, res) => {
    try {
        const userId = req.params.id;
        const mode = String(req.body.mode || '').toLowerCase();
        const amount = Number(req.body.amount);
        const description = String(req.body.description || '').trim();
        const balanceType = String(req.body.balance_type || req.body.balanceType || 'locked').toLowerCase();

        if (!['add', 'subtract', 'set'].includes(mode)) return res.json({ success: false, message: 'Invalid balance mode' });
        if (!Number.isFinite(amount) || amount < 0) return res.json({ success: false, message: 'Invalid amount' });

        const user = req.db.db.prepare('SELECT id, wallet_balance, COALESCE(withdrawable_balance,0) as withdrawable_balance FROM users WHERE id = ? AND role = ?').get(userId, 'user');
        if (!user) return res.json({ success: false, message: 'User not found' });

        let delta = 0;
        if (mode === 'add') delta = amount;
        if (mode === 'subtract') delta = -amount;
        const currentBalance = balanceType === 'withdrawable' ? Number(user.withdrawable_balance || 0) : Number(user.wallet_balance || 0);
        if (mode === 'set') delta = amount - currentBalance;

        const newBalance = currentBalance + delta;
        if (newBalance < -0.000001) return res.json({ success: false, message: 'Balance cannot become negative' });

        const applyAdjustment = req.db.db.transaction(() => {
            req.db.db.prepare(balanceType === 'withdrawable' ? 'UPDATE users SET withdrawable_balance = ? WHERE id = ?' : 'UPDATE users SET wallet_balance = ? WHERE id = ?').run(Math.max(0, newBalance), userId);
            req.db.db.prepare(`
                INSERT INTO transactions (user_id, type, amount, net_amount, status, description)
                VALUES (?, 'admin_balance_adjustment', ?, ?, 'completed', ?)
            `).run(
                userId,
                delta,
                delta,
                description || `Admin ${balanceType} balance ${mode}: ${amount} USDT`
            );
        });
        applyAdjustment();

        res.json({ success: true, message: 'Balance adjusted successfully', old_balance: user.wallet_balance, new_balance: Math.max(0, newBalance), delta });
    } catch (error) {
        console.error('Admin adjust balance error:', error);
        res.json({ success: false, message: 'Balance adjustment failed' });
    }
});


// Adjust user crypto asset balance: BTC / ETH / DOGE
router.post('/users/:id/crypto-balance', (req, res) => {
    try {
        const userId = req.params.id;
        const mode = String(req.body.mode || '').toLowerCase();
        const asset = String(req.body.asset || '').trim().toUpperCase();
        const amount = Number(req.body.amount);
        const description = String(req.body.description || '').trim();
        if (!['add', 'subtract', 'set'].includes(mode)) return res.json({ success: false, message: 'Invalid balance mode' });
        if (!['BTC','ETH','DOGE'].includes(asset)) return res.json({ success: false, message: 'Invalid asset' });
        if (!Number.isFinite(amount) || amount < 0) return res.json({ success: false, message: 'Invalid amount' });
        const user = req.db.db.prepare('SELECT id FROM users WHERE id = ? AND role = ?').get(userId, 'user');
        if (!user) return res.json({ success: false, message: 'User not found' });
        const current = Number(req.db.db.prepare('SELECT amount FROM crypto_balances WHERE user_id = ? AND asset = ?').get(userId, asset)?.amount || 0);
        let delta = 0;
        if (mode === 'add') delta = amount;
        if (mode === 'subtract') delta = -amount;
        if (mode === 'set') delta = amount - current;
        const next = current + delta;
        if (next < -0.00000001) return res.json({ success: false, message: 'Asset balance cannot become negative' });
        req.db.db.transaction(() => {
            req.db.db.prepare(`
                INSERT INTO crypto_balances (user_id, asset, amount, updated_at)
                VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(user_id, asset) DO UPDATE SET amount = excluded.amount, updated_at = CURRENT_TIMESTAMP
            `).run(userId, asset, Math.max(0, next));
            req.db.db.prepare(`INSERT INTO transactions (user_id, type, amount, net_amount, status, description)
                VALUES (?, 'admin_crypto_balance_adjustment', 0, 0, 'completed', ?)`)
                .run(userId, description || `Admin ${mode} ${amount} ${asset}; new balance ${Math.max(0,next)} ${asset}`);
        })();
        res.json({ success: true, message: `${asset} balance adjusted`, old_balance: current, new_balance: Math.max(0, next), delta, asset });
    } catch (error) {
        console.error('Admin crypto balance adjustment error:', error);
        res.json({ success: false, message: 'Crypto balance adjustment failed' });
    }
});

// Enable/disable the 5-day withdrawal lock for a specific user
router.patch('/users/:id/withdraw-lock', (req, res) => {
    try {
        const userId = req.params.id;
        const disabled = req.body.disabled === true || req.body.disabled === 1 || req.body.disabled === '1' || String(req.body.disabled).toLowerCase() === 'true';
        const user = req.db.db.prepare('SELECT id FROM users WHERE id = ? AND role = ?').get(userId, 'user');
        if (!user) return res.json({ success: false, message: 'User not found' });

        req.db.db.prepare('UPDATE users SET withdraw_lock_disabled = ? WHERE id = ?').run(disabled ? 1 : 0, userId);
        req.db.db.prepare(`
            INSERT INTO transactions (user_id, type, amount, net_amount, status, description)
            VALUES (?, 'admin_withdraw_lock_update', 0, 0, 'completed', ?)
        `).run(userId, disabled ? 'Admin disabled 5-day withdrawal lock for this user' : 'Admin enabled 5-day withdrawal lock for this user');
        req.db.db.prepare(`
            INSERT INTO notifications (target_user_id, title, message, type, created_by)
            VALUES (?, 'Withdrawal Lock Updated', ?, 'info', ?)
        `).run(userId, disabled ? 'The 5-day deposit withdrawal lock has been disabled for your account by admin.' : 'The 5-day deposit withdrawal lock has been enabled for your account by admin.', req.user.id);

        res.json({ success: true, message: disabled ? '5-day withdrawal lock disabled for user' : '5-day withdrawal lock enabled for user', withdraw_lock_disabled: disabled ? 1 : 0 });
    } catch (error) {
        console.error('Withdraw lock update error:', error);
        res.json({ success: false, message: 'Could not update withdrawal lock setting' });
    }
});


// Enable/disable referral withdrawal rule for a specific user
router.patch('/users/:id/referral-withdraw-limit', (req, res) => {
    try {
        const userId = req.params.id;
        const disabled = req.body.disabled === true || req.body.disabled === 1 || req.body.disabled === '1' || String(req.body.disabled).toLowerCase() === 'true';
        const user = req.db.db.prepare('SELECT id FROM users WHERE id = ? AND role = ?').get(userId, 'user');
        if (!user) return res.json({ success: false, message: 'User not found' });
        req.db.db.prepare('UPDATE users SET withdraw_referral_limit_disabled = ? WHERE id = ?').run(disabled ? 1 : 0, userId);
        req.db.db.prepare(`INSERT INTO transactions (user_id, type, amount, net_amount, status, description) VALUES (?, 'admin_referral_withdraw_limit_update', 0, 0, 'completed', ?)`)
            .run(userId, disabled ? 'Admin disabled referral withdrawal requirement for this user' : 'Admin enabled referral withdrawal requirement for this user');
        req.db.db.prepare(`INSERT INTO notifications (target_user_id, title, message, type, created_by) VALUES (?, 'Withdrawal Referral Rule Updated', ?, 'info', ?)`)
            .run(userId, disabled ? 'The active-referral withdrawal requirement has been disabled for your account by admin.' : 'The active-referral withdrawal requirement has been enabled for your account by admin.', req.user.id);
        res.json({ success: true, message: disabled ? 'Referral withdrawal rule disabled for user' : 'Referral withdrawal rule enabled for user', withdraw_referral_limit_disabled: disabled ? 1 : 0 });
    } catch (error) {
        console.error('Referral withdraw limit update error:', error);
        res.json({ success: false, message: 'Could not update referral withdrawal rule' });
    }
});

// Bulk enable/disable referral withdrawal rule override for all users
router.patch('/users/referral-withdraw-limit/bulk', (req, res) => {
    try {
        const disabled = req.body.disabled === true || req.body.disabled === 1 || req.body.disabled === '1' || String(req.body.disabled).toLowerCase() === 'true';
        const result = req.db.db.prepare("UPDATE users SET withdraw_referral_limit_disabled = ? WHERE role = 'user'").run(disabled ? 1 : 0);
        res.json({ success: true, message: disabled ? 'Referral withdrawal rule disabled for all users' : 'Referral withdrawal rule enabled for all users', changed: result.changes || 0 });
    } catch (error) {
        console.error('Bulk referral withdraw limit update error:', error);
        res.json({ success: false, message: 'Could not update users' });
    }
});

// Get pending KYC requests
router.get('/kyc-pending', (req, res) => {
    try {
        const users = req.db.db.prepare(`
            SELECT id, user_uid, email, full_name, phone, kyc_documents, created_at
            FROM users WHERE kyc_status = 'pending' AND kyc_documents IS NOT NULL
            ORDER BY created_at DESC
        `).all().map(u => {
            try { u.kyc_documents = u.kyc_documents ? JSON.parse(u.kyc_documents) : null; } catch { u.kyc_documents = null; }
            return u;
        });

        res.json({
            success: true,
            users
        });
    } catch (error) {
        res.json({ success: false, message: 'Error fetching KYC requests' });
    }
});

// Approve/Reject KYC
router.post('/kyc/:id', (req, res) => {
    try {
        const { id } = req.params;
        const { action, notes } = req.body;

        if (!['approve', 'reject'].includes(action)) {
            return res.json({ success: false, message: 'Invalid action' });
        }

        const newStatus = action === 'approve' ? 'approved' : 'rejected';

        req.db.db.prepare('UPDATE users SET kyc_status = ? WHERE id = ?').run(newStatus, id);
        req.db.db.prepare(`
            INSERT INTO notifications (target_user_id, title, message, type, created_by)
            VALUES (?, ?, ?, ?, ?)
        `).run(
            id,
            newStatus === 'approved' ? 'KYC Approved' : 'KYC Rejected',
            newStatus === 'approved' ? 'Your identity verification has been approved.' : 'Your identity verification was rejected. Please review and submit again.',
            newStatus === 'approved' ? 'success' : 'warning',
            req.user.id
        );

        res.json({
            success: true,
            message: `KYC ${action}d successfully`
        });
    } catch (error) {
        res.json({ success: false, message: 'KYC update failed' });
    }
});


// Withdrawal limit settings
function normalizeWithdrawalSettings(body = {}) {
    const enabled = body.enabled === true || body.enabled === 1 || body.enabled === '1' || String(body.enabled).toLowerCase() === 'true';
    const requireActiveReferral = body.require_active_referral === true || body.require_active_referral === 1 || body.require_active_referral === '1' || String(body.require_active_referral).toLowerCase() === 'true';
    const minActiveReferrals = Math.max(0, parseInt(body.min_active_referrals ?? '1', 10) || 0);
    const activeReferralMinDeposit = Math.max(0, Number(body.active_referral_min_deposit ?? 100));
    let weeklyRatio = Number(body.weekly_withdraw_ratio ?? 0.3333333333);
    if (weeklyRatio > 1) weeklyRatio = weeklyRatio / 100;
    weeklyRatio = Math.min(1, Math.max(0.01, weeklyRatio));
    const weeklyWindowDays = Math.max(1, parseInt(body.weekly_window_days ?? '7', 10) || 7);
    const kycRequired = body.kyc_required === true || body.kyc_required === 1 || body.kyc_required === '1' || String(body.kyc_required).toLowerCase() === 'true';
    return { enabled, requireActiveReferral, minActiveReferrals, activeReferralMinDeposit, weeklyRatio, weeklyWindowDays, kycRequired };
}

router.get('/withdrawal-settings', (req, res) => {
    try {
        const row = req.db.db.prepare('SELECT * FROM withdrawal_settings WHERE id = 1').get() || {};
        res.json({
            success: true,
            settings: {
                enabled: Number(row.enabled ?? 1),
                require_active_referral: Number(row.require_active_referral ?? 1),
                min_active_referrals: Number(row.min_active_referrals ?? 1),
                active_referral_min_deposit: Number(row.active_referral_min_deposit ?? 100),
                weekly_withdraw_ratio: Number(row.weekly_withdraw_ratio ?? 0.3333333333),
                weekly_withdraw_percent: Math.round(Number(row.weekly_withdraw_ratio ?? 0.3333333333) * 10000) / 100,
                weekly_window_days: Number(row.weekly_window_days ?? 7),
                kyc_required: Number(row.kyc_required ?? 1),
                updated_at: row.updated_at || null
            }
        });
    } catch (error) {
        console.error('Withdrawal settings read error:', error);
        res.json({ success: false, message: 'Error fetching withdrawal settings' });
    }
});

router.patch('/withdrawal-settings', (req, res) => {
    try {
        const v = normalizeWithdrawalSettings(req.body);
        req.db.db.prepare(`
            INSERT INTO withdrawal_settings
            (id, enabled, require_active_referral, min_active_referrals, active_referral_min_deposit, weekly_withdraw_ratio, weekly_window_days, kyc_required, updated_at)
            VALUES (1, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(id) DO UPDATE SET
                enabled = excluded.enabled,
                require_active_referral = excluded.require_active_referral,
                min_active_referrals = excluded.min_active_referrals,
                active_referral_min_deposit = excluded.active_referral_min_deposit,
                weekly_withdraw_ratio = excluded.weekly_withdraw_ratio,
                weekly_window_days = excluded.weekly_window_days,
                kyc_required = excluded.kyc_required,
                updated_at = CURRENT_TIMESTAMP
        `).run(v.enabled ? 1 : 0, v.requireActiveReferral ? 1 : 0, v.minActiveReferrals, v.activeReferralMinDeposit, v.weeklyRatio, v.weeklyWindowDays, v.kycRequired ? 1 : 0);
        res.json({ success: true, message: 'Withdrawal limits updated' });
    } catch (error) {
        console.error('Withdrawal settings update error:', error);
        res.json({ success: false, message: 'Could not update withdrawal settings' });
    }
});

// Get pending withdrawals
router.get('/withdrawals', (req, res) => {
    try {
        const withdrawals = req.db.db.prepare(`
            SELECT w.*, u.email, u.full_name, u.phone
            FROM withdrawals w
            JOIN users u ON w.user_id = u.id
            WHERE w.status = 'pending'
            ORDER BY w.created_at ASC
        `).all();

        res.json({
            success: true,
            withdrawals
        });
    } catch (error) {
        res.json({ success: false, message: 'Error fetching withdrawals' });
    }
});

// Process withdrawal
router.post('/withdrawals/:id', (req, res) => {
    try {
        const { id } = req.params;
        const { action, tx_hash, notes } = req.body;

        if (!['approve', 'reject'].includes(action)) {
            return res.json({ success: false, message: 'Invalid action' });
        }

        const withdrawal = req.db.db.prepare('SELECT * FROM withdrawals WHERE id = ?').get(id);

        if (!withdrawal) {
            return res.json({ success: false, message: 'Withdrawal not found' });
        }

        if (withdrawal.status !== 'pending') {
            return res.json({ success: false, message: `Withdrawal is already ${withdrawal.status}` });
        }

        if (action === 'approve') {
            // Update withdrawal status
            req.db.db.prepare(`
                UPDATE withdrawals SET 
                    status = 'approved',
                    tx_hash = ?,
                    admin_notes = ?,
                    processed_at = CURRENT_TIMESTAMP
                WHERE id = ?
            `).run(tx_hash || `TX-${Date.now()}`, notes, id);

            const asset = String(withdrawal.asset || 'USDT').toUpperCase();
            const netToSend = Number(withdrawal.net_amount || withdrawal.amount || 0);
            const netToSendUsdt = Number(withdrawal.amount_usdt || (netToSend * Number(withdrawal.asset_price || 1)) || netToSend);

            // Update user total withdraw in USDT value
            req.db.db.prepare(`
                UPDATE users SET total_withdraw = total_withdraw + ? WHERE id = ?
            `).run(netToSendUsdt, withdrawal.user_id);

            // Update transaction
            req.db.db.prepare(`
                UPDATE transactions SET status = 'completed'
                WHERE user_id = ? AND type = 'withdraw_request' AND status = 'pending'
            `).run(withdrawal.user_id);

            req.db.db.prepare(`
                INSERT INTO notifications (target_user_id, title, message, type, created_by)
                VALUES (?, 'Withdrawal Approved', ?, 'success', ?)
            `).run(withdrawal.user_id, `Your withdrawal was approved. Net amount sent: ${netToSend} ${asset}.`, req.user.id);

            res.json({
                success: true,
                message: 'Withdrawal approved and processed'
            });
        } else {
            // Return the full requested amount to the same internal asset when rejected
            const asset = String(withdrawal.asset || 'USDT').toUpperCase();
            if (asset === 'USDT') {
                req.db.db.prepare(`UPDATE users SET withdrawable_balance = COALESCE(withdrawable_balance,0) + ? WHERE id = ?`).run(withdrawal.amount, withdrawal.user_id);
            } else {
                req.db.db.prepare(`
                    INSERT INTO crypto_balances (user_id, asset, amount, updated_at)
                    VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(user_id, asset) DO UPDATE SET amount = amount + excluded.amount, updated_at = CURRENT_TIMESTAMP
                `).run(withdrawal.user_id, asset, withdrawal.amount);
            }

            // Update withdrawal status
            req.db.db.prepare(`
                UPDATE withdrawals SET 
                    status = 'rejected',
                    admin_notes = ?,
                    processed_at = CURRENT_TIMESTAMP
                WHERE id = ?
            `).run(notes, id);

            // Update transaction
            req.db.db.prepare(`
                UPDATE transactions SET status = 'rejected'
                WHERE user_id = ? AND type = 'withdraw_request' AND status = 'pending'
            `).run(withdrawal.user_id);

            req.db.db.prepare(`
                INSERT INTO notifications (target_user_id, title, message, type, created_by)
                VALUES (?, 'Withdrawal Rejected', 'Your withdrawal request was rejected and the requested amount was returned to your balance.', 'warning', ?)
            `).run(withdrawal.user_id, req.user.id);

            res.json({
                success: true,
                message: 'Withdrawal rejected and funds returned'
            });
        }
    } catch (error) {
        console.error('Withdrawal process error:', error);
        res.json({ success: false, message: 'Withdrawal processing failed' });
    }
});

// Add balance to user (manual deposit that counts as a confirmed deposit and referral source)
router.post('/deposit', (req, res) => {
    try {
        const { user_id, amount, description } = req.body;
        const numericAmount = Number(amount);

        if (!user_id || !Number.isFinite(numericAmount) || numericAmount <= 0) {
            return res.json({ success: false, message: 'Invalid parameters' });
        }

        const target = req.db.db.prepare('SELECT id, referred_by, COALESCE(total_deposit,0) as total_deposit FROM users WHERE id = ? AND role = ?').get(user_id, 'user');
        if (!target) return res.json({ success: false, message: 'User not found' });

        const tx = req.db.db.transaction(() => {
            req.db.db.prepare(`
                UPDATE users SET
                    wallet_balance = wallet_balance + ?,
                    total_deposit = total_deposit + ?
                WHERE id = ?
            `).run(numericAmount, numericAmount, user_id);

            req.db.db.prepare(`
                INSERT INTO transactions (user_id, type, amount, net_amount, status, description)
                VALUES (?, 'deposit', ?, ?, 'completed', ?)
            `).run(user_id, numericAmount, numericAmount, description || 'Admin confirmed manual deposit');

            if (typeof req.db.awardFirstDepositWheelSpin === 'function') {
                req.db.awardFirstDepositWheelSpin(user_id, numericAmount, target.total_deposit || 0);
            }

            if (typeof req.db.awardReferralBonus === 'function') {
                req.db.awardReferralBonus(user_id, numericAmount, null, 'admin deposit');
            } else if (target.referred_by) {
                const bonus = numericAmount * REFERRAL_RATE;
                req.db.db.prepare('UPDATE users SET withdrawable_balance = COALESCE(withdrawable_balance,0) + ? WHERE id = ?').run(bonus, target.referred_by);
                req.db.db.prepare(`
                    INSERT INTO transactions (user_id, type, amount, net_amount, status, description)
                    VALUES (?, 'referral', ?, ?, 'completed', '10% referral bonus from admin deposit')
                `).run(target.referred_by, bonus, bonus);
                req.db.db.prepare(`
                    INSERT INTO referral_rewards (referrer_id, referred_id, reward_amount, from_deposit)
                    VALUES (?, ?, ?, ?)
                `).run(target.referred_by, user_id, bonus, numericAmount);
            }
        });

        tx();
        const updated = req.db.db.prepare('SELECT wallet_balance, total_deposit FROM users WHERE id = ?').get(user_id);

        res.json({
            success: true,
            message: 'Deposit credited successfully',
            user: updated
        });
    } catch (error) {
        console.error('Admin deposit error:', error);
        res.json({ success: false, message: 'Operation failed' });
    }
});

// Get all transactions
router.get('/transactions', (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 50;
        const offset = (page - 1) * limit;

        const transactions = req.db.db.prepare(`
            SELECT t.*, u.email
            FROM transactions t
            JOIN users u ON t.user_id = u.id
            ORDER BY t.created_at DESC
            LIMIT ? OFFSET ?
        `).all(limit, offset);

        res.json({
            success: true,
            transactions
        });
    } catch (error) {
        res.json({ success: false, message: 'Error fetching transactions' });
    }
});


// Get all KYC requests for a dedicated admin page
router.get('/kyc-requests', (req, res) => {
    try {
        const status = String(req.query.status || 'pending').toLowerCase();
        const where = ['u.role = \'user\'', 'u.kyc_documents IS NOT NULL'];
        const params = [];
        if (['pending', 'approved', 'rejected'].includes(status)) {
            where.push('u.kyc_status = ?');
            params.push(status);
        }
        const users = req.db.db.prepare(`
            SELECT u.id, u.user_uid, u.email, u.full_name, u.phone, u.kyc_status, u.kyc_documents, u.created_at
            FROM users u
            WHERE ${where.join(' AND ')}
            ORDER BY u.created_at DESC
            LIMIT 200
        `).all(...params).map(u => {
            try { u.kyc_documents = u.kyc_documents ? JSON.parse(u.kyc_documents) : null; } catch { u.kyc_documents = null; }
            return u;
        });
        res.json({ success: true, users });
    } catch (error) {
        console.error('KYC requests error:', error);
        res.json({ success: false, message: 'Error fetching KYC requests' });
    }
});

// Securely serve KYC files only to logged-in admins
router.get('/kyc-file/:userId/:file', (req, res) => {
    try {
        const user = req.db.db.prepare('SELECT id, kyc_documents FROM users WHERE id = ?').get(req.params.userId);
        if (!user || !user.kyc_documents) return res.status(404).send('Not found');
        let docs = null;
        try { docs = JSON.parse(user.kyc_documents); } catch { docs = null; }
        const requested = require('path').basename(req.params.file);
        if (!docs || ![docs.id_front_file, docs.id_back_file].includes(requested)) return res.status(403).send('Forbidden');
        const filePath = require('path').join(__dirname, '..', '..', 'uploads', 'kyc', requested);
        if (!require('fs').existsSync(filePath)) return res.status(404).send('File not found');
        res.sendFile(filePath);
    } catch (error) {
        console.error('KYC file error:', error);
        res.status(500).send('Server error');
    }
});

// Dedicated withdrawal history/all status endpoint
router.get('/withdrawals-all', (req, res) => {
    try {
        const status = String(req.query.status || 'all').toLowerCase();
        const where = [];
        const params = [];
        if (['pending', 'approved', 'rejected'].includes(status)) {
            where.push('w.status = ?');
            params.push(status);
        }
        const sqlWhere = where.length ? `WHERE ${where.join(' AND ')}` : '';
        const withdrawals = req.db.db.prepare(`
            SELECT w.*, u.user_uid, u.email, u.full_name, u.phone, u.kyc_status
            FROM withdrawals w
            JOIN users u ON w.user_id = u.id
            ${sqlWhere}
            ORDER BY w.created_at DESC
            LIMIT 300
        `).all(...params);
        res.json({ success: true, withdrawals });
    } catch (error) {
        console.error('Withdrawals all error:', error);
        res.json({ success: false, message: 'Error fetching withdrawals' });
    }
});

// Dedicated deposit requests/all status endpoint
router.get('/deposits-all', (req, res) => {
    try {
        const status = String(req.query.status || 'pending').toLowerCase();
        const where = ["t.type = 'deposit'"];
        const params = [];
        if (['pending', 'completed', 'rejected'].includes(status)) {
            where.push('t.status = ?');
            params.push(status);
        }
        const deposits = req.db.db.prepare(`
            SELECT t.*, u.user_uid, u.email, u.full_name, u.phone
            FROM transactions t
            JOIN users u ON t.user_id = u.id
            WHERE ${where.join(' AND ')}
            ORDER BY t.created_at DESC
            LIMIT 300
        `).all(...params);
        res.json({ success: true, deposits });
    } catch (error) {
        console.error('Deposits all error:', error);
        res.json({ success: false, message: 'Error fetching deposits' });
    }
});

// Admin notifications: list recent notifications sent by admin
router.get('/notifications', (req, res) => {
    try {
        const notifications = req.db.db.prepare(`
            SELECT n.*, u.email as target_email, u.user_uid as target_uid
            FROM notifications n
            LEFT JOIN users u ON n.target_user_id = u.id
            ORDER BY n.created_at DESC
            LIMIT 200
        `).all();
        res.json({ success: true, notifications });
    } catch (error) {
        console.error('Admin notifications list error:', error);
        res.json({ success: false, message: 'Error fetching notifications' });
    }
});

// Admin notifications: send broadcast or single-user notification
router.post('/notifications', (req, res) => {
    try {
        const title = String(req.body.title || '').trim();
        const message = String(req.body.message || '').trim();
        const titleFa = String(req.body.title_fa || '').trim();
        const messageFa = String(req.body.message_fa || '').trim();
        const type = String(req.body.type || 'info').trim().toLowerCase();
        const target = String(req.body.target || 'all').trim();

        if (!title || !message) return res.json({ success: false, message: 'Title and message are required' });
        if (!['info', 'success', 'warning', 'danger'].includes(type)) return res.json({ success: false, message: 'Invalid notification type' });

        let targetUserId = null;
        if (target && target.toLowerCase() !== 'all' && target !== '*') {
            const user = req.db.db.prepare(`
                SELECT id FROM users
                WHERE role = 'user' AND (email = ? OR user_uid = ? OR CAST(id AS TEXT) = ?)
            `).get(target.toLowerCase(), target, target);
            if (!user) return res.json({ success: false, message: 'Target user not found. Use email, User ID or internal ID.' });
            targetUserId = user.id;
        }

        const result = req.db.db.prepare(`
            INSERT INTO notifications (target_user_id, title, title_fa, message, message_fa, type, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `).run(targetUserId, title, titleFa || null, message, messageFa || null, type, req.user.id);

        res.json({ success: true, message: targetUserId ? 'Notification sent to user' : 'Broadcast notification sent', id: result.lastInsertRowid });
    } catch (error) {
        console.error('Admin notification send error:', error);
        res.json({ success: false, message: 'Notification send failed' });
    }
});


// Admin notifications: delete a notification and its read receipts
router.delete('/notifications/:id', (req, res) => {
    try {
        const id = parseInt(req.params.id, 10);
        if (!Number.isInteger(id) || id <= 0) {
            return res.json({ success: false, message: 'Invalid notification ID' });
        }

        const notification = req.db.db.prepare(`
            SELECT id, title FROM notifications WHERE id = ?
        `).get(id);
        if (!notification) {
            return res.json({ success: false, message: 'Notification not found' });
        }

        const remove = req.db.db.transaction(() => {
            req.db.db.prepare('DELETE FROM notification_reads WHERE notification_id = ?').run(id);
            return req.db.db.prepare('DELETE FROM notifications WHERE id = ?').run(id);
        });
        const result = remove();

        res.json({
            success: result.changes > 0,
            message: result.changes > 0 ? 'Notification deleted' : 'Notification could not be deleted'
        });
    } catch (error) {
        console.error('Admin notification delete error:', error);
        res.json({ success: false, message: 'Notification delete failed' });
    }
});

// Request badge counts for admin navigation and quick actions
router.get('/request-counts', (req, res) => {
    try {
        const deposits = req.db.db.prepare(`SELECT COUNT(*) as count FROM transactions WHERE type = 'deposit' AND status = 'pending'`).get();
        const withdrawals = req.db.db.prepare(`SELECT COUNT(*) as count FROM withdrawals WHERE status = 'pending'`).get();
        const kyc = req.db.db.prepare(`SELECT COUNT(*) as count FROM users WHERE role = 'user' AND kyc_status = 'pending' AND kyc_documents IS NOT NULL`).get();
        const tickets = req.db.db.prepare(`SELECT COUNT(*) as count FROM tickets WHERE status != 'closed' AND admin_unread > 0`).get();
        const openTickets = req.db.db.prepare(`SELECT COUNT(*) as count FROM tickets WHERE status != 'closed'`).get();
        const wheel = req.db.db.prepare(`SELECT COALESCE(SUM(wheel_spins),0) as count FROM users WHERE role = 'user'`).get();
        res.json({
            success: true,
            counts: {
                deposits: deposits.count || 0,
                withdrawals: withdrawals.count || 0,
                kyc: kyc.count || 0,
                tickets: tickets.count || 0,
                open_tickets: openTickets.count || 0,
                wheel_spins: wheel.count || 0,
                total: (deposits.count || 0) + (withdrawals.count || 0) + (kyc.count || 0) + (tickets.count || 0)
            }
        });
    } catch (error) {
        console.error('Admin request counts error:', error);
        res.json({ success: false, counts: { deposits: 0, withdrawals: 0, kyc: 0, tickets: 0, open_tickets: 0, total: 0 } });
    }
});

module.exports = router;
