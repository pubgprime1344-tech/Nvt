const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const router = express.Router();

const uploadRoot = path.join(__dirname, '..', '..', 'uploads', 'kyc');
fs.mkdirSync(uploadRoot, { recursive: true });

function safeExt(filename = '') {
    const ext = path.extname(filename).toLowerCase();
    return ['.jpg', '.jpeg', '.png', '.webp', '.pdf', '.heic', '.heif'].includes(ext) ? ext : '.jpg';
}

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, uploadRoot),
    filename: (req, file, cb) => {
        const field = file.fieldname === 'id_back' ? 'back' : 'front';
        cb(null, `${req.user.id}-${field}-${Date.now()}-${Math.random().toString(16).slice(2)}${safeExt(file.originalname)}`);
    }
});

const upload = multer({
    storage,
    limits: { fileSize: 25 * 1024 * 1024, files: 2 },
    fileFilter: (req, file, cb) => {
        const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif', 'application/pdf', 'application/octet-stream'];
        if (file.mimetype && !allowed.includes(file.mimetype) && !String(file.mimetype).startsWith('image/')) {
            return cb(new Error('Only image or PDF files are allowed'));
        }
        cb(null, true);
    }
});

function parseDocs(raw) {
    try { return raw ? JSON.parse(raw) : null; } catch { return null; }
}

// Get KYC status
router.get('/status', (req, res) => {
    try {
        const user = req.db.db.prepare('SELECT full_name, phone, kyc_status, kyc_documents FROM users WHERE id = ?').get(req.user.id);
        const docs = parseDocs(user.kyc_documents);
        res.json({
            success: true,
            status: user.kyc_status,
            full_name: user.full_name,
            phone: user.phone,
            documents: docs ? {
                submitted_at: docs.submitted_at,
                id_number: docs.id_number ? String(docs.id_number).replace(/.(?=.{4})/g, '*') : null,
                id_front_name: docs.id_front_name || null,
                id_back_name: docs.id_back_name || null
            } : null
        });
    } catch (error) {
        console.error('KYC status error:', error);
        res.json({ success: false, message: 'Error fetching KYC status' });
    }
});

const kycUpload = upload.fields([
    { name: 'id_front', maxCount: 1 },
    { name: 'id_back', maxCount: 1 }
]);

// Submit KYC documents with real file upload
router.post('/submit', (req, res) => {
    kycUpload(req, res, (uploadError) => {
        if (uploadError) {
            console.error('KYC upload error:', uploadError.message);
            return res.json({ success: false, message: uploadError.message || 'Document upload failed' });
        }
        try {
        const { full_name, phone, id_number } = req.body;
        if (!full_name || !phone || !id_number) {
            return res.json({ success: false, message: 'Full name, phone and ID number are required' });
        }
        if (!req.files || !req.files.id_front || !req.files.id_back) {
            return res.json({ success: false, message: 'Please upload both front and back ID documents' });
        }

        const front = req.files.id_front[0];
        const back = req.files.id_back[0];
        const documents = {
            id_number: String(id_number).trim(),
            id_front_file: front.filename,
            id_back_file: back.filename,
            id_front_name: front.originalname,
            id_back_name: back.originalname,
            id_front_type: front.mimetype,
            id_back_type: back.mimetype,
            submitted_at: new Date().toISOString()
        };

        req.db.db.prepare(`
            UPDATE users SET
                full_name = ?,
                phone = ?,
                kyc_status = 'pending',
                kyc_documents = ?
            WHERE id = ?
        `).run(String(full_name).trim(), String(phone).trim(), JSON.stringify(documents), req.user.id);

        res.json({ success: true, message: 'KYC documents submitted. Admin review is now pending.' });
        } catch (error) {
            console.error('KYC submit error:', error);
            res.json({ success: false, message: error.message || 'KYC submission failed' });
        }
    });
});

module.exports = router;
