const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { JWT_SECRET } = require('../middleware/auth');
const { isEmailEnabled, sendEmail, renderCodeEmail } = require('../utils/email');

const router = express.Router();
const CODE_EXPIRE_MINUTES = parseInt(process.env.REGISTER_EMAIL_CODE_EXPIRE_MINUTES || '10', 10);
const CODE_RESEND_SECONDS = parseInt(process.env.EMAIL_CODE_RESEND_SECONDS || '60', 10);

function generateCode() {
    return String(Math.floor(100000 + Math.random() * 900000));
}

function hashCode(email, purpose, code) {
    return crypto.createHash('sha256')
        .update(`${JWT_SECRET}:${String(email).toLowerCase()}:${purpose}:${code}`)
        .digest('hex');
}

function emailVerificationRequired() {
    const setting = String(process.env.REQUIRE_REGISTER_EMAIL_CODE || 'auto').toLowerCase();
    if (setting === 'true') return true;
    if (setting === 'false') return false;
    return isEmailEnabled();
}

function cleanEmailValue(email) {
    return String(email || '').trim().toLowerCase();
}

function cleanReferralValue(code) {
    return String(code || '').trim().toUpperCase();
}

function validateRegistrationInput({ email, password, referral_code }) {
    const cleanEmail = cleanEmailValue(email);
    const cleanReferralCode = cleanReferralValue(referral_code);
    if (!cleanEmail || !password || !cleanReferralCode) {
        return { ok: false, message: 'Email, password and referral code are required' };
    }
    if (!/^\S+@\S+\.\S+$/.test(cleanEmail)) {
        return { ok: false, message: 'Please enter a valid email address' };
    }
    if (String(password).length < 6) {
        return { ok: false, message: 'Password must be at least 6 characters' };
    }
    return { ok: true, cleanEmail, cleanReferralCode };
}

function verifyEmailCode(db, email, purpose, code) {
    const cleanEmail = cleanEmailValue(email);
    const cleanCode = String(code || '').trim();
    if (!cleanCode || !/^\d{6}$/.test(cleanCode)) return { ok: false, message: 'Enter the 6-digit email code' };

    const row = db.prepare(`
        SELECT * FROM verification_codes
        WHERE email = ? AND purpose = ? AND used_at IS NULL AND datetime(expires_at) > datetime('now')
        ORDER BY created_at DESC LIMIT 1
    `).get(cleanEmail, purpose);

    if (!row) return { ok: false, message: 'Email code is expired or not found' };
    if (Number(row.attempts || 0) >= 5) return { ok: false, message: 'Too many wrong attempts. Request a new code.' };

    const expected = hashCode(cleanEmail, purpose, cleanCode);
    if (expected !== row.code_hash) {
        db.prepare('UPDATE verification_codes SET attempts = attempts + 1 WHERE id = ?').run(row.id);
        return { ok: false, message: 'Email code is incorrect' };
    }
    return { ok: true, row };
}

// Send registration verification code
router.post('/register/send-code', async (req, res) => {
    try {
        if (!isEmailEnabled()) {
            return res.json({ success: false, message: 'Email sending is not configured yet' });
        }

        const { email, password, referral_code } = req.body;
        const validation = validateRegistrationInput({ email, password, referral_code });
        if (!validation.ok) return res.json({ success: false, message: validation.message });
        const { cleanEmail, cleanReferralCode } = validation;

        const existingUser = req.db.db.prepare('SELECT id FROM users WHERE email = ?').get(cleanEmail);
        if (existingUser) return res.json({ success: false, message: 'Email already registered' });

        const referrer = req.db.db.prepare('SELECT id FROM users WHERE referral_code = ?').get(cleanReferralCode);
        if (!referrer) return res.json({ success: false, message: 'Referral code is invalid' });

        const recent = req.db.db.prepare(`
            SELECT last_sent_at FROM verification_codes
            WHERE email = ? AND purpose = 'register' AND used_at IS NULL
            ORDER BY created_at DESC LIMIT 1
        `).get(cleanEmail);
        if (recent) {
            const last = new Date(recent.last_sent_at).getTime();
            const wait = Math.ceil((CODE_RESEND_SECONDS * 1000 - (Date.now() - last)) / 1000);
            if (wait > 0) return res.json({ success: false, message: `Please wait ${wait}s before requesting another code` });
        }

        const code = generateCode();
        const expiresAt = new Date(Date.now() + CODE_EXPIRE_MINUTES * 60 * 1000).toISOString();
        req.db.db.prepare(`
            INSERT INTO verification_codes (email, purpose, code_hash, metadata, expires_at)
            VALUES (?, 'register', ?, ?, ?)
        `).run(cleanEmail, hashCode(cleanEmail, 'register', code), JSON.stringify({ referral_code: cleanReferralCode }), expiresAt);

        const mail = renderCodeEmail({
            title: 'Confirm your NVT registration',
            code,
            purposeText: 'create your NVT NexaVest account'
        });
        const sent = await sendEmail({ to: cleanEmail, ...mail });
        if (!sent.ok) return res.json({ success: false, message: sent.error || 'Could not send email code' });

        res.json({ success: true, message: 'Verification code sent to your email', expires_minutes: CODE_EXPIRE_MINUTES });
    } catch (error) {
        console.error('Register code send error:', error);
        res.json({ success: false, message: 'Could not send verification code' });
    }
});

// Register
router.post('/register', (req, res) => {
    try {
        const { email, password, referral_code, full_name, email_code } = req.body;
        const validation = validateRegistrationInput({ email, password, referral_code });
        if (!validation.ok) return res.json({ success: false, message: validation.message });
        const { cleanEmail, cleanReferralCode } = validation;

        // Check if email exists
        const existingUser = req.db.db.prepare('SELECT * FROM users WHERE email = ?').get(cleanEmail);
        if (existingUser) {
            return res.json({ success: false, message: 'Email already registered' });
        }

        if (emailVerificationRequired()) {
            const codeCheck = verifyEmailCode(req.db.db, cleanEmail, 'register', email_code);
            if (!codeCheck.ok) return res.json({ success: false, message: codeCheck.message });
        }

        // Find referrer
        let referredBy = null;
        const referrer = req.db.db.prepare('SELECT id FROM users WHERE referral_code = ?').get(cleanReferralCode);
        if (!referrer) {
            return res.json({ success: false, message: 'Referral code is invalid' });
        }
        referredBy = referrer.id;

        // Generate user referral code
        let userReferralCode;
        do {
            userReferralCode = req.db.generateReferralCode();
        } while (req.db.db.prepare('SELECT * FROM users WHERE referral_code = ?').get(userReferralCode));

        // Generate public user ID
        let publicUserId;
        do {
            publicUserId = req.db.generatePublicUserId();
        } while (req.db.db.prepare('SELECT id FROM users WHERE user_uid = ?').get(publicUserId));

        // Generate wallets
        const trc20Address = req.db.generateWalletAddress('trc20');
        const bep20Address = req.db.generateWalletAddress('bep20');

        // Hash password
        const hashedPassword = bcrypt.hashSync(password, 10);

        // Insert user + welcome bonus in one database transaction.
        const registerUser = req.db.db.transaction(() => {
            const stmt = req.db.db.prepare(`
                INSERT INTO users (user_uid, email, password, full_name, phone, referral_code, referred_by, trc20_address, bep20_address)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `);

            const result = stmt.run(
                publicUserId,
                cleanEmail,
                hashedPassword,
                full_name || cleanEmail.split('@')[0],
                null,
                userReferralCode,
                referredBy,
                trc20Address,
                bep20Address
            );

            req.db.db.prepare(`
                INSERT INTO transactions (user_id, type, amount, net_amount, status, description)
                VALUES (?, 'bonus', 10, 10, 'completed', 'Welcome bonus')
            `).run(result.lastInsertRowid);

            req.db.db.prepare('UPDATE users SET wallet_balance = wallet_balance + 10 WHERE id = ?').run(result.lastInsertRowid);
            req.db.db.prepare(`
                UPDATE verification_codes SET used_at = CURRENT_TIMESTAMP
                WHERE email = ? AND purpose = 'register' AND used_at IS NULL
            `).run(cleanEmail);
            return result;
        });

        const result = registerUser();

        // Generate token
        const token = jwt.sign(
            { id: result.lastInsertRowid, email: cleanEmail, role: 'user' },
            JWT_SECRET,
            { expiresIn: '7d' }
        );

        res.json({
            success: true,
            message: 'Registration successful! Welcome bonus of 10 USDT credited.',
            token,
            user: {
                id: result.lastInsertRowid,
                user_uid: publicUserId,
                email: cleanEmail,
                referral_code: userReferralCode,
                referral_link: `/register?ref=${userReferralCode}`,
                wallet_balance: 10
            }
        });

    } catch (error) {
        console.error('Registration error:', error);
        res.json({ success: false, message: 'Registration failed. Please try again or use another email.' });
    }
});

// Login
router.post('/login', (req, res) => {
    try {
        const { email, password } = req.body;
        const cleanEmail = String(email || '').trim().toLowerCase();

        if (!cleanEmail || !password) {
            return res.json({ success: false, message: 'Email and password required' });
        }

        const user = req.db.db.prepare('SELECT * FROM users WHERE email = ?').get(cleanEmail);
        
        if (!user) {
            return res.json({ success: false, message: 'Invalid credentials' });
        }

        if (!bcrypt.compareSync(password, user.password)) {
            return res.json({ success: false, message: 'Invalid credentials' });
        }

        const token = jwt.sign(
            { id: user.id, email: user.email, role: user.role },
            JWT_SECRET,
            { expiresIn: '7d' }
        );

        res.json({
            success: true,
            message: 'Login successful',
            token,
            user: {
                id: user.id,
                user_uid: user.user_uid,
                email: user.email,
                full_name: user.full_name,
                role: user.role,
                referral_code: user.referral_code,
                wallet_balance: user.wallet_balance,
                kyc_status: user.kyc_status
            }
        });

    } catch (error) {
        console.error('Login error:', error);
        res.json({ success: false, message: 'Login failed' });
    }
});

module.exports = router;
