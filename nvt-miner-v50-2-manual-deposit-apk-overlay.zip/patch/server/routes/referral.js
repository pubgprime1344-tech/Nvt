const express = require('express');
const router = express.Router();

// Get referral info
router.get('/info', (req, res) => {
    try {
        const user = req.db.db.prepare('SELECT referral_code FROM users WHERE id = ?').get(req.user.id);
        if (!user) return res.json({ success: false, message: 'User not found' });

        const stats = typeof req.db.getReferralSummary === 'function'
            ? req.db.getReferralSummary(req.user.id)
            : req.db.db.prepare(`
                SELECT COUNT(*) as total_referrals, COALESCE(SUM(reward_amount), 0) as total_earnings
                FROM referral_rewards WHERE referrer_id = ?
            `).get(req.user.id);

        // Every direct referral is shown, even if they have not deposited yet.
        const referrals = req.db.db.prepare(`
            SELECT
                u.id,
                u.full_name,
                u.email,
                u.created_at,
                COALESCE(u.total_deposit, 0) as total_deposit,
                COALESCE(SUM(r.reward_amount), 0) as reward_amount,
                COUNT(r.id) as reward_count
            FROM users u
            LEFT JOIN referral_rewards r
                ON r.referred_id = u.id AND r.referrer_id = ?
            WHERE u.referred_by = ? AND u.role = 'user'
            GROUP BY u.id
            ORDER BY u.created_at DESC
            LIMIT 50
        `).all(req.user.id, req.user.id);

        const rewards = req.db.db.prepare(`
            SELECT r.id, r.reward_amount, r.from_deposit, r.source_type, r.created_at,
                   u.full_name, u.email
            FROM referral_rewards r
            JOIN users u ON r.referred_id = u.id
            WHERE r.referrer_id = ?
            ORDER BY r.created_at DESC
            LIMIT 50
        `).all(req.user.id);

        res.json({
            success: true,
            referral_code: user.referral_code,
            stats: {
                total_referrals: stats.total_referrals || 0,
                active_referrals: stats.active_referrals || 0,
                total_earnings: stats.total_earnings || 0,
                referral_bonus_percentage: stats.referral_bonus_percentage || 10,
                referral_tier: stats.referral_tier || { code: 'bronze', name: 'Bronze', name_fa: 'برنز', rate: 0.10, rank_bonus: 0, range: '1-9' },
                next_referral_tier: stats.next_referral_tier || null,
                referral_tiers: stats.referral_tiers || [
                    { code: 'bronze', name: 'Bronze', name_fa: 'برنز', range: '1-9', rate: 0.10, rank_bonus: 0 },
                    { code: 'silver', name: 'Silver', name_fa: 'نقره', range: '10-49', rate: 0.12, rank_bonus: 50 },
                    { code: 'gold', name: 'Gold', name_fa: 'طلا', range: '50-99', rate: 0.15, rank_bonus: 200 },
                    { code: 'platinum', name: 'Platinum', name_fa: 'پلاتین', range: '100+', rate: 0.20, rank_bonus: 500 }
                ]
            },
            recent_referrals: referrals,
            rewards
        });
    } catch (error) {
        console.error('Referral info error:', error);
        res.json({ success: false, message: 'Error fetching referral info' });
    }
});

// Get referral link
router.get('/link', (req, res) => {
    try {
        const user = req.db.db.prepare('SELECT referral_code FROM users WHERE id = ?').get(req.user.id);
        if (!user) return res.json({ success: false, message: 'User not found' });
        const baseUrl = req.headers.origin || `${req.protocol}://${req.get('host')}` || `http://localhost:${process.env.PORT || 3000}`;

        res.json({
            success: true,
            referral_code: user.referral_code,
            referral_link: `${baseUrl}/register?ref=${encodeURIComponent(user.referral_code)}`
        });
    } catch (error) {
        console.error('Referral link error:', error);
        res.json({ success: false, message: 'Error generating link' });
    }
});

module.exports = router;
