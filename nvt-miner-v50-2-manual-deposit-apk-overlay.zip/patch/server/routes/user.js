const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../middleware/auth');
const router = express.Router();

function getVipLevel(totalDeposit = 0) {
    const v = Number(totalDeposit || 0);
    if (v >= 50000) return { level: 'VIP 6', min: 3, max: 4, range: '50,000+ USDT', daily_trades: 20, next_min: null };
    if (v >= 15000) return { level: 'VIP 5', min: 2.5, max: 3.2, range: '15,000 - 50,000 USDT', daily_trades: 15, next_min: 50000 };
    if (v >= 5000) return { level: 'VIP 4', min: 2, max: 2.7, range: '5,000 - 15,000 USDT', daily_trades: 10, next_min: 15000 };
    if (v >= 2000) return { level: 'VIP 3', min: 1.5, max: 2.1, range: '2,000 - 5,000 USDT', daily_trades: 7, next_min: 5000 };
    if (v >= 400) return { level: 'VIP 2', min: 1, max: 1.5, range: '400 - 2,000 USDT', daily_trades: 5, next_min: 2000 };
    if (v >= 50) return { level: 'VIP 1', min: 0.5, max: 1, range: '50 - 400 USDT', daily_trades: 3, next_min: 400 };
    return { level: 'Starter', min: 0, max: 0, range: 'Deposit at least 50 USDT to unlock N-VT Miner', daily_trades: 0, next_min: 50 };
}


function getIranDateKey(date = new Date()) {
    const parts = new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Asia/Tehran',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    }).formatToParts(date).reduce((acc, p) => {
        if (p.type !== 'literal') acc[p.type] = p.value;
        return acc;
    }, {});
    return `${parts.year}-${parts.month}-${parts.day}`;
}

const IRAN_SQL_DATE = "DATE(created_at, '+3 hours', '+30 minutes')";

// Get user profile
router.get('/profile', (req, res) => {
    try {
        const user = req.db.db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
        
        if (!user) {
            return res.json({ success: false, message: 'User not found' });
        }

        res.json({
            success: true,
            user: {
                id: user.id,
                user_uid: user.user_uid,
                email: user.email,
                full_name: user.full_name,
                phone: user.phone,
                referral_code: user.referral_code,
                wallet_balance: user.wallet_balance,
                withdrawable_balance: user.withdrawable_balance || 0,
                total_deposit: user.total_deposit,
                total_withdraw: user.total_withdraw,
                total_profit: user.total_profit,
                kyc_status: user.kyc_status,
                role: user.role,
                created_at: user.created_at,
                trades_today: user.trades_today,
                last_trade_date: user.last_trade_date,
                trc20_address: user.trc20_address,
                bep20_address: user.bep20_address
            }
        });
    } catch (error) {
        res.json({ success: false, message: 'Error fetching profile' });
    }
});

// Update own profile/security. Current password is required for changing email, name or password.
function updateOwnAccount(req, res) {
    try {
        const currentPassword = String(req.body.current_password || '').trim();
        const newPassword = String(req.body.new_password || '').trim();
        const confirmPassword = String(req.body.confirm_password || '').trim();
        const email = String(req.body.email || '').trim().toLowerCase();
        const fullName = String(req.body.full_name || '').trim();
        const phone = String(req.body.phone || '').trim();

        if (!currentPassword) {
            return res.json({ success: false, message: 'Current password is required' });
        }
        if (!email || !email.includes('@')) {
            return res.json({ success: false, message: 'Valid email is required' });
        }
        if (!fullName || fullName.length < 2) {
            return res.json({ success: false, message: 'Full name is required' });
        }
        if (newPassword && newPassword.length < 6) {
            return res.json({ success: false, message: 'New password must be at least 6 characters' });
        }
        if (newPassword && newPassword !== confirmPassword) {
            return res.json({ success: false, message: 'New password confirmation does not match' });
        }

        const user = req.db.db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
        if (!user) return res.json({ success: false, message: 'User not found' });
        if (!bcrypt.compareSync(currentPassword, user.password)) {
            return res.json({ success: false, message: 'Current password is incorrect' });
        }

        const duplicate = req.db.db.prepare('SELECT id FROM users WHERE email = ? AND id != ?').get(email, req.user.id);
        if (duplicate) return res.json({ success: false, message: 'This email is already used by another account' });

        if (newPassword) {
            const hashed = bcrypt.hashSync(newPassword, 10);
            req.db.db.prepare(`
                UPDATE users SET email = ?, full_name = ?, phone = ?, password = ?
                WHERE id = ?
            `).run(email, fullName, phone || null, hashed, req.user.id);
        } else {
            req.db.db.prepare(`
                UPDATE users SET email = ?, full_name = ?, phone = ?
                WHERE id = ?
            `).run(email, fullName, phone || null, req.user.id);
        }

        req.db.db.prepare(`
            INSERT INTO transactions (user_id, type, amount, net_amount, status, description)
            VALUES (?, 'profile_update', 0, 0, 'completed', ?)
        `).run(req.user.id, newPassword ? 'User updated profile and password' : 'User updated profile');

        const updated = req.db.db.prepare(`
            SELECT id, user_uid, email, full_name, phone, role, referral_code, wallet_balance, COALESCE(withdrawable_balance,0) as withdrawable_balance, kyc_status
            FROM users WHERE id = ?
        `).get(req.user.id);

        const token = jwt.sign(
            { id: updated.id, email: updated.email, role: updated.role },
            JWT_SECRET,
            { expiresIn: '7d' }
        );

        res.json({ success: true, message: 'Account updated successfully', user: updated, token });
    } catch (error) {
        console.error('Account update error:', error);
        res.json({ success: false, message: 'Update failed' });
    }
}

router.post('/account', updateOwnAccount);
router.post('/update', updateOwnAccount);

// Get dashboard stats
router.get('/dashboard', (req, res) => {
    try {
        const user = req.db.db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
        
        // Get referral stats
        const referralStats = typeof req.db.getReferralSummary === 'function'
            ? req.db.getReferralSummary(req.user.id)
            : req.db.db.prepare(`
                SELECT COUNT(*) as total_referrals,
                       COALESCE(SUM(reward_amount), 0) as total_referral_earnings
                FROM referral_rewards WHERE referrer_id = ?
            `).get(req.user.id);

        // Get recent transactions
        const recentTransactions = req.db.db.prepare(`
            SELECT * FROM transactions WHERE user_id = ?
            ORDER BY created_at DESC LIMIT 10
        `).all(req.user.id);

        // Get today's trades
        const today = getIranDateKey();
        const todayTrades = req.db.db.prepare(`
            SELECT * FROM trades WHERE user_id = ? AND DATE(created_at, '+3 hours', '+30 minutes') = ?
        `).all(req.user.id, today);

        // Get total trade profit
        const tradeStats = req.db.db.prepare(`
            SELECT SUM(profit_amount) as total_profit, COUNT(*) as total_trades
            FROM trades WHERE user_id = ? AND status IN ('completed','mining')
        `).get(req.user.id);

        const vip = getVipLevel(user.total_deposit || 0);
        const dailyLimit = vip.daily_trades || 0;

        res.json({
            success: true,
            stats: {
                balance: user.wallet_balance,
                total_deposit: user.total_deposit,
                total_profit: tradeStats.total_profit || 0,
                total_trades: tradeStats.total_trades || 0,
                referrals: referralStats.total_referrals || 0,
                referral_earnings: referralStats.total_earnings || referralStats.total_referral_earnings || 0,
                trades_today: todayTrades.length,
                trades_remaining: null,
                daily_trade_limit: null,
                active_mining: todayTrades.filter(t => t.status === 'mining').length,
                vip
            },
            recent_transactions: recentTransactions,
            today_trades: todayTrades
        });
    } catch (error) {
        console.error('Dashboard error:', error);
        res.json({ success: false, message: 'Error loading dashboard' });
    }
});

module.exports = router;
