const nodemailer = require('nodemailer');

function envBool(value) {
  return String(value || '').toLowerCase() === 'true';
}

function isEmailEnabled() {
  return Boolean(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);
}

function getTransporter() {
  if (!isEmailEnabled()) return null;
  const port = parseInt(process.env.SMTP_PORT || '587', 10);
  const secure = envBool(process.env.SMTP_SECURE) || port === 465;
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
}

async function sendEmail({ to, subject, text, html }) {
  const transporter = getTransporter();
  if (!transporter) {
    return { ok: false, error: 'SMTP is not configured' };
  }
  const from = process.env.SMTP_FROM || `NVT NexaVest <${process.env.SMTP_USER}>`;
  try {
    const info = await transporter.sendMail({ from, to, subject, text, html });
    return { ok: true, messageId: info.messageId };
  } catch (error) {
    console.error('Email send error:', error);
    return { ok: false, error: error.message || 'Email send failed' };
  }
}

function renderCodeEmail({ title, code, purposeText }) {
  const safeTitle = title || 'NVT NexaVest Verification';
  const safePurpose = purposeText || 'confirm your action';
  return {
    subject: safeTitle,
    text: `Your NVT NexaVest verification code is ${code}. Use it to ${safePurpose}. This code expires in 10 minutes.`,
    html: `
      <div style="font-family:Arial,sans-serif;background:#07111f;padding:28px;color:#f8fafc">
        <div style="max-width:560px;margin:auto;background:#111c31;border:1px solid #263449;border-radius:18px;padding:26px">
          <div style="display:inline-flex;align-items:center;gap:10px;margin-bottom:18px">
            <div style="background:linear-gradient(135deg,#14b8a6,#6366f1);color:white;border-radius:12px;padding:10px 12px;font-weight:800">NVT</div>
            <strong style="font-size:18px">NexaVest</strong>
          </div>
          <h2 style="margin:0 0 10px">${safeTitle}</h2>
          <p style="color:#94a3b8;margin:0 0 18px">Use this code to ${safePurpose}. The code expires in 10 minutes.</p>
          <div style="font-size:34px;letter-spacing:8px;font-weight:900;text-align:center;background:#07111f;border:1px solid #334155;border-radius:16px;padding:18px;color:#5eead4">${code}</div>
          <p style="color:#64748b;font-size:12px;margin-top:18px">If you did not request this code, you can safely ignore this email.</p>
        </div>
      </div>
    `
  };
}

module.exports = { isEmailEnabled, sendEmail, renderCodeEmail };
