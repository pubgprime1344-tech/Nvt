const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'crypto-invest-secret-key-2024';

function authMiddleware(req, res, next) {
    const authHeader = req.headers.authorization;
    const queryToken = req.query && req.query.token;

    let token = null;
    if (authHeader && authHeader.startsWith('Bearer ')) {
        token = authHeader.split(' ')[1];
    } else if (queryToken) {
        token = String(queryToken);
    }

    if (!token) {
        return res.status(401).json({ success: false, message: 'Authentication required' });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        return res.status(401).json({ success: false, message: 'Invalid or expired token' });
    }
}

function adminMiddleware(req, res, next) {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ success: false, message: 'Admin access required' });
    }
    next();
}

module.exports = { authMiddleware, adminMiddleware, JWT_SECRET };
