/**
 * Simple Database - Direct to Admin Wallet
 * واریزی مستقیم به ولت ادمین - بدون ولت جداگانه
 */

const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');

// فقط BSC چون ethers.js ساده‌تره
const { ethers } = require('ethers');

class SimpleDB {
    constructor() {
        this.db = new Database('./cryptoinvest-simple.db');
        
        // آدرس‌های ادمین (از .env یا دستی)
        this.adminWallets = {
            tron: process.env.TRON_ADDRESS || 'TFVSKHiakSiSMR7VyGjDzWxfPSPnSSwNPg',
            bsc: process.env.BSC_ADDRESS || '0xxxxx'
        };
        
        // کارمزد شبکه (USDT)
        this.networkFee = 1; // 1 USDT
        
        // RPC برای BSC
        this.bscRpc = 'https://bsc-dataseed.binance.org/';
        this.usdtContractBsc = '0x55d398326f99059fF775485246999027B3197955';
    }

    async init() {
        // Users table - بدون ولت!
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                full_name TEXT,
                phone TEXT,
                referral_code TEXT UNIQUE NOT NULL,
                referred_by INTEGER,
                
                -- فقط موجودی سیستم
                wallet_balance REAL DEFAULT 0,
                total_deposit REAL DEFAULT 0,
                total_withdraw REAL DEFAULT 0,
                
                -- KYC
                kyc_status TEXT DEFAULT 'pending',
                
                -- نقش
                role TEXT DEFAULT 'user',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_trade_date DATE,
                trades_today INTEGER DEFAULT 0,
                
                -- آخرین موجودی چک شده (برای ردیابی واریزی‌ها)
                last_tron_balance REAL DEFAULT 0,
                last_bsc_balance REAL DEFAULT 0
            )
        `);

        // Transactions
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                type TEXT NOT NULL,
                amount REAL NOT NULL,
                net_amount REAL NOT NULL,
                status TEXT DEFAULT 'pending',
                tx_hash TEXT,
                description TEXT,
                network TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Known deposits - برای جلوگیری از تکرار
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS known_deposits (
                tx_hash TEXT PRIMARY KEY,
                user_id INTEGER,
                amount REAL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Admin config
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS admin_config (
                id INTEGER PRIMARY KEY,
                tron_address TEXT,
                bsc_address TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Create admin
        this.createAdmin();

        console.log('✅ Simple database initialized');
    }

    createAdmin() {
        const admin = this.db.prepare('SELECT * FROM users WHERE role = ?').get('admin');
        if (!admin) {
            const hashedPassword = bcrypt.hashSync('admin123', 10);
            
            this.db.prepare(`
                INSERT INTO users (email, password, full_name, referral_code, role, kyc_status)
                VALUES (?, ?, ?, ?, ?, ?)
            `).run('admin@nexavest.local', hashedPassword, 'Admin', 'ADMIN2024', 'admin', 'approved');
            
            // ذخیره آدرس‌های ادمین
            this.db.prepare(`
                INSERT INTO admin_config (id, tron_address, bsc_address)
                VALUES (1, ?, ?)
            `).run(this.adminWallets.tron, this.adminWallets.bsc);
            
            console.log('✅ Admin created');
        }
    }

    getAdminAddresses() {
        const config = this.db.prepare('SELECT * FROM admin_config WHERE id = 1').get();
        return {
            tron: config?.tron_address || this.adminWallets.tron,
            bsc: config?.bsc_address || this.adminWallets.bsc
        };
    }

    // چک موجودی BSC از بلاکچین
    async getBscBalance(address) {
        try {
            const provider = new ethers.JsonRpcProvider(this.bscRpc);
            
            const abi = [
                "function balanceOf(address) view returns (uint256)",
                "function decimals() view returns (uint8)"
            ];
            
            const contract = new ethers.Contract(this.usdtContractBsc, abi, provider);
            const balance = await contract.balanceOf(address);
            const decimals = await contract.decimals();
            
            return parseFloat(ethers.formatUnits(balance, decimals));
        } catch (error) {
            console.error('BSC balance error:', error.message);
            return 0;
        }
    }

    // پیدا کردن واریزی‌های جدید و پردازش
    async checkDeposits() {
        const addresses = this.getAdminAddresses();
        
        console.log('🔍 Checking deposits...');
        console.log('   BSC Address:', addresses.bsc);

        try {
            // چک موجودی BSC
            const currentBalance = await this.getBscBalance(addresses.bsc);
            console.log('   Current balance:', currentBalance, 'USDT');
            
            if (currentBalance > 0) {
                // پیدا کردن واریزی‌های جدید
                // در عمل باید Event Log رو چک کنیم
                // ولی برای سادگی، فرض میکنیم موجودی جدید = واریزی جدید
                
                console.log('💰 Balance detected!');
                
                // برای هر کاربر، بررسی میکنیم
                // در نسخه واقعی باید Event Transfer رو Parse کنیم
                // ولی اینجا یه مثال ساده میزنیم
            }
        } catch (error) {
            console.error('Check deposits error:', error);
        }
    }

    // ثبت واریزی دستی (ادمین تأیید میکنه)
    async recordDeposit(userId, amount, network, txHash) {
        // کارمزد کسر
        const netAmount = Math.max(0, amount - this.networkFee);
        
        // آپدیت موجودی کاربر
        this.db.prepare(`
            UPDATE users SET 
                wallet_balance = wallet_balance + ?,
                total_deposit = total_deposit + ?
            WHERE id = ?
        `).run(netAmount, netAmount, userId);

        // ثبت تراکنش
        this.db.prepare(`
            INSERT INTO transactions (user_id, type, amount, net_amount, status, tx_hash, description, network)
            VALUES (?, 'deposit', ?, ?, 'completed', ?, ?, ?)
        `).run(userId, amount, netAmount, txHash, `Deposit via ${network.toUpperCase()}`, network);

        // ثبت در known_deposits
        this.db.prepare(`
            INSERT OR IGNORE INTO known_deposits (tx_hash, user_id, amount)
            VALUES (?, ?, ?)
        `).run(txHash, userId, amount);

        console.log(`✅ Deposit recorded: User ${userId}, Gross ${amount}, Net ${netAmount} USDT`);

        return { gross: amount, net: netAmount, fee: this.networkFee };
    }

    generateReferralCode() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let code = 'CIP';
        for (let i = 0; i < 6; i++) {
            code += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return code;
    }
}

module.exports = SimpleDB;

        // Support tickets
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                subject TEXT NOT NULL,
                priority TEXT DEFAULT 'normal',
                status TEXT DEFAULT 'open',
                admin_unread INTEGER DEFAULT 1,
                user_unread INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);
        this.db.exec(`
            CREATE TABLE IF NOT EXISTS ticket_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id INTEGER NOT NULL,
                sender_id INTEGER NOT NULL,
                sender_role TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

