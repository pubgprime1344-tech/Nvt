(function () {
    const STORAGE_KEY = 'nexavest_lang';

    const GOOGLE_LANGUAGES = [
        ['en','English'], ['fa','فارسی'], ['ar','العربية'], ['tr','Türkçe'], ['ku','Kurdî'],
        ['ru','Русский'], ['fr','Français'], ['de','Deutsch'], ['es','Español'], ['it','Italiano'],
        ['pt','Português'], ['nl','Nederlands'], ['sv','Svenska'], ['no','Norsk'], ['da','Dansk'],
        ['fi','Suomi'], ['pl','Polski'], ['uk','Українська'], ['ro','Română'], ['el','Ελληνικά'],
        ['hi','हिन्दी'], ['ur','اردو'], ['bn','বাংলা'], ['pa','ਪੰਜਾਬੀ'], ['id','Bahasa Indonesia'],
        ['ms','Bahasa Melayu'], ['th','ไทย'], ['vi','Tiếng Việt'], ['ko','한국어'], ['ja','日本語'],
        ['zh-CN','中文'], ['az','Azərbaycanca'], ['he','עברית']
    ];
    const RTL_LANGS = new Set(['fa', 'ar', 'ur', 'he']);

    function setGoogleCookie(lang) {
        const value = lang === 'en' || lang === 'fa' ? '' : `/en/${lang}`;
        const expires = value ? 'expires=Fri, 31 Dec 9999 23:59:59 GMT;' : 'expires=Thu, 01 Jan 1970 00:00:00 GMT;';
        document.cookie = `googtrans=${value}; path=/; ${expires}`;
        if (location.hostname.includes('.')) {
            document.cookie = `googtrans=${value}; path=/; domain=.${location.hostname}; ${expires}`;
        }
    }

    function loadGoogleTranslate(lang) {
        if (!lang || lang === 'en' || lang === 'fa') return;
        setGoogleCookie(lang);
        if (!document.getElementById('google_translate_element')) {
            const holder = document.createElement('div');
            holder.id = 'google_translate_element';
            holder.style.position = 'absolute';
            holder.style.left = '-9999px';
            holder.style.top = '-9999px';
            document.body.appendChild(holder);
        }
        window.googleTranslateElementInit = function () {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                autoDisplay: false,
                includedLanguages: GOOGLE_LANGUAGES.filter(x => !['en','fa'].includes(x[0])).map(x => x[0]).join(',')
            }, 'google_translate_element');
        };
        if (!document.querySelector('script[data-google-translate]')) {
            const script = document.createElement('script');
            script.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
            script.async = true;
            script.setAttribute('data-google-translate', '1');
            document.head.appendChild(script);
        }
    }

    const fa = {
        'Mining Level': 'سطح Mining', 'Current Level': 'سطح فعلی', 'Daily Mining Limit': 'محدودیت قراردادهای فعال', 'Mining Range': 'بازه قرارداد', 'Mining Benefits': 'مزایای Mining', 'How to Upgrade': 'چطور ارتقا بدهم', 'Verified Deposits': 'واریزی‌های تاییدشده', 'Cloud Mines/day': 'معاملات AI روزانه',
        'Features': 'امکانات', 'Mining Levels': 'سطوح Mining', 'How It Works': 'روش کار', 'FAQ': 'سؤالات', 'Login': 'ورود', 'Get Started': 'شروع کنید', 'Learn More': 'بیشتر بدانید', 'Download': 'دانلود', 'Download Shortcut': 'دانلود میانبر', 'View Mining Levels': 'مشاهده سطوح Mining', 'Dashboard': 'داشبورد', 'Wallet': 'کیف پول', 'Mine': 'ماین', 'Convert': 'تبدیل', 'Deposit': 'واریز', 'Withdraw': 'برداشت', 'Referral': 'معرفی', 'Logout': 'خروج', 'Create Account': 'ساخت حساب',
        'A cleaner way to manage crypto investing': 'راهی مدرن‌تر برای مدیریت سرمایه‌گذاری کریپتو',
        'N-VT Miner brings deposits, TXID checks, Mining trading access, referral rewards, and withdrawal requests into one modern dashboard built for USDT investors.': 'نکساوست واریزها، بررسی TXID، دسترسی ماین Mining، پاداش معرفی و درخواست برداشت را در یک داشبورد مدرن برای سرمایه‌گذاران USDT کنار هم قرار می‌دهد.',
        '10 USDT Welcome Bonus': 'بونوس خوش‌آمد ۱۰ USDT', 'Cloud Mine panel': 'پنل ماین خودکار هوش مصنوعی', 'Mining profit tiers': 'سطوح سوددهی Mining', '10% referral rewards': 'پاداش معرفی ۱۰٪', 'KYC-protected withdrawals': 'برداشت محافظت‌شده با احراز هویت',
        'Portfolio Balance': 'موجودی پرتفوی', 'Verified Deposits': 'واریزهای تاییدشده', 'Pending Withdrawals': 'برداشت‌های در انتظار', 'USDT minimum deposit': 'حداقل واریز USDT', 'Minimum AI trade': 'حداقل ماین AI', 'Referral reward': 'پاداش معرفی',
        'Built for a smoother investment flow': 'ساخته‌شده برای جریان سرمایه‌گذاری روان‌تر',
        'A fast and organized crypto dashboard for investors who want clear deposit tracking, portfolio visibility, Mining-based trade access, and simple referral growth.': 'یک داشبورد سریع و منظم برای سرمایه‌گذارانی که پیگیری شفاف واریز، مشاهده پرتفوی، دسترسی ماین بر اساس Mining و رشد ساده معرفی می‌خواهند.',
        'Cloud Mine': 'ماین خودکار AI', 'Use one clean Cloud Mine button instead of manual long/short choices. Minimum trade amount starts from 50 USDT.': 'به‌جای انتخاب دستی لانگ و شورت، از یک دکمه ساده ماین خودکار AI استفاده کنید. حداقل مبلغ ماین از ۵۰ USDT شروع می‌شود.',
        'Mining Tier System': 'سیستم سطح‌بندی Mining', 'Users are grouped from Mining 1 to Mining 6 based on verified deposits, with trade ranges shown clearly in the dashboard.': 'کاربران بر اساس واریزهای تاییدشده از Mining 1 تا Mining 6 سطح‌بندی می‌شوند و بازه ماین در داشبورد نمایش داده می‌شود.',
        '10% Referral Rewards': 'پاداش معرفی ۱۰٪', 'Referral income is credited automatically when a verified deposit is added to the referred user\'s account.': 'درآمد معرفی بعد از ثبت واریز تاییدشده کاربر زیرمجموعه، خودکار به حساب معرف اضافه می‌شود.',
        'TXID Verification': 'تایید TXID', 'TRC20 and BEP20 TXIDs are checked before the deposit is credited, with pending review when verification needs attention.': 'TXID شبکه‌های TRC20 و BEP20 قبل از شارژ حساب بررسی می‌شود و در صورت نیاز برای بررسی در انتظار می‌ماند.',
        'KYC Withdrawals': 'برداشت با KYC', 'Withdrawals require approved KYC, helping keep account activity more controlled and organized.': 'برای برداشت، احراز هویت تاییدشده لازم است تا فعالیت حساب کنترل‌شده‌تر و منظم‌تر باشد.',
        'Mobile Shortcut': 'میانبر موبایل', 'Users can add N-VT Miner to their phone home screen as a branded shortcut with logo and standalone layout.': 'کاربران می‌توانند نکساوست را به‌صورت میانبر برنددار با لوگو به صفحه اصلی گوشی اضافه کنند.',
        'Mining levels': 'سطوح Mining', 'Mining level is calculated from approved deposits. Mine percentages shown here are platform settings and should not be presented as guaranteed market returns.': 'سطح Mining بر اساس واریزهای تاییدشده محاسبه می‌شود. درصدهای ماین تنظیمات پلتفرم هستند و نباید به‌عنوان سود قطعی بازار معرفی شوند.',
        'Create account': 'ساخت حساب', 'Register with a referral code and access your personal dashboard.': 'با کد معرف ثبت‌نام کنید و وارد داشبورد شخصی شوید.', 'Deposit USDT': 'واریز USDT', 'Minimum deposit is 50 USDT. Submit TXID for automatic TRC20/BEP20 verification.': 'حداقل واریز ۵۰ USDT است. برای تایید خودکار TRC20/BEP20، TXID را ثبت کنید.', 'Use Cloud Mine': 'استفاده از ماین خودکار AI', 'Choose an amount from 50 USDT and run the Mining-based mine flow.': 'مبلغی از ۵۰ USDT انتخاب کنید و ماین خودکار بر اساس سطح Mining را اجرا کنید.', 'Withdraw with KYC': 'برداشت با احراز هویت', 'After KYC approval, submit withdrawal requests to your external wallet.': 'بعد از تایید KYC، درخواست برداشت به کیف پول خارجی خود ثبت کنید.',
        'Ready to start?': 'آماده شروع هستید؟', 'Create your account, submit a verified deposit, and unlock your Mining level.': 'حساب بسازید، واریز تاییدشده ثبت کنید و سطح Mining خود را فعال کنید.', 'Platform': 'پلتفرم', 'Support': 'پشتیبانی', 'Legal': 'قانونی', 'Help Center': 'مرکز راهنما', 'Contact Us': 'تماس با ما', 'Terms': 'قوانین', 'Privacy': 'حریم خصوصی', 'Risk Disclosure': 'افشای ریسک', 'Smart crypto portfolio dashboard with verified deposits, Mining trade access, referrals, and KYC-protected withdrawals.': 'داشبورد هوشمند کریپتو با واریز تاییدشده، دسترسی ماین Mining، معرفی و برداشت محافظت‌شده با KYC.',
        'Welcome Back': 'خوش برگشتی', 'Login to your N-VT Miner account': 'وارد حساب نکساوست شوید', 'Email Address': 'آدرس ایمیل', 'Password': 'رمز عبور', 'Full Name': 'نام کامل', 'Phone Number': 'شماره تلفن', 'Referral Code': 'کد معرف', 'Already have an account?': 'قبلاً حساب دارید؟', 'Register now': 'ثبت‌نام کنید', 'Don\'t have an account?': 'حساب ندارید؟', 'Register': 'ثبت‌نام', 'By registering, you agree to our Terms of Service and Privacy Policy': 'با ثبت‌نام، قوانین سرویس و حریم خصوصی را می‌پذیرید', 'Join N-VT Miner and start earning': 'به نکساوست بپیوندید و شروع کنید', 'Create a secure N-VT Miner account': 'یک حساب امن نکساوست بسازید', 'Don\'t have a code? Use:': 'کد ندارید؟ استفاده کنید:',
        'Welcome back,': 'خوش برگشتی،', 'Portfolio Overview': 'نمای کلی پرتفوی', 'Available Balance': 'موجودی قابل استفاده', 'Total Deposits': 'کل واریزها', 'Total Profit': 'کل نتیجه ماین', 'Total Mines': 'کل ماینها', 'Quick Actions': 'دسترسی سریع', 'Your Referral Code': 'کد معرفی شما', 'Referral Statistics': 'آمار معرفی', 'Total Referrals': 'کل زیرمجموعه‌ها', 'Total Earnings': 'کل درآمد', 'Referral Earnings': 'درآمد معرفی', 'Recent Transactions': 'تراکنش‌های اخیر', 'Total Deposited': 'کل واریزشده', 'Total Profits': 'کل نتیجه‌ها', 'Mining Cycles': 'ماینهای باقی‌مانده امروز', 'Start Mining': 'شروع ماین', 'Recent Mining': 'ماینهای اخیر', 'View All': 'مشاهده همه', 'No mining yet': 'هنوز ماینی نیست', 'Start trading to see your history here': 'برای دیدن تاریخچه، ماین را شروع کنید', 'No transactions yet': 'هنوز تراکنشی نیست', 'Make a deposit to get started': 'برای شروع واریز انجام دهید', 'Complete Your KYC Verification': 'احراز هویت خود را تکمیل کنید',
        'Deposit USDT': 'واریز USDT', 'Send USDT to the addresses below': 'USDT را به آدرس‌های زیر ارسال کنید', 'Lower fees • Recommended': 'کارمزد کمتر • پیشنهادی', 'Fast • Popular': 'سریع • محبوب', 'Deposit Address:': 'آدرس واریز:', 'Copy Address': 'کپی آدرس', 'Minimum deposit is 50 USDT. Network fee (~1 USDT) will be deducted automatically.': 'حداقل واریز ۵۰ USDT است. کارمزد شبکه حدود ۱ USDT خودکار کسر می‌شود.', 'Minimum deposit is 50 USDT. Network fee (~0.5 USDT) will be deducted automatically.': 'حداقل واریز ۵۰ USDT است. کارمزد شبکه حدود ۰.۵ USDT خودکار کسر می‌شود.', 'How to Deposit': 'روش واریز', 'Copy Address': 'کپی آدرس', 'Send USDT': 'ارسال USDT', 'Receive': 'دریافت', 'Report Your Deposit': 'ثبت گزارش واریز', 'If you\'ve sent USDT, report it here. Admin will verify and credit your account.': 'اگر USDT ارسال کرده‌اید، اینجا ثبت کنید. سیستم بررسی می‌کند و در صورت نیاز ادمین تایید می‌کند.', 'Amount Sent (USDT)': 'مبلغ ارسال‌شده (USDT)', 'Transaction Hash (TX Hash)': 'هش تراکنش (TX Hash)', 'Submit Deposit Report': 'ثبت گزارش واریز', 'Scan this QR code to copy the exact TRC20 address.': 'این QR را اسکن کنید تا آدرس دقیق TRC20 ثبت شود.', 'Scan this QR code to copy the exact BEP20 address.': 'این QR را اسکن کنید تا آدرس دقیق BEP20 ثبت شود.', 'درخواست شما به مدیریت ارسال گردید. ۱ تا ۱۰ ساعت آینده پول به حساب اکانت شما واریز خواهد شد.': 'درخواست شما به مدیریت ارسال گردید. ۱ تا ۱۰ ساعت آینده پول به حساب اکانت شما واریز خواهد شد.', 'Important': 'مهم',
        'Withdraw USDT': 'برداشت USDT', 'KYC Verification Required': 'احراز هویت الزامی است', 'You must complete KYC verification before making withdrawals.': 'برای برداشت باید احراز هویت شما تایید شود.', 'Withdrawal Address': 'آدرس برداشت', 'Request Withdrawal': 'درخواست برداشت', 'Withdrawal History': 'تاریخچه برداشت',
        'Cloud Mine': 'ماین خودکار AI', 'Run up to 3 Cloud Mines per day. Your Mining level is calculated from approved deposits.': 'روزانه تا ۳ ماین خودکار AI اجرا کنید. سطح Mining شما بر اساس واریز تاییدشده محاسبه می‌شود.', 'Mining Cycles': 'ماینهای باقی‌مانده امروز', 'Current Mining Level': 'سطح Mining فعلی', 'Mining Mining Range': 'بازه ماین Mining', 'Available AI Markets': 'بازارهای AI موجود', 'Investment Amount (USDT)': 'مبلغ سرمایه‌گذاری (USDT)', 'Mode': 'حالت', 'Market direction is selected automatically by the AI panel.': 'جهت بازار به‌صورت خودکار توسط پنل AI انتخاب می‌شود.', 'Estimated Result': 'نتیجه تخمینی', 'Estimated Return': 'بازگشت تخمینی', 'Today\'s Mine History': 'تاریخچه ماین امروز', 'No trades today': 'امروز ماینی ندارید', 'Execute your first Cloud Mine above.': 'اولین ماین خودکار AI را از بالا اجرا کنید.', 'Time': 'زمان', 'Pair': 'جفت‌ارز', 'Amount': 'مبلغ', 'Result': 'نتیجه',
        'Referral Program': 'برنامه معرفی', 'Invite friends and earn 10% commission on every deposit': 'دوستان خود را دعوت کنید و از هر واریز ۱۰٪ کمیسیون بگیرید', 'Commission Rate': 'نرخ کمیسیون', 'Active Referrals': 'زیرمجموعه فعال', 'Your Referral Link': 'لینک معرفی شما', 'Copy': 'کپی', 'How It Works': 'روش کار', 'Recent Referral Earnings': 'آخرین درآمدهای معرفی',
        'KYC Verification': 'احراز هویت', 'Identity Verification': 'تایید هویت', 'ID Number': 'شماره مدرک', 'ID Document (Front)': 'تصویر روی مدرک', 'ID Document (Back)': 'تصویر پشت مدرک', 'Click to upload': 'برای آپلود کلیک کنید', 'Submit for Verification': 'ارسال برای تایید', 'What is KYC?': 'KYC چیست؟', 'Verify your identity to enable withdrawals': 'برای فعال شدن برداشت، هویت خود را تایید کنید', 'Your data is encrypted and secure': 'داده‌های شما رمزنگاری و امن است',
        'Admin Panel': 'پنل مدیریت', 'Users': 'کاربران', 'Withdrawals': 'برداشت‌ها', 'Transactions': 'تراکنش‌ها', 'Admin Dashboard': 'داشبورد ادمین', 'Manage Users': 'مدیریت کاربران', 'Send Funds': 'ارسال موجودی', 'Pending KYC': 'KYC در انتظار', 'Approved KYC': 'KYC تاییدشده',
        "Here's your investment overview": 'نمای کلی حساب سرمایه\u200cگذاری شما',
        'Your N-VT Miner User ID': 'شناسه کاربری NVT شما',
        'Manage Profile': 'مدیریت پروفایل',
        'Your Mining Level': 'سطح Mining شما',
        'Make a verified deposit to unlock Cloud Mine access.': 'برای فعال شدن ماین خودکار AI یک واریز تاییدشده ثبت کنید.',
        'Deposit progress loading...': 'در حال محاسبه پیشرفت واریز...',
        'Verify Now': 'تایید هویت',
        'Verify your identity to enable withdrawals and increase daily trading limits.': 'برای فعال شدن برداشت، احراز هویت خود را تکمیل کنید.',
        'Start Mining': 'شروع ماین',
        'Earn 10% bonus on every deposit by your referrals!': 'از هر واریز زیرمجموعه، ۱۰٪ پاداش دریافت کنید.',
        'Support Tickets': 'تیکت\u200cهای پشتیبانی',
        'Create a ticket and follow replies from support.': 'تیکت ثبت کنید و پاسخ\u200cهای پشتیبانی را دنبال کنید.',
        'New Ticket': 'تیکت جدید',
        'Subject': 'موضوع',
        'Priority': 'اولویت',
        'Normal': 'معمولی',
        'High': 'مهم',
        'Low': 'کم\u200cاهمیت',
        'Message': 'پیام', 'Enter 6-digit code': 'کد ۶ رقمی را وارد کنید',
        'Send Ticket': 'ارسال تیکت',
        'My Tickets': 'تیکت\u200cهای من',
        'No tickets yet': 'هنوز تیکتی ندارید',
        'Send your first support ticket from the form.': 'اولین تیکت پشتیبانی خود را از فرم ارسال کنید.',
        'Write a reply': 'پاسخ خود را بنویسید',
        'Reply': 'پاسخ',
        'This ticket is closed.': 'این تیکت بسته شده است.',
        'Ticket created': 'تیکت ایجاد شد',
        'Reply sent': 'پاسخ ارسال شد',
        'Support replied': 'پشتیبانی پاسخ داد',
        'Admin replied to your support ticket.': 'ادمین به تیکت پشتیبانی شما پاسخ داد.',
        'Support Center': 'مرکز پشتیبانی',
        'Need help with deposits, withdrawals, KYC or your account? Open a ticket and support will reply inside your account.': 'برای واریز، برداشت، احراز هویت یا حساب خود کمک لازم دارید؟ تیکت بزنید تا پشتیبانی داخل حساب پاسخ بدهد.',
        'Deposit Help': 'راهنمای واریز',
        'KYC Help': 'راهنمای KYC',
        'Withdrawal Help': 'راهنمای برداشت',
        'TXID checks, pending deposits and network selection.': 'بررسی TXID، واریزهای در انتظار و انتخاب شبکه.',
        'Upload documents and track approval status.': 'مدارک را آپلود کنید و وضعیت تایید را پیگیری کنید.',
        'KYC-required withdrawals and 10% withdrawal fee details.': 'جزئیات برداشت نیازمند KYC و کارمزد ۱۰٪ برداشت.',
        'Contact support by ticket': 'ارتباط با پشتیبانی از طریق تیکت',
        'Tickets keep all replies in one secure place. You can create a new ticket or review previous answers.': 'تیکت\u200cها همه پاسخ\u200cها را در یک بخش امن نگه می\u200cدارند. می\u200cتوانید تیکت جدید بسازید یا پاسخ\u200cهای قبلی را ببینید.',
        'Open Support Tickets': 'باز کردن تیکت\u200cهای پشتیبانی',
        'View Notifications': 'مشاهده نوتیفیکیشن\u200cها',
        'Deposit Requests': 'درخواست\u200cهای واریز',
        'Approve or reject TXID deposits from one dedicated queue.': 'واریزهای TXID را از یک صف جداگانه تایید یا رد کنید.',
        'No deposit requests': 'درخواست واریزی وجود ندارد',
        'Withdrawal Requests': 'درخواست\u200cهای برداشت',
        'Process user withdrawal requests': 'رسیدگی به درخواست\u200cهای برداشت کاربران',
        'KYC Requests': 'درخواست\u200cهای KYC',
        'Review uploaded documents and approve or reject users.': 'مدارک آپلودشده را بررسی و کاربران را تایید یا رد کنید.',
        'Reply to user tickets from one dedicated queue.': 'از یک صف جداگانه به تیکت\u200cهای کاربران پاسخ دهید.',
        'Ticket Queue': 'صف تیکت\u200cها',
        'Conversation': 'گفتگو',
        'Select a ticket': 'یک تیکت انتخاب کنید',
        'Open': 'باز',
        'Answered': 'پاسخ داده\u200cشده',
        'Closed': 'بسته\u200cشده',
        'Unread': 'خوانده\u200cنشده',
        'Send Reply': 'ارسال پاسخ',
        'Status updated': 'وضعیت تغییر کرد',
        'Write a support reply': 'پاسخ پشتیبانی را بنویسید',
        'Platform management and analytics': 'مدیریت و آمار پلتفرم',
        'Total Users': 'کل کاربران',
        'Confirmed Deposits': 'واریزهای تاییدشده',
        'Deposit Amount': 'مبلغ واریزها',
        'Pending Deposits': 'واریزهای در انتظار',
        'Financial Summary': 'خلاصه مالی',
        'User Balances': 'موجودی کاربران',
        'Total Withdrawn': 'کل برداشت\u200cشده',
        'Pending Amount': 'مبلغ در انتظار',
        'Mining Profits': 'سودهای ماین',
        'KYC Overview': 'نمای کلی KYC',
        'Pending Deposit Reviews': 'بررسی واریزهای در انتظار',
        'Process Withdrawals': 'بررسی برداشت\u200cها',
        'Add Balance to User': 'افزودن موجودی به کاربر',
        'Amount (USDT)': 'مبلغ (USDT)',
        'Description': 'توضیح',
        'Add Balance': 'افزودن موجودی',
        'Notifications': 'نوتیفیکیشن\u200cها',
        'Messages and account updates from N-VT Miner.': 'پیام\u200cها و به\u200cروزرسانی\u200cهای حساب از N-VT Miner.',
        'No notifications yet': 'هنوز نوتیفیکیشنی ندارید',
        'Admin messages and account updates will appear here.': 'پیام\u200cهای ادمین و وضعیت حساب اینجا نمایش داده می\u200cشود.',
        'Mark all read': 'همه را خوانده\u200cشده کن',
        'Send Notification': 'ارسال نوتیفیکیشن',
        'Broadcast notification sent': 'نوتیفیکیشن همگانی ارسال شد',
        'Notification sent to user': 'نوتیفیکیشن برای کاربر ارسال شد',
        'Profile': 'پروفایل',
        'View your N-VT Miner User ID and update your account information securely.': 'شناسه NVT خود را ببینید و اطلاعات حساب را امن تغییر دهید.',
        'KYC Status': 'وضعیت احراز هویت',
        'Update Account': 'به\u200cروزرسانی حساب',
        'Current Password': 'رمز فعلی',
        'New Password': 'رمز جدید',
        'Confirm New Password': 'تکرار رمز جدید',
        'Save Changes': 'ذخیره تغییرات',
        'Copy User ID': 'کپی شناسه کاربری',
        'pending': 'در انتظار',
        'approved': 'تاییدشده',
        'rejected': 'ردشده',
        'completed': 'تکمیل\u200cشده',
        'open': 'باز',
        'answered': 'پاسخ داده\u200cشده',
        'closed': 'بسته\u200cشده',
        'profit': 'سود',
        'normal': 'معمولی',
        'high': 'مهم',
        'low': 'کم\u200cاهمیت',
        'All': 'همه',
        'Pending': 'در انتظار',
        'Completed': 'تکمیل\u200cشده',
        'Rejected': 'ردشده',
        'Approved': 'تاییدشده',
        'Approve': 'تایید',
        'Reject': 'رد',
        'View Front': 'مشاهده روی مدرک',
        'View Back': 'مشاهده پشت مدرک',
        'Submitted': 'ارسال شده',
        'Phone': 'شماره تلفن',
        'Network': 'شبکه',
        'Gross': 'ناخالص',
        'Fee': 'کارمزد',
        'Amount Sent': 'مبلغ ارسالی',
        'Requested': 'درخواستی',
        'Pending Requests': 'درخواست\u200cهای در انتظار',
        'Total Approved': 'کل تاییدشده',
        'All Withdrawal History': 'همه تاریخچه برداشت',
        'Support': 'پشتیبانی',
        'Tickets': 'تیکت\u200cها',
        'Deposits': 'واریزها',
        'KYC': 'احراز هویت',
        'Email Verification Code': 'کد تایید ایمیل',
        'Enter 6-digit code': 'کد ۶ رقمی را وارد کنید',
        'Send Email Code': 'ارسال کد ایمیل',
        'Verify Code & Create Account': 'تایید کد و ساخت حساب',
        'Confirm Withdrawal': 'تایید برداشت',
        'A code was sent to the email on your account.': 'کد به ایمیل حساب شما ارسال شد.',
        'We sent a 6-digit code to your email. It expires in 10 minutes.': 'کد ۶ رقمی به ایمیل شما ارسال شد و تا ۱۰ دقیقه معتبر است.',
        'Use the referral code shared by your inviter.': 'کد معرف ارسال‌شده توسط دعوت‌کننده را وارد کنید.',
        '5-Day Deposit Lock Active': 'قفل ۵ روزه واریز فعال است',
        'Withdrawals unlock after the deposit lock period.': 'برداشت بعد از پایان دوره قفل واریز فعال می‌شود.',
        'Each verified deposit has a 5-day withdrawal lock': 'هر واریز تاییدشده ۵ روز قفل برداشت دارد',
        'Email code confirmation is required before a withdrawal is submitted': 'قبل از ثبت برداشت، تایید کد ایمیل لازم است',
        'Support email': 'ایمیل پشتیبانی',
        'Contact support': 'ارتباط با پشتیبانی',
        'Referral Boost': 'افزایش درآمد معرفی',
        'Invite, activate, and earn more': 'دعوت کنید، فعال کنید و بیشتر درآمد بگیرید',

        'Invite friends, grow your rank, and earn up to 20% commission plus rank bonuses': 'دوستان خود را دعوت کنید، رتبه معرفی را بالا ببرید و تا ۲۰٪ کمیسیون به‌همراه پاداش رتبه بگیرید',
        'Your referral rank increases as more invited users complete a verified deposit. Higher ranks unlock higher commission rates and one-time USDT bonuses.': 'با افزایش زیرمجموعه‌های فعال، رتبه رفرال شما بالاتر می‌رود. رتبه‌های بالاتر کمیسیون بیشتر و پاداش تتر یک‌باره فعال می‌کنند.',
        'Referral Ranking': 'رتبه‌بندی رفرال',
        'Rank': 'رتبه',
        'Referral Count': 'تعداد رفرال',
        'Reward': 'پاداش',
        'Bronze': 'برنز',
        'Silver': 'نقره',
        'Gold': 'طلا',
        'Platinum': 'پلاتین',
        'Your rank is based on active referrals — users who completed a verified deposit.': 'رتبه شما بر اساس زیرمجموعه‌های فعال محاسبه می‌شود؛ یعنی کاربرانی که واریز تاییدشده انجام داده‌اند.',
        'Current Lucky Wheel is for new users after their first verified deposit. A special referral wheel will be available after 5 active referrals.': 'گردونه فعلی برای کاربران جدید بعد از اولین واریز تاییدشده است. گردونه ویژه معرف بعد از ۵ زیرمجموعه فعال ارائه می‌شود.',
        'This Lucky Wheel is for new users after their first verified deposit.': 'این گردونه مخصوص کاربران جدید بعد از اولین واریز تاییدشده است.',
        'New users receive 1 spin after their first verified deposit of 100 USDT or more.': 'کاربران جدید بعد از اولین واریز تاییدشده ۱۰۰ USDT یا بیشتر، ۱ شانس چرخش دریافت می‌کنند.',
        'Make First Deposit': 'اولین واریز را انجام دهید',
        'This Lucky Wheel is for new users after their first verified deposit of 100 USDT or more.': 'این گردونه برای کاربران جدید است و بعد از اولین واریز تاییدشده ۱۰۰ USDT یا بیشتر فعال می‌شود.',
        'Each eligible new user receives 1 normal Lucky Wheel spin after the first qualifying deposit is approved.': 'هر کاربر جدید واجد شرایط بعد از تایید اولین واریز، ۱ شانس گردونه معمولی دریافت می‌کند.',
        'A special referral wheel will be introduced for referrers after 5 active referrals.': 'گردونه ویژه معرف‌ها بعد از ۵ زیرمجموعه فعال اضافه می‌شود.',
        'Your first qualified deposit unlocked 1 Lucky Wheel spin.': 'اولین واریز واجد شرایط شما ۱ شانس گردونه فعال کرد.',
        'Referral rank bonus unlocked': 'پاداش رتبه رفرال فعال شد',

        'Lucky Wheel': 'گردونه شانس',
        'Referral Campaign': 'کمپین معرفی',
        'Invite active users, unlock spin chances, and win USDT rewards.': 'کاربران فعال دعوت کنید، شانس چرخش بگیرید و پاداش USDT برنده شوید.',
        'Lucky Wheel Chances': 'شانس‌های گردونه',
        'Earn 1 spin when a referred user completes a verified qualifying deposit.': 'وقتی کاربر معرفی‌شده واریز واجد شرایط و تاییدشده انجام دهد، ۱ شانس چرخش می‌گیرید.',
        'Invite Friends': 'دعوت از دوستان',
        'Total Wheel Rewards': 'کل پاداش‌های گردونه',
        'Cash rewards are credited directly to your N-VT Miner balance after a winning spin.': 'پاداش‌های نقدی بعد از برنده شدن مستقیم به موجودی NVT شما اضافه می‌شوند.',
        'Activity Rules': 'قوانین فعالیت',
        'My Rewards': 'جوایز من',
        'Remaining chances:': 'شانس‌های باقی‌مانده:',
        'Spin Now': 'چرخاندن',
        'Lucky Wheel Rules': 'قوانین گردونه شانس',
        'Every user can earn spin chances by inviting new users who complete a verified deposit of 100 USDT or more.': 'هر کاربر می‌تواند با دعوت کاربران جدیدی که واریز تاییدشده ۱۰۰ USDT یا بیشتر انجام دهند، شانس چرخش دریافت کند.',
        'Each successful referral activation gives the inviter 1 Lucky Wheel spin chance.': 'هر فعال‌سازی موفق معرفی، ۱ شانس چرخش گردونه به دعوت‌کننده می‌دهد.',
        'Cash rewards are added to the account balance automatically after the spin result is confirmed.': 'پاداش‌های نقدی پس از تایید نتیجه چرخش، خودکار به موجودی حساب اضافه می‌شوند.',
                'Fake accounts, repeated abuse, invalid deposits, or suspicious activity can lead to reward cancellation and account review.': 'حساب جعلی، سوءاستفاده تکراری، واریز نامعتبر یا فعالیت مشکوک می‌تواند باعث لغو پاداش و بررسی حساب شود.',
                'My Lucky Wheel Rewards': 'جوایز گردونه من',
        'No wheel rewards yet': 'هنوز جایزه‌ای از گردونه ندارید',
        'Invite an active user to unlock your first spin.': 'برای گرفتن اولین شانس چرخش، یک کاربر فعال دعوت کنید.',
        'Lucky Wheel is active': 'گردونه شانس فعال است',
        'Open Lucky Wheel': 'رفتن به گردونه',
        'You have a new message': 'اعلان یا پیام جدید دارید',
        'View messages': 'مشاهده پیام‌ها',
        'Later': 'بعداً',
        'You do not have any Lucky Wheel spins yet': 'فعلاً هیچ شانسی برای گردونه ندارید',
        'Lucky Wheel campaign is currently inactive': 'کمپین گردونه شانس در حال حاضر غیرفعال است',
        'Lucky Wheel chance added': 'شانس گردونه به حساب شما اضافه شد',
        'Your deposit was confirmed and 1 Lucky Wheel chance was added to your account.': 'واریز شما تایید شد و ۱ شانس گردونه به حساب شما اضافه شد.',
        'You won': 'برنده شدید',
        'Added to your balance.': 'به موجودی شما اضافه شد.',
        '17 USDT': '۱۷ تتر', '25 USDT': '۲۵ تتر', '39 USDT': '۳۹ تتر', '50 USDT': '۵۰ تتر', '70 USDT': '۷۰ تتر', 'Extra Spin': 'چرخش دوباره', 'Washer': 'ماشین لباسشویی', 'Washing Machine': 'ماشین لباسشویی', 'Refrigerator': 'یخچال', 'iPhone 17': 'آیفون ۱۷', 'iPhone 17 Pro Max': 'آیفون ۱۷ پرو مکس',

        'Invite friends and earn 10% commission plus a 5 USDT activation bonus': 'دوستانتان را دعوت کنید و ۱۰٪ کمیسیون به‌همراه ۵ USDT پاداش فعال‌سازی بگیرید',
        'Earn 10% from each verified deposit plus a one-time 5 USDT active referral bonus when your invited user completes their first qualifying deposit.': 'از هر واریز تاییدشده ۱۰٪ بگیرید و وقتی کاربر دعوت‌شده اولین واریز واجدشرایط خود را کامل کرد، یک پاداش ۵ USDT هم دریافت کنید.',
        'Share my link': 'اشتراک لینک من',
        'You can trade each pair only once per day. Choose another pair.': 'هر جفت‌ارز را فقط یک‌بار در روز می‌توانید ماین کنید. جفت‌ارز دیگری انتخاب کنید.',
        'Used today': 'امروز استفاده شده',
        'one trade per pair/day': 'یک ماین برای هر جفت‌ارز در روز',
        'Opening NVT...': 'در حال باز کردن NVT...',
        'Loading page...': 'در حال بارگذاری صفحه...',
        'Loading NVT...': 'در حال بارگذاری NVT...',

        'Home': 'خانه',
        'Assets': 'دارایی',
        'Convert': 'تبدیل',
        'More': 'بیشتر',
        'Menu': 'منو',
        'N-VT Miner Menu': 'منوی NVT',
        'All account tools in one place.': 'همه ابزارهای حساب در یک بخش.',
        'Account': 'حساب کاربری',
        'Funds': 'مالی',
        'More tools': 'ابزارهای بیشتر',
        'Quick actions': 'دسترسی سریع',
        'Users': 'کاربران',
        'Deposits': 'واریزی‌ها',
        'Withdrawals': 'برداشت‌ها',
        'Tickets': 'تیکت‌ها',
        'Notifications': 'اعلان‌ها',
        'Broadcast': 'ارسال اعلان',
        'Download app': 'نصب برنامه',
        'KYC Verification': 'احراز هویت',
        'Referral Program': 'برنامه معرفی',
        'Minimum withdrawal: $100': 'حداقل برداشت: ۱۰۰ دلار',
        'Minimum withdrawal amount: $100 USDT': 'حداقل مبلغ برداشت: ۱۰۰ USDT',
        'Minimum withdrawal is $100': 'حداقل برداشت ۱۰۰ دلار است',
        'Minimum withdrawal is 100 USDT': 'حداقل برداشت ۱۰۰ USDT است',
        '5D Lock': 'قفل ۵روزه',
        '5-Day Withdrawal Lock': 'قفل برداشت ۵روزه',
        'Disabled for this user': 'برای این کاربر غیرفعال است',
        'Disable 5D': 'غیرفعال‌کردن ۵روز',
        'Enable 5D': 'فعال‌کردن ۵روز',
        'Active': 'فعال',
        'Disabled': 'غیرفعال',
        'Disable the 5-day withdrawal lock for this user?': 'قفل برداشت ۵روزه برای این کاربر غیرفعال شود؟',
        'Enable the 5-day withdrawal lock again for this user?': 'قفل برداشت ۵روزه دوباره برای این کاربر فعال شود؟',
        'Withdrawal lock updated': 'وضعیت قفل برداشت بروزرسانی شد',
        'Deposit & Withdraw': 'واریز و برداشت',
        'Manage your USDT balance directly.': 'موجودی تتر خود را مستقیم مدیریت کنید.',
        'Miner Rental Plans': 'پلن‌های کرایه ماینر',
        'View Profit Rates': 'مشاهده سوددهی',
        '24-hour plan costs and profit rates': 'هزینه پلن‌ها و درصد سود ۲۴ ساعته',
        'Choose a 24h miner plan. Principal and mining profit are credited automatically after completion.': 'یک پلن ماینر ۲۴ ساعته انتخاب کنید. اصل مبلغ و سود پس از پایان به‌صورت خودکار به حساب اضافه می‌شود.',
        'Choose BTC, ETH, DOGE or USDT and rent a 24h miner. Completed miners are credited automatically after 24 hours.': 'دارایی ماین را انتخاب کنید و یک ماینر ۲۴ ساعته کرایه کنید. پس از پایان، مبلغ به‌صورت خودکار به حساب اضافه می‌شود.',
        '24h Mining Plans': 'پلن‌های ماین ۲۴ ساعته',
        'Active Mining Contracts': 'ماینرهای فعال',
        'Mining History': 'تاریخچه ماین',
        'My Mining Asset Balances': 'موجودی دارایی‌های ماین‌شده',
        'Choose Mining Asset': 'انتخاب دارایی ماین',
        'Automatically credited after the countdown ends': 'پس از پایان شمارش، به‌صورت خودکار به حساب اضافه می‌شود',
        'Crediting automatically...': 'در حال واریز خودکار...',
        'Auto credited': 'واریز خودکار انجام شد',
        'Mining profit:': 'سود ماین:',
        'Start Mining Contract': 'شروع ماینر',
        'Start 24h Mining Contract': 'شروع ماینر ۲۴ ساعته',
        'Starter Miner': 'ماینر استارتر',
        'Bronze Miner': 'ماینر برنزی',
        'Silver Miner': 'ماینر نقره‌ای',
        'Gold Miner': 'ماینر طلایی',
        'Platinum Miner': 'ماینر پلاتینیوم',
        'Diamond Miner': 'ماینر الماس',
    };

    const placeholders = {
        'Enter your email': 'ایمیل خود را وارد کنید', 'Enter your password': 'رمز عبور را وارد کنید', 'Enter your full name': 'نام کامل خود را وارد کنید', 'Enter your phone number': 'شماره تلفن خود را وارد کنید', 'Create a password (min 6 chars)': 'رمز عبور بسازید (حداقل ۶ کاراکتر)', 'Enter referral code': 'کد معرف را وارد کنید', 'Minimum 50 USDT': 'حداقل ۵۰ USDT', 'Enter amount': 'مبلغ را وارد کنید', 'Enter TX hash from your wallet': 'هش تراکنش را وارد کنید', 'Enter withdrawal wallet address': 'آدرس کیف پول برداشت را وارد کنید', 'How much did you send?': 'چه مقدار ارسال کردید؟', 'Write a short subject': 'موضوع کوتاه را بنویسید', 'Explain your issue clearly': 'مشکل خود را واضح توضیح دهید', 'Write a reply': 'پاسخ خود را بنویسید', 'Write a support reply': 'پاسخ پشتیبانی را بنویسید', 'User ID': 'شناسه کاربر', 'Optional note': 'یادداشت اختیاری', 'Subject': 'موضوع', 'Message': 'پیام', 'Enter 6-digit code': 'کد ۶ رقمی را وارد کنید'
    };

    function normalize(str) { return String(str || '').replace(/\s+/g, ' ').trim(); }

    function translateTextNode(node) {
        const raw = node.nodeValue;
        const trimmed = normalize(raw);
        if (!trimmed || !fa[trimmed]) return;
        node.nodeValue = raw.replace(raw.trim(), fa[trimmed]);
    }

    function walk(root) {
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
            acceptNode(node) {
                const parent = node.parentElement;
                if (!parent) return NodeFilter.FILTER_REJECT;
                if (['SCRIPT', 'STYLE', 'TEXTAREA'].includes(parent.tagName)) return NodeFilter.FILTER_REJECT;
                if (parent.closest('.mono, code, pre, .wallet-address, #trc20Address, #bep20Address, #depositTxHash')) return NodeFilter.FILTER_REJECT;
                return NodeFilter.FILTER_ACCEPT;
            }
        });
        const nodes = [];
        while (walker.nextNode()) nodes.push(walker.currentNode);
        nodes.forEach(translateTextNode);
        document.querySelectorAll('input[placeholder], textarea[placeholder]').forEach(el => {
            const value = el.getAttribute('placeholder');
            if (placeholders[value]) el.setAttribute('placeholder', placeholders[value]);
        });
        document.querySelectorAll('title').forEach(t => {
            Object.entries(fa).forEach(([en, tr]) => { if (t.textContent.includes(en)) t.textContent = t.textContent.replace(en, tr); });
        });
    }

    function setLanguage(lang) {
        lang = lang || 'en';
        localStorage.setItem(STORAGE_KEY, lang);
        document.documentElement.lang = lang;
        document.documentElement.dir = RTL_LANGS.has(lang) ? 'rtl' : 'ltr';
        document.body.classList.toggle('rtl', RTL_LANGS.has(lang));
        document.body.classList.toggle('auto-translated', !['en', 'fa'].includes(lang));
        if (lang === 'fa') { setGoogleCookie('fa'); walk(document.body); }
        else if (lang === 'en') { setGoogleCookie('en'); }
        else loadGoogleTranslate(lang);
        const select = document.querySelector('#languageSelect');
        if (select) select.value = lang;
    }

    function languageOptionsHtml() {
        return GOOGLE_LANGUAGES.map(([code, label]) => `<option value="${code}">${label}</option>`).join('');
    }

    function addLanguageSwitcher() {
        if (document.querySelector('#languageSelect')) return;
        const wrap = document.createElement('div');
        wrap.className = 'language-switcher';
        wrap.innerHTML = `<select id="languageSelect" aria-label="Language">${languageOptionsHtml()}</select>`;
        const navbarActions = document.querySelector('.navbar-actions');
        if (navbarActions) navbarActions.prepend(wrap);
        else {
            const card = document.querySelector('.auth-card');
            if (card) { card.classList.add('auth-card-with-language'); card.prepend(wrap); }
        }
        wrap.querySelector('select').addEventListener('change', e => {
            const next = e.target.value;
            localStorage.setItem(STORAGE_KEY, next);
            setGoogleCookie(next);
            // Reload keeps Google Translate and the native EN/FA translator from fighting each other.
            location.href = location.pathname + location.search + location.hash;
        });
    }

    document.addEventListener('DOMContentLoaded', () => {
        addLanguageSwitcher();
        setLanguage(localStorage.getItem(STORAGE_KEY) || 'en');
        // Observe only newly-added DOM nodes. Observing characterData here caused
        // the translator to react to its own text changes and could freeze Chrome/PWA.
        let translateTimer = null;
        const observerConfig = { childList: true, subtree: true };
        const observer = new MutationObserver((mutations) => {
            if ((localStorage.getItem(STORAGE_KEY) || 'en') !== 'fa') return;
            const hasAddedNodes = mutations.some(mutation => mutation.addedNodes && mutation.addedNodes.length);
            if (!hasAddedNodes) return;
            clearTimeout(translateTimer);
            translateTimer = setTimeout(() => {
                observer.disconnect();
                try { walk(document.body); }
                finally { observer.observe(document.body, observerConfig); }
            }, 60);
        });
        observer.observe(document.body, observerConfig);
    });
})();
