// N-VT Miner - Main JavaScript

// API Configuration
const API_BASE = '/api';

// Token management
const TokenManager = {
    get() {
        return localStorage.getItem('token');
    },
    set(token) {
        localStorage.setItem('token', token);
    },
    remove() {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
    },
    getUser() {
        const user = localStorage.getItem('user');
        return user ? JSON.parse(user) : null;
    },
    setUser(user) {
        localStorage.setItem('user', JSON.stringify(user));
    }
};

// API Helper
async function api(endpoint, options = {}) {
    const token = TokenManager.get();
    
    const headers = {
        'Content-Type': 'application/json',
        ...(token && { 'Authorization': `Bearer ${token}` }),
        ...options.headers
    };

    try {
        const response = await fetch(`${API_BASE}${endpoint}`, {
            ...options,
            headers
        });

        const data = await response.json();
        
        if (!response.ok) {
            if (response.status === 401) {
                TokenManager.remove();
                window.location.href = '/login';
            }
            throw new Error(data.message || 'Request failed');
        }

        return data;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}


async function apiForm(endpoint, formData, options = {}) {
    const token = TokenManager.get();
    const headers = {
        ...(token && { 'Authorization': `Bearer ${token}` }),
        ...(options.headers || {})
    };
    const response = await fetch(`${API_BASE}${endpoint}`, {
        ...options,
        method: options.method || 'POST',
        headers,
        body: formData
    });
    const data = await response.json();
    if (!response.ok) {
        if (response.status === 401) {
            TokenManager.remove();
            window.location.href = '/login';
        }
        throw new Error(data.message || 'Request failed');
    }
    return data;
}

// Toast Notifications
const Toast = {
    container: null,
    
    init() {
        if (!this.container) {
            this.container = document.createElement('div');
            this.container.className = 'toast-container';
            document.body.appendChild(this.container);
        }
    },

    show(message, type = 'info', duration = 4000) {
        this.init();
        
        const icons = {
            success: '✓',
            error: '✕',
            warning: '⚠',
            info: 'ℹ'
        };

        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <span class="toast-icon">${icons[type]}</span>
            <span class="toast-message">${message}</span>
        `;

        this.container.appendChild(toast);

        setTimeout(() => {
            toast.style.animation = 'slideIn 0.3s ease reverse';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    },

    success(message) { this.show(message, 'success'); },
    error(message) { this.show(message, 'error'); },
    warning(message) { this.show(message, 'warning'); },
    info(message) { this.show(message, 'info'); }
};

// Format numbers
function formatNumber(num, decimals = 2) {
    if (num === null || num === undefined) return '0.00';
    return Number(num).toLocaleString('en-US', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
    });
}

// Format currency
function formatCurrency(amount) {
    return '$' + formatNumber(amount);
}

// Format date
function formatDate(dateStr) {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Copy to clipboard
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        Toast.success('Copied to clipboard!');
    } catch (err) {
        Toast.error('Failed to copy');
    }
}

// Format wallet address
function formatAddress(address, chars = 6) {
    if (!address) return '';
    return `${address.slice(0, chars)}...${address.slice(-chars)}`;
}

// Check authentication
function requireAuth() {
    const token = TokenManager.get();
    if (!token) {
        window.location.href = '/login';
        return false;
    }
    return true;
}

// Check admin role
function requireAdmin() {
    const user = TokenManager.getUser();
    if (!user || user.role !== 'admin') {
        window.location.href = '/dashboard';
        return false;
    }
    return true;
}

// Logout
async function logout() {
    TokenManager.remove();
    window.location.href = '/login';
}

// Auth functions
const Auth = {
    async login(email, password) {
        const data = await api('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });

        if (data.success) {
            TokenManager.set(data.token);
            TokenManager.setUser(data.user);
        }

        return data;
    },

    async sendRegisterCode(email, password, referralCode) {
        return api('/auth/register/send-code', {
            method: 'POST',
            body: JSON.stringify({ email, password, referral_code: referralCode })
        });
    },

    async register(email, password, referralCode, fullName, emailCode = '') {
        const data = await api('/auth/register', {
            method: 'POST',
            body: JSON.stringify({
                email,
                password,
                referral_code: referralCode,
                full_name: fullName,
                email_code: emailCode
            })
        });

        if (data.success) {
            TokenManager.set(data.token);
            TokenManager.setUser(data.user);
        }

        return data;
    }
};

// User functions
const User = {
    async getProfile() {
        return api('/user/profile');
    },

    async getDashboard() {
        return api('/user/dashboard');
    },

    async updateAccount(payload) {
        const data = await api('/user/account', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        if (data.success) {
            if (data.token) TokenManager.set(data.token);
            if (data.user) TokenManager.setUser(data.user);
        }
        return data;
    }
};

// Wallet functions
const Wallet = {
    async getAddresses() {
        return api('/wallet/addresses');
    },

    async getBalance() {
        return api('/wallet/balance');
    },

    async getAssets() {
        return api('/wallet/assets');
    },

    async getTransactions(page = 1) {
        return api(`/wallet/transactions?page=${page}`);
    },

    async deposit(amount, network) {
        return api('/wallet/deposit', {
            method: 'POST',
            body: JSON.stringify({ amount, network })
        });
    }
};

// Mine functions
const Mine = {
    async getPairs() {
        return api('/mine/pairs');
    },

    async execute(pair, direction, amount) {
        return api('/mine/execute', {
            method: 'POST',
            body: JSON.stringify({ pair, direction, amount })
        });
    },

    async claim(id) {
        return api(`/mine/claim/${id}`, { method: 'POST' });
    },

    async convert(asset, amount) {
        return api('/mine/convert', {
            method: 'POST',
            body: JSON.stringify({ asset, amount })
        });
    },

    async getHistory() {
        return api('/mine/history');
    }
};

// Referral functions
const Referral = {
    async getInfo() {
        return api('/referral/info');
    },

    async getLink() {
        return api('/referral/link');
    }
};

// Withdraw functions
const Withdraw = {
    async sendCode(amount, walletAddress, network, asset = 'USDT') {
        return api('/withdraw/send-code', {
            method: 'POST',
            body: JSON.stringify({ amount, wallet_address: walletAddress, network, asset })
        });
    },

    async request(amount, walletAddress, network, emailCode = '', asset = 'USDT') {
        return api('/withdraw/request', {
            method: 'POST',
            body: JSON.stringify({ amount, wallet_address: walletAddress, network, email_code: emailCode, asset })
        });
    },

    async getHistory() {
        return api('/withdraw/history');
    }
};

// KYC functions
const KYC = {
    async getStatus() {
        return api('/kyc/status');
    },

    async submit(data) {
        if (data instanceof FormData) {
            return apiForm('/kyc/submit', data);
        }
        return api('/kyc/submit', {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }
};


// Notification functions
const Notifications = {
    async list(lang = (localStorage.getItem('nexavest_lang') || 'en')) {
        return api(`/notifications?lang=${encodeURIComponent(lang)}`);
    },
    async unreadCount() {
        return api('/notifications/unread-count');
    },
    async markRead(id) {
        return api(`/notifications/${id}/read`, { method: 'POST', body: JSON.stringify({}) });
    },
    async markAllRead() {
        return api('/notifications/mark-all-read', { method: 'POST', body: JSON.stringify({}) });
    }
};

// Ticket / support functions
const Tickets = {
    async my() { return api('/tickets/my'); },
    async create(payload) { return api('/tickets', { method: 'POST', body: JSON.stringify(payload) }); },
    async detail(id) { return api(`/tickets/${id}`); },
    async reply(id, message) { return api(`/tickets/${id}/reply`, { method: 'POST', body: JSON.stringify({ message }) }); },
    async adminList(status = 'open') { return api(`/tickets/admin?status=${encodeURIComponent(status)}`); },
    async setStatus(id, status) { return api(`/tickets/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }); }
};

// Lucky Wheel functions
const Wheel = {
    async status() { return api('/wheel/status'); },
    async spin() { return api('/wheel/spin', { method: 'POST', body: JSON.stringify({}) }); },
    async admin() { return api('/wheel/admin'); },
    async updateSettings(payload) { return api('/wheel/admin/settings', { method: 'PATCH', body: JSON.stringify(payload) }); },
    async updateUserSpins(id, mode, amount) { return api(`/wheel/admin/users/${id}/spins`, { method: 'POST', body: JSON.stringify({ mode, amount }) }); }
};

// Admin functions
const Admin = {
    async getStats() {
        return api('/admin/stats');
    },

    async getRequestCounts() {
        return api('/admin/request-counts');
    },

    async getUsers(page = 1, q = '') {
        const params = new URLSearchParams({ page: String(page) });
        if (q) params.set('q', q);
        return api(`/admin/users?${params.toString()}`);
    },

    async getUser(id) {
        return api(`/admin/users/${id}`);
    },

    async updateUser(id, payload) {
        return api(`/admin/users/${id}`, {
            method: 'PATCH',
            body: JSON.stringify(payload)
        });
    },

    async adjustBalance(id, mode, amount, description, balance_type = 'locked') {
        return api(`/admin/users/${id}/balance`, {
            method: 'POST',
            body: JSON.stringify({ mode, amount, description, balance_type })
        });
    },

    async adjustCryptoBalance(id, asset, mode, amount, description) {
        return api(`/admin/users/${id}/crypto-balance`, {
            method: 'POST',
            body: JSON.stringify({ asset, mode, amount, description })
        });
    },

    async setWithdrawLock(id, disabled) {
        return api(`/admin/users/${id}/withdraw-lock`, {
            method: 'PATCH',
            body: JSON.stringify({ disabled })
        });
    },

    async setReferralWithdrawLimit(id, disabled) {
        return api(`/admin/users/${id}/referral-withdraw-limit`, {
            method: 'PATCH',
            body: JSON.stringify({ disabled })
        });
    },

    async bulkReferralWithdrawLimit(disabled) {
        return api('/admin/users/referral-withdraw-limit/bulk', {
            method: 'PATCH',
            body: JSON.stringify({ disabled })
        });
    },

    async getPendingDeposits() {
        return api('/deposit/pending');
    },

    async processDeposit(id, action, notes = '') {
        return api(`/deposit/approve/${id}`, {
            method: 'POST',
            body: JSON.stringify({ action, notes })
        });
    },

    async getWithdrawals() {
        return api('/admin/withdrawals');
    },

    async getWithdrawalSettings() {
        return api('/admin/withdrawal-settings');
    },

    async updateWithdrawalSettings(payload) {
        return api('/admin/withdrawal-settings', {
            method: 'PATCH',
            body: JSON.stringify(payload)
        });
    },

    async getKycPending() {
        return api('/admin/kyc-pending');
    },

    async processWithdrawal(id, action, txHash, notes) {
        return api(`/admin/withdrawals/${id}`, {
            method: 'POST',
            body: JSON.stringify({ action, tx_hash: txHash, notes })
        });
    },

    async processKyc(id, action) {
        return api(`/admin/kyc/${id}`, {
            method: 'POST',
            body: JSON.stringify({ action })
        });
    },

    async addDeposit(userId, amount, description) {
        return api('/admin/deposit', {
            method: 'POST',
            body: JSON.stringify({ user_id: userId, amount, description })
        });
    },

    async getKycRequests(status = 'pending') {
        return api(`/admin/kyc-requests?status=${encodeURIComponent(status)}`);
    },

    async getDepositsAll(status = 'pending') {
        return api(`/admin/deposits-all?status=${encodeURIComponent(status)}`);
    },

    async getWithdrawalsAll(status = 'pending') {
        return api(`/admin/withdrawals-all?status=${encodeURIComponent(status)}`);
    },

    async getNotifications() {
        return api('/admin/notifications');
    },

    async sendNotification(payload) {
        return api('/admin/notifications', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
    },

    async deleteNotification(id) {
        return api(`/admin/notifications/${encodeURIComponent(id)}`, {
            method: 'DELETE'
        });
    }
};

// Crypto prices for ticker (simulated)
const cryptoPrices = {
    'BTC/USDT': { price: 67523.45, change: 2.34 },
    'ETH/USDT': { price: 3456.78, change: 1.56 },
    'BNB/USDT': { price: 582.34, change: -0.78 },
    'SOL/USDT': { price: 145.67, change: 5.23 },
    'XRP/USDT': { price: 0.5234, change: -1.23 },
    'ADA/USDT': { price: 0.4567, change: 0.89 },
    'DOGE/USDT': { price: 0.1234, change: 3.45 },
    'DOT/USDT': { price: 7.23, change: -0.56 }
};

// Generate price ticker
function generateTickerHTML() {
    let html = '';
    const items = Object.entries(cryptoPrices);
    // Duplicate for seamless scroll
    [...items, ...items].forEach(([pair, data]) => {
        const changeClass = data.change >= 0 ? 'up' : 'down';
        const changeSign = data.change >= 0 ? '+' : '';
        html += `
            <div class="ticker-item">
                <span class="ticker-symbol">${pair}</span>
                <span class="ticker-price">$${formatNumber(data.price, pair.includes('XRP') || pair.includes('ADA') || pair.includes('DOGE') ? 4 : 2)}</span>
                <span class="ticker-change ${changeClass}">${changeSign}${data.change}%</span>
            </div>
        `;
    });
    return html;
}

// Initialize ticker
function initTicker() {
    const tickerContainer = document.getElementById('priceTicker');
    if (tickerContainer) {
        tickerContainer.innerHTML = `<div class="ticker-scroll">${generateTickerHTML()}</div>`;
    }
}

// Update user info in navbar
function updateUserNavbar() {
    const user = TokenManager.getUser();
    if (!user) return;

    const userNameEl = document.getElementById('userName');
    const userBalanceEl = document.getElementById('userBalance');

    if (userNameEl) userNameEl.textContent = user.full_name || user.email;
    if (userBalanceEl) userBalanceEl.textContent = formatCurrency(user.wallet_balance);
}

// Protected page guard
function protectPage() {
    if (!requireAuth()) return;
    updateUserNavbar();
}

// Form validation helper
function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validatePassword(password) {
    return password.length >= 6;
}

// Get URL params
function getUrlParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

// Generate countdown HTML
function createCountdown(seconds, onComplete) {
    const update = () => {
        const hours = Math.floor(seconds / 3600);
        const mins = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;

        document.querySelectorAll('.countdown-value').forEach((el, i) => {
            el.textContent = [hours, mins, secs][i].toString().padStart(2, '0');
        });

        if (seconds > 0) {
            seconds--;
            setTimeout(update, 1000);
        } else if (onComplete) {
            onComplete();
        }
    };

    update();
}


// Add top navigation shortcuts for notifications and admin request queues.
function makeNavBadge(id) {
    return `<span id="${id}" class="nav-count-badge" style="display:none">0</span>`;
}

function setBadge(id, value) {
    const el = document.getElementById(id);
    if (!el) return;
    const n = Number(value || 0);
    el.textContent = n > 99 ? '99+' : String(n);
    el.style.display = n > 0 ? 'inline-flex' : 'none';
}

// Add top navigation shortcuts for notifications, support, and admin request queues.
function initDynamicNav() {
    const user = TokenManager.getUser();
    const menu = document.querySelector('.navbar-menu');
    if (!menu || !user) return;

    const addLink = (href, label, extra = '') => {
        const existing = menu.querySelector(`a[href="${href}"]`);
        if (existing) {
            if (label.includes('nav-count-badge') && !existing.querySelector('.nav-count-badge')) {
                const tmp = document.createElement('span');
                tmp.innerHTML = label;
                const badge = tmp.querySelector('.nav-count-badge');
                if (badge) existing.appendChild(badge);
            }
            return;
        }
        const a = document.createElement('a');
        a.href = href;
        a.className = `nav-link ${extra}`.trim();
        a.innerHTML = label;
        menu.appendChild(a);
    };

    document.querySelectorAll('.user-menu').forEach(el => {
        if (user.role !== 'admin') {
            el.classList.add('clickable-user-menu');
            el.addEventListener('click', () => { window.location.href = '/profile'; });
        }
    });

    if (user.role === 'admin') {
        addLink('/admin-deposits', `Deposits ${makeNavBadge('adminDepositBadge')}`);
        addLink('/admin-withdrawals', `Withdrawals ${makeNavBadge('adminWithdrawBadge')}`);
        addLink('/admin-kyc', `KYC ${makeNavBadge('adminKycBadge')}`);
        addLink('/admin-tickets', `Tickets ${makeNavBadge('adminTicketBadge')}`);
        addLink('/admin-notifications', 'Notifications');
        addLink('/admin-wheel', `Lucky Wheel ${makeNavBadge('adminWheelBadge')}`);
        ['/admin-deposits','/admin-withdrawals','/admin-kyc','/admin-tickets','/admin-notifications','/admin-wheel'].forEach(href => {
            if (location.pathname === href) menu.querySelector(`a[href="${href}"]`)?.classList.add('active');
        });
        Admin.getRequestCounts().then(r => {
            if (!r.success) return;
            setBadge('adminDepositBadge', r.counts.deposits);
            setBadge('adminWithdrawBadge', r.counts.withdrawals);
            setBadge('adminKycBadge', r.counts.kyc);
            setBadge('adminTicketBadge', r.counts.tickets || r.counts.open_tickets);
            setBadge('adminWheelBadge', r.counts.wheel_spins || 0);
            document.querySelectorAll('[data-admin-count="deposits"]').forEach(el => el.textContent = r.counts.deposits || 0);
            document.querySelectorAll('[data-admin-count="withdrawals"]').forEach(el => el.textContent = r.counts.withdrawals || 0);
            document.querySelectorAll('[data-admin-count="kyc"]').forEach(el => el.textContent = r.counts.kyc || 0);
            document.querySelectorAll('[data-admin-count="tickets"]').forEach(el => el.textContent = r.counts.tickets || r.counts.open_tickets || 0);
        }).catch(() => null);
        return;
    }

    addLink('/support', 'Support');
    addLink('/tickets', 'Tickets');
    addLink('/lucky-wheel', '🎡 Lucky Wheel');
    addLink('/notifications', `🔔 Notifications <span id="notifBadge" class="notif-badge" style="display:none">0</span>`);
    ['/support','/tickets','/notifications','/lucky-wheel'].forEach(href => {
        if (location.pathname === href) menu.querySelector(`a[href="${href}"]`)?.classList.add('active');
    });
    Notifications.unreadCount().then(r => {
        const badge = document.getElementById('notifBadge');
        if (badge && r.success && r.unread > 0) {
            badge.textContent = r.unread;
            badge.style.display = 'inline-flex';
        }
    }).catch(() => null);
}


// App-like loading overlay and mobile bottom navigation
function showAppLoader(text = 'Loading NVT...') {
    let loader = document.getElementById('appLoader');
    if (!loader) {
        loader = document.createElement('div');
        loader.id = 'appLoader';
        loader.className = 'app-loader';
        loader.innerHTML = `
            <div class="app-loader-card">
                <div class="app-loader-logo">NVT</div>
                <div class="app-loader-ring"></div>
                <p id="appLoaderText">${text}</p>
            </div>`;
        document.body.appendChild(loader);
    }
    const txt = document.getElementById('appLoaderText');
    if (txt) txt.textContent = text;
    loader.classList.remove('hidden');
}

function hideAppLoader() {
    const loader = document.getElementById('appLoader');
    if (loader) loader.classList.add('hidden');
}

function initPageLoader() {
    showAppLoader('Opening NVT...');
    setTimeout(hideAppLoader, 650);
    document.addEventListener('click', (event) => {
        const link = event.target.closest('a[href]');
        if (!link) return;
        const href = link.getAttribute('href') || '';
        if (!href || href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:') || link.target === '_blank') return;
        try {
            const url = new URL(href, window.location.origin);
            if (url.origin === window.location.origin && url.pathname !== window.location.pathname) {
                showAppLoader('Loading page...');
            }
        } catch {}
    });
}


function uiLabel(text) {
    const lang = localStorage.getItem('nexavest_lang') || 'en';
    if (lang !== 'fa') return text;
    const map = {
        'Home': 'خانه', 'Assets': 'دارایی', 'Mine': 'ماین', 'Convert': 'تبدیل', 'Wheel': 'گردونه', 'More': 'بیشتر', 'Lucky Wheel': 'گردونه شانس',
        'Admin': 'مدیر', 'Users': 'کاربران', 'Withdraw': 'برداشت', 'Tickets': 'تیکت‌ها',
        'Dashboard': 'داشبورد', 'Profile': 'پروفایل', 'VIP Level': 'سطح VIP', 'Notifications': 'اعلان‌ها',
        'Support': 'پشتیبانی', 'KYC Verification': 'احراز هویت', 'Deposit': 'واریز', 'Referral': 'معرفی',
        'Referral Program': 'برنامه معرفی', 'Download app': 'نصب برنامه', 'Logout': 'خروج', 'Wallet': 'کیف پول',
        'Deposits': 'واریزی‌ها', 'Withdrawals': 'برداشت‌ها', 'KYC': 'احراز هویت', 'Broadcast': 'ارسال اعلان', 'Wheel': 'گردونه',
        'Account': 'حساب کاربری', 'Funds': 'مالی', 'Quick actions': 'دسترسی سریع', 'More tools': 'ابزارهای بیشتر',
        'N-VT Miner Menu': 'منوی NVT', 'All account tools in one place.': 'همه ابزارهای حساب در یک بخش.'
    };
    return map[text] || text;
}

function initMobileBottomNav() {
    const user = TokenManager.getUser();
    if (!user || document.querySelector('.mobile-bottom-nav')) return;
    const isAdmin = user.role === 'admin';
    const items = isAdmin ? [
        ['/admin', '⌂', 'Admin'], ['/admin-users', '👥', 'Users'], ['/admin-withdrawals', '↗', 'Withdraw'], ['/admin-tickets', '💬', 'Tickets'], ['#more', '☰', 'More']
    ] : [
        ['/dashboard', '⌂', 'Home'], ['/wallet', '▣', 'Assets'], ['/mine', '$', 'Mine'], ['/convert', '⇄', 'Convert'], ['#more', '☰', 'More']
    ];
    const nav = document.createElement('nav');
    nav.className = 'mobile-bottom-nav';
    nav.innerHTML = items.map(([href, icon, label]) => {
        const active = location.pathname === href ? 'active' : '';
        const attrs = href === '#more' ? 'href="#" data-mobile-more="1"' : `href="${href}"`;
        const special = href === '/mine' ? ' trade-dollar-tab' : '';
        return `<a class="${active}${special}" ${attrs}><span>${icon}</span><small>${uiLabel(label)}</small></a>`;
    }).join('');
    document.body.appendChild(nav);
    nav.querySelector('[data-mobile-more="1"]')?.addEventListener('click', (e) => {
        e.preventDefault();
        openMobileMoreSheet();
    });
}

function initMobileQuickMenu() {
    // V19: keep mobile clean. The bottom 'More' tab opens the full menu,
    // so we do not inject an extra top hamburger on phones.
    if (window.matchMedia && window.matchMedia('(max-width: 900px)').matches) return;
    return;
}


function initDesktopQuickMenu() {
    const user = TokenManager.getUser();
    if (window.matchMedia && window.matchMedia('(max-width: 900px)').matches) return;
    if (!user || document.querySelector('.desktop-menu-btn')) return;
    const actions = document.querySelector('.navbar-actions');
    const navMenu = document.querySelector('.navbar-menu');
    if (!actions) return;

    if (navMenu) {
        navMenu.classList.add('desktop-compact-menu');
        const current = navMenu.querySelector('a.active')?.textContent?.trim() || 'Menu';
        const indicator = document.createElement('span');
        indicator.className = 'desktop-current-section';
        indicator.textContent = current.replace(/\s+/g, ' ');
        actions.insertBefore(indicator, actions.firstChild);
    }

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'btn btn-secondary btn-sm desktop-menu-btn';
    btn.setAttribute('aria-label', 'Open full menu');
    btn.innerHTML = '☰ Menu';
    btn.addEventListener('click', openMobileMoreSheet);
    const firstAfterCurrent = actions.querySelector('.desktop-current-section')?.nextSibling || actions.firstChild;
    actions.insertBefore(btn, firstAfterCurrent);
}

function getMobileMenuLinks() {
    const user = TokenManager.getUser();
    if (!user) return [];
    if (user.role === 'admin') {
        return [
            { section: 'Admin', items: [
                ['/admin', 'Dashboard', '🛡️'], ['/admin-users', 'Users', '👥'], ['/admin-deposits', 'Deposits', '💵'], ['/admin-withdrawals', 'Withdrawals', '↗'],
                ['/admin-kyc', 'KYC', '🪪'], ['/admin-tickets', 'Tickets', '🎫'], ['/admin-notifications', 'Notifications', '🔔'], ['/admin-send', 'Broadcast', '📣'], ['/admin-wheel', 'Wheel', '🎡']
            ]},
            { section: 'Quick actions', items: [
                ['#download', 'Download app', '⬇️'], ['#logout', 'Logout', '⇥']
            ]}
        ];
    }
    return [
        { section: 'Account', items: [
            ['/dashboard', 'Dashboard', '🏠'], ['/profile', 'Profile', '👤'], ['/mine', 'Mining Contracts', '⛏️'], ['/convert', 'Convert', '⇄'], ['/lucky-wheel', 'Lucky Wheel', '🎡'], ['/notifications', 'Notifications', '🔔'], ['/support', 'Support', '🛟'], ['/kyc', 'KYC Verification', '🪪']
        ]},
        { section: 'Funds', items: [
            ['/deposit', 'Deposit', '➕'], ['/withdraw', 'Withdraw', '↗'], ['/wallet', 'Assets', '💼'], ['/convert', 'Convert', '⇄'], ['/referral', 'Referral', '🤝']
        ]},
        { section: 'More', items: [
            ['/tickets', 'Tickets', '🎫'], ['/referral', 'Referral Program', '🎁'], ['#download', 'Download app', '⬇️'], ['#logout', 'Logout', '⇥']
        ]}
    ];
}

function openMobileMoreSheet() {
    let sheet = document.getElementById('mobileMoreSheet');
    if (!sheet) {
        sheet = document.createElement('div');
        sheet.id = 'mobileMoreSheet';
        sheet.className = 'mobile-more-sheet';
        document.body.appendChild(sheet);
    }
    const groups = getMobileMenuLinks();
    sheet.innerHTML = `
        <div class="mobile-more-backdrop" data-close-sheet="1"></div>
        <div class="mobile-more-panel">
            <div class="mobile-more-handle"></div>
            <div class="mobile-more-header">
                <div>
                    <strong>${uiLabel('N-VT Miner Menu')}</strong>
                    <p>${uiLabel('All account tools in one place.')}</p>
                </div>
                <button type="button" class="mobile-more-close" data-close-sheet="1">✕</button>
            </div>
            <div class="mobile-more-content">
                ${groups.map(group => `
                    <section class="mobile-more-group">
                        <h4>${uiLabel(group.section)}</h4>
                        <div class="mobile-sheet-grid">
                            ${group.items.map(([href, label, icon]) => `<a href="${href}" data-mobile-link="1"><span>${icon}</span><small>${uiLabel(label)}</small></a>`).join('')}
                        </div>
                    </section>
                `).join('')}
            </div>
        </div>`;
    sheet.classList.add('open');
    document.body.classList.add('sheet-open');
    sheet.querySelectorAll('[data-close-sheet="1"]').forEach(el => el.addEventListener('click', closeMobileMoreSheet));
    sheet.querySelectorAll('[data-mobile-link="1"]').forEach(el => {
        el.addEventListener('click', async (e) => {
            const href = el.getAttribute('href');
            if (href === '#download') {
                e.preventDefault();
                closeMobileMoreSheet();
                await installNVTMiner();
                return;
            }
            if (href === '#logout') {
                e.preventDefault();
                closeMobileMoreSheet();
                logout();
                return;
            }
            closeMobileMoreSheet();
        });
    });
}

function closeMobileMoreSheet() {
    const sheet = document.getElementById('mobileMoreSheet');
    if (sheet) sheet.classList.remove('open');
    document.body.classList.remove('sheet-open');
}




function currentLang() { return localStorage.getItem('nexavest_lang') || 'en'; }
function tQuick(en, fa) { return currentLang() === 'fa' ? fa : en; }

function createAppPopup({ id, icon = '🔔', title, message, primaryText, primaryHref, secondaryText }) {
    let modal = document.getElementById(id);
    if (modal) modal.remove();
    modal = document.createElement('div');
    modal.id = id;
    modal.className = 'app-popup-overlay';
    modal.innerHTML = `
        <div class="app-popup-card">
            <button class="app-popup-close" type="button" data-popup-close="1">✕</button>
            <div class="app-popup-icon">${icon}</div>
            <h3>${title}</h3>
            <p>${message}</p>
            <div class="app-popup-actions">
                ${primaryHref ? `<a class="btn btn-primary" href="${primaryHref}">${primaryText}</a>` : ''}
                <button class="btn btn-secondary" type="button" data-popup-close="1">${secondaryText || tQuick('Later','بعداً')}</button>
            </div>
        </div>`;
    document.body.appendChild(modal);
    requestAnimationFrame(() => modal.classList.add('open'));
    modal.querySelectorAll('[data-popup-close="1"]').forEach(btn => btn.addEventListener('click', () => modal.remove()));
    modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
    return modal;
}

async function checkUserAlertsPopup() {
    const user = TokenManager.getUser();
    if (!user || user.role === 'admin') return;
    if (['/login','/register','/'].includes(location.pathname)) return;
    try {
        const [notif, tickets] = await Promise.allSettled([Notifications.list(currentLang()), Tickets.my()]);
        const unreadNotifications = notif.status === 'fulfilled' && notif.value.success ? (notif.value.notifications || []).filter(n => !n.is_read && n.type !== 'mining_auto_claim') : [];
        const unreadTickets = tickets.status === 'fulfilled' && tickets.value.success ? (tickets.value.tickets || []).filter(t => Number(t.user_unread || 0) > 0) : [];
        if (unreadNotifications.length || unreadTickets.length) {
            const key = `nvt_alert_popup_${unreadNotifications[0]?.id || 'ticket'}_${unreadTickets[0]?.id || 'n'}`;
            if (sessionStorage.getItem(key)) return;
            sessionStorage.setItem(key, '1');
            const title = tQuick('You have a new message', 'اعلان یا پیام جدید دارید');
            const first = unreadNotifications[0];
            const message = first ? `${first.title}: ${first.message}` : tQuick('Support replied to one of your tickets.', 'پشتیبانی به یکی از تیکت‌های شما پاسخ داده است.');
            createAppPopup({ id: 'newMessagePopup', icon: '🔔', title, message, primaryText: tQuick('View messages','مشاهده پیام‌ها'), primaryHref: first ? '/notifications' : '/tickets' });
        }
    } catch (e) { /* silent */ }
}

async function checkWheelPromoPopup() {
    const user = TokenManager.getUser();
    if (!user || user.role === 'admin') return;
    if (!['/dashboard','/wallet','/profile'].includes(location.pathname)) return;
    try {
        const status = await Wheel.status();
        if (!status.success || !status.enabled || !status.popup_enabled) return;
        const today = new Date().toISOString().slice(0, 10);
        const key = `nvt_wheel_promo_${user.id || user.email}_${today}`;
        if (sessionStorage.getItem(key)) return;
        sessionStorage.setItem(key, '1');
        createAppPopup({
            id: 'wheelPromoPopup',
            icon: '🎡',
            title: tQuick('Lucky Wheel is active', 'گردونه شانس فعال است'),
            message: status.spins > 0
              ? tQuick(`You have ${status.spins} spin chance. Try your luck now.`, `شما ${status.spins} شانس چرخش دارید. همین حالا امتحان کنید.`)
              : tQuick('Invite a friend who makes a verified deposit to unlock spin chances.', 'با معرفی کاربری که واریز تاییدشده انجام دهد، شانس چرخش بگیرید.'),
            primaryText: tQuick('Open Lucky Wheel','رفتن به گردونه'),
            primaryHref: '/lucky-wheel'
        });
    } catch (e) { /* silent */ }
}

function initUserPopups() {
    // Wheel promotion popup intentionally disabled. User/admin notifications remain active.
    setTimeout(() => { checkUserAlertsPopup(); }, 900);
    setInterval(checkUserAlertsPopup, 60000);
}

// Export functions
window.api = api;
window.Toast = Toast;
window.TokenManager = TokenManager;
window.Auth = Auth;
window.User = User;
window.Wallet = Wallet;
window.Mine = Mine;
window.Trade = Mine;
window.Referral = Referral;
window.Withdraw = Withdraw;
window.KYC = KYC;
window.Notifications = Notifications;
window.Tickets = Tickets;
window.Wheel = Wheel;
window.Admin = Admin;
window.formatNumber = formatNumber;
window.formatCurrency = formatCurrency;
window.formatDate = formatDate;
window.copyToClipboard = copyToClipboard;
window.formatAddress = formatAddress;
window.requireAuth = requireAuth;
window.requireAdmin = requireAdmin;
window.logout = logout;
window.initTicker = initTicker;
window.updateUserNavbar = updateUserNavbar;
window.protectPage = protectPage;
window.getUrlParam = getUrlParam;
window.createCountdown = createCountdown;
window.cryptoPrices = cryptoPrices;

// Direct APK download + global release announcement
const APK_DOWNLOAD_URL = '/downloads/app-release.apk';

function downloadNVTMinerAPK() {
    const link = document.createElement('a');
    link.href = APK_DOWNLOAD_URL;
    link.download = 'NVT-Miner.apk';
    link.rel = 'noopener';
    document.body.appendChild(link);
    link.click();
    link.remove();
}

async function installNVTMiner() {
    downloadNVTMinerAPK();
}

function showApkReleaseBanner() {
    if (document.getElementById('nvtApkReleaseBanner')) return;

    const banner = document.createElement('div');
    banner.id = 'nvtApkReleaseBanner';
    banner.className = 'apk-release-banner';
    banner.innerHTML = `
        <div class="apk-release-banner__text">
            <strong>📱 فایل نصبی N-VT Miner منتشر شد</strong>
            <span>نسخه اندروید اکنون برای دانلود مستقیم در دسترس است.</span>
        </div>
        <button type="button" class="btn btn-primary apk-download-btn">دانلود APK</button>
    `;

    banner.querySelector('.apk-download-btn').addEventListener('click', downloadNVTMinerAPK);
    document.body.prepend(banner);
}

function initPWAInstall() {
    document.addEventListener('click', (event) => {
        const btn = event.target.closest('.install-btn');
        if (btn) {
            event.preventDefault();
            downloadNVTMinerAPK();
        }
    });

    showApkReleaseBanner();

    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/sw.js').catch(() => null);
    }
}

// Landing page metrics animation for the experimental UI build.
function initLandingMetrics() {
    const portfolio = document.getElementById('heroPortfolio');
    const deposits = document.getElementById('heroDeposits');
    const pending = document.getElementById('heroPending');
    if (!portfolio || !deposits || !pending) return;

    let pendingValue = 286430.19;
    let depositValue = 40384219.58;
    let portfolioValue = 100126840.72;

    const render = () => {
        pendingValue += (Math.random() - 0.48) * 750;
        depositValue += Math.random() * 180;
        portfolioValue += (Math.random() - 0.45) * 520;
        portfolio.textContent = formatCurrency(portfolioValue);
        deposits.textContent = '+ ' + formatCurrency(depositValue);
        pending.textContent = formatCurrency(Math.max(120000, pendingValue));
    };
    render();
    setInterval(render, 3500);
}

function getVipLevel(totalDeposit = 0) {
    const v = Number(totalDeposit || 0);
    if (v >= 50000) return { level: 'VIP 6', min: 3, max: 4, range: '50,000+ USDT', daily_trades: 20, next_min: null };
    if (v >= 15000) return { level: 'VIP 5', min: 2.5, max: 3.2, range: '15,000 - 50,000 USDT', daily_trades: 15, next_min: 50000 };
    if (v >= 5000) return { level: 'VIP 4', min: 2, max: 2.7, range: '5,000 - 15,000 USDT', daily_trades: 10, next_min: 15000 };
    if (v >= 2000) return { level: 'VIP 3', min: 1.5, max: 2.1, range: '2,000 - 5,000 USDT', daily_trades: 7, next_min: 5000 };
    if (v >= 400) return { level: 'VIP 2', min: 1, max: 1.5, range: '400 - 2,000 USDT', daily_trades: 5, next_min: 2000 };
    if (v >= 50) return { level: 'VIP 1', min: 0.5, max: 1, range: '50 - 400 USDT', daily_trades: 3, next_min: 400 };
    return { level: 'Starter', min: 0, max: 0, range: 'Deposit at least 50 USDT to unlock Cloud Mine', daily_trades: 0, next_min: 50 };
}

function getAllVipLevels() {
    return [
        { level: 'VIP 1', min_deposit: 50, max_deposit: 400, profit: '0.5% - 1%', daily_trades: 3 },
        { level: 'VIP 2', min_deposit: 400, max_deposit: 2000, profit: '1% - 1.5%', daily_trades: 5 },
        { level: 'VIP 3', min_deposit: 2000, max_deposit: 5000, profit: '1.5% - 2.1%', daily_trades: 7 },
        { level: 'VIP 4', min_deposit: 5000, max_deposit: 15000, profit: '2% - 2.7%', daily_trades: 10 },
        { level: 'VIP 5', min_deposit: 15000, max_deposit: 50000, profit: '2.5% - 3.2%', daily_trades: 15 },
        { level: 'VIP 6', min_deposit: 50000, max_deposit: null, profit: '3% - 4%', daily_trades: 20 }
    ];
}

window.installNVTMiner = installNVTMiner;
window.initPWAInstall = initPWAInstall;
window.initLandingMetrics = initLandingMetrics;
window.showAppLoader = showAppLoader;
window.hideAppLoader = hideAppLoader;
window.initPageLoader = initPageLoader;
window.initMobileBottomNav = initMobileBottomNav;
window.initMobileQuickMenu = initMobileQuickMenu;
window.initDesktopQuickMenu = initDesktopQuickMenu;
window.openMobileMoreSheet = openMobileMoreSheet;
window.closeMobileMoreSheet = closeMobileMoreSheet;
window.initUserPopups = initUserPopups;
window.getVipLevel = getVipLevel;
window.getAllVipLevels = getAllVipLevels;

document.addEventListener('DOMContentLoaded', () => { initPageLoader(); initPWAInstall(); initDynamicNav(); initMobileBottomNav(); initMobileQuickMenu(); initDesktopQuickMenu(); initUserPopups(); });


// Global account notification center (popup + PWA notification + balance refresh)
const LiveNotifications = {
    timer: null,
    busy: false,
    lastKey: 'nvt_last_popup_notification_id',

    async enableDeviceNotifications() {
        if (!('Notification' in window)) return { ok: false, message: 'Notifications are not supported on this device.' };
        const permission = await Notification.requestPermission();
        return { ok: permission === 'granted', message: permission === 'granted' ? 'Device notifications enabled.' : 'Notification permission was not granted.' };
    },

    async showSystemNotification(n) {
        if (!('Notification' in window) || Notification.permission !== 'granted') return;
        try {
            const reg = await navigator.serviceWorker?.ready;
            if (reg) {
                await reg.showNotification(n.title || 'NVT', {
                    body: n.message || '',
                    icon: '/images/icon-192.png',
                    badge: '/images/icon-192.png',
                    tag: `nvt-notification-${n.id}`,
                    renotify: false,
                    data: { url: '/notifications' }
                });
            } else {
                new Notification(n.title || 'NVT', { body: n.message || '', icon: '/images/icon-192.png' });
            }
        } catch (_) {}
    },

    showPopup(n) {
        const old = document.getElementById('nvtLiveNotificationModal');
        if (old) old.remove();
        const wrap = document.createElement('div');
        wrap.id = 'nvtLiveNotificationModal';
        wrap.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.66);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;';
        const safeTitle = String(n.title || 'New notification').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
        const safeMessage = String(n.message || '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
        wrap.innerHTML = `<div class="card" style="width:min(430px,100%);text-align:center;border:1px solid var(--primary);box-shadow:0 20px 70px rgba(0,0,0,.45)">
            <div style="font-size:2.4rem;margin-bottom:.6rem">🔔</div>
            <h2 style="margin:0 0 .75rem">${safeTitle}</h2>
            <p style="white-space:pre-wrap;color:var(--text-secondary);line-height:1.8">${safeMessage}</p>
            <div style="display:flex;gap:.75rem;justify-content:center;margin-top:1.25rem;flex-wrap:wrap">
                <button type="button" class="btn btn-primary" id="nvtNotificationOk">متوجه شدم</button>
                <a class="btn btn-secondary" href="/notifications">مشاهده اعلان‌ها</a>
            </div>
        </div>`;
        document.body.appendChild(wrap);
        const close = async () => {
            wrap.remove();
            try { await Notifications.markRead(n.id); } catch (_) {}
        };
        wrap.querySelector('#nvtNotificationOk')?.addEventListener('click', close);
    },

    async refreshBalance() {
        try {
            const profile = await User.getProfile();
            if (!profile?.success) return;
            const value = formatCurrency(profile.user.wallet_balance || 0);
            document.querySelectorAll('#userBalance').forEach(el => el.textContent = value);
            window.dispatchEvent(new CustomEvent('nvt:balance-updated', { detail: profile.user }));
        } catch (_) {}
    },

    async poll() {
        if (this.busy || !TokenManager.get()) return;
        this.busy = true;
        try {
            const lang = document.documentElement.lang === 'fa' || localStorage.getItem('lang') === 'fa' ? 'fa' : 'en';
            const result = await api(`/notifications?lang=${encodeURIComponent(lang)}`);
            if (!result?.success) return;
            const lastShown = Number(localStorage.getItem(this.lastKey) || 0);
            const fresh = (result.notifications || []).filter(n => !n.is_read && Number(n.id) > lastShown).sort((a,b) => a.id-b.id);
            for (const n of fresh) {
                localStorage.setItem(this.lastKey, String(n.id));
                this.showPopup(n);
                await this.showSystemNotification(n);
                const notificationText = `${n.title || ''} ${n.message || ''}`;
                if (/deposit approved|واریز تایید|واریز تأیید|mining_auto_claim|miner completed|ماینر تکمیل/i.test(`${n.type || ''} ${notificationText}`)) await this.refreshBalance();
                if (n.type === 'mining_auto_claim') {
                    try { await Notifications.markRead(n.id); } catch (_) {}
                }
                break;
            }
            document.querySelectorAll('[data-notification-count]').forEach(el => {
                el.textContent = String(result.unread || 0);
                el.style.display = result.unread ? '' : 'none';
            });
        } catch (_) {
        } finally {
            this.busy = false;
        }
    },

    start() {
        if (!TokenManager.get() || this.timer) return;
        setTimeout(() => this.poll(), 1200);
        this.timer = setInterval(() => this.poll(), 15000);
        document.addEventListener('visibilitychange', () => { if (!document.hidden) this.poll(); });
    }
};

document.addEventListener('DOMContentLoaded', () => LiveNotifications.start());
window.LiveNotifications = LiveNotifications;
