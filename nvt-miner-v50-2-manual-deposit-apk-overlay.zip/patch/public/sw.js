const CACHE_NAME = 'nvt-v50-1-manual-deposit-apk-release';
const CORE_ASSETS = ['/css/style.css', '/js/app.js', '/js/i18n.js', '/manifest.json', '/images/icon-192.png'];
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(CORE_ASSETS)).catch(() => null));
  self.skipWaiting();
});
self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);
  if (url.pathname === '/' || url.pathname.endsWith('.html') || ['/deposit','/dashboard','/mine','/wallet','/withdraw','/vip-level'].includes(url.pathname)) return;
  if (req.method !== 'GET' || url.pathname.startsWith('/api/')) return;
  event.respondWith(fetch(req).catch(() => caches.match(req)));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const target = event.notification?.data?.url || '/notifications';
  event.waitUntil(clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
    for (const client of list) {
      if ('focus' in client) { client.navigate(target); return client.focus(); }
    }
    return clients.openWindow ? clients.openWindow(target) : null;
  }));
});
