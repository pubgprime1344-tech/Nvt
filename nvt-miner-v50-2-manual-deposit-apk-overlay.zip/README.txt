NVT V50.2 overlay update
- Does not replace cryptoinvest.db
- Does not replace .env, uploads or node_modules
- Restores manual deposit + QR
- Removes BEP20 automatic-test text/card
- Adds APK release banner and direct APK download
- Disables BEP20 automatic watcher
Run: bash INSTALL.sh
